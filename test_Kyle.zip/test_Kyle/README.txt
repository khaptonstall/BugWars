1) Modify init.bat
-> ANDROID_HOME=[Android SDK directory]
-> AVD_NAME=[name of the avd]

2) Launch init.bat
3) Launch installerTestSuiteCoverage
4) unlock emulator
5) close emulator
6) run "java -jar ExecutorGenerator N" replacing N with the number of the last test case of the test suite
7) run executor.bat

--------------------------

if you want you can modify "executor.bat" in order to shorten wait times replacing (as an example):

call %EXPPATH%/wait.bat 45

with

call %EXPPATH%/wait.bat 20

----------------------------

OUTPUT:
- log.txt (logcat)
- test.txt (test summary)
- coverage directory contains coverageXXX.ec (1 for each test case)
- coverage.em can be found in \Tomdroid071_r400\bin