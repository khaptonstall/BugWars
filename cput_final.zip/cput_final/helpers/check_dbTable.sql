--Author: Sachinkumar Jain                                                                                                                          
-- Function: check_CputDB_Table                                                        
-- Purpose:  This function is used to maintain cput_database_info table. This table has one row for every database that is created from within the CPUT tool. The table has database name, user created, date created, user modified, last modified data, drop flag fields. Drop flag is set to 'N' when a database is newly created. It is set to 'Y' when through CPUT, a user replaces the database with another database of the same name. To avoid having several rows in the cput_database_info table with the same database name, this function clears all rows that have a flag set to 'Y' and a date greater than user-specified date.

-- To run the function: select check_CputDB_Table('2010-05-19');

-- Algorithm:
-- 1. If a database is dropped from the postgres prompt and is not replaced from within CPUT, this function, sets all such rows to flag 'Y' in the cput_database_info table.
-- 2. If a database is dropped from the postgres prompt, and is replace from within CPUT, that new row is created with flag 'N' by CPUT. This function, convers the flag of all old rows with the same database name to 'Y'. This function, finds all rows from cput_database_info table with the same database name, a flag of 'N', and a rank > 1 (rank function is a postgres sql function that gives ranks to databases with the same name that are created at different times. the most recent database has a rank of 1, all other databases have a rank greater than 1), and sets their flag to 'Y'
-- 3. Finally, all rows with a flag of 'Y' and a creation date greater than the date provided by the user are deleted from the cput_database_info table.
-- Note: If a database is replaced from within CPUT, the new row is created with flag 'N' by CPUT. CPUT also updates old rows with same database name to 'Y' (not done by this function)
 

-----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION check_CputDB_Table (dt date)
RETURNS void
AS $$

BEGIN
	--Initially update all the rows with dropdbFlag = 'Y' where
 	--dbname is not present in pg_database catalog table.

	update cput_database_info 
   	set dropdbflag = 'Y' 
	where dropdbflag = 'N' 
	and dbname not in (select datname from pg_database);

	-- Update all the rows with dropdbFlag = 'Y' where
	-- there are multiple rows with same database name
	-- and dropdbflag = 'N'. But we need to retain the latest
	-- row which was created last. 

	Update cput_database_info c 
	set dropdbflag = 'Y' 
	from (select dbname, datecreated ,
			RANK() OVER (partition by dbname order by datecreated 				desc) AS pos 
		from cput_database_info where dropdbflag = 'N') as foo 	where pos > 1 and foo.datecreated = c.datecreated;	

	-- Finally delete all the rows with dropdbflag = 'Y' and
	-- user specified date.

	delete from cput_database_info 
	where dropdbflag = 'Y' 
	and datecreated >= dt;



    END;
   $$ LANGUAGE plpgsql;
