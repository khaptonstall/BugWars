package cput;

import java.util.HashMap;
import java.util.LinkedList;

/**
 * This class encapsulates the contents of a Test Case.
 * Included in this class are the 'scoring' values for each
 * prioritization criteria, Hashtables to store the two-way inputParameters
 * used to calculated the two-way score as well as the actual text of the test
 * case.
 * @author Schuyler Manchester & Devin Minson
 * @editorInChief Chelynn Day
 * @co-editorInChief Michael Burton
 */
public class TestCase implements java.io.Serializable {

	private String ID;
    private String testCase;  //used to store the contents of the test case


//    protected HashMap<String, Boolean> pairs;
    protected HashMap<String, Integer> frequencyLength2Map;

    private boolean REDUCED;
    private int numGets;
    private int numPosts;
    private int numParams;
    private int numGetsPosts;
    private int numURLs;
    private int originalIndex;
    private int currentIndex;
    
    private int oneWayScore; //number of pairs that haven't been covered by another session
    private int twoWayScore;
    private int twoWayConScore;
    private int twoWaySeqScore;
    private int twoWayIntraScore;
    private double HybridScore;
    private int threeWayScore;
    private int threeWaySeqScore;
    private int oneWayScore_Reduced;
    private int twoWayScore_Reduced;
    private int twoWayConScore_Reduced;
    private int twoWaySeqScore_Reduced;
    private int twoWayIntraScore_Reduced;
    private int threeWayScore_Reduced;
    private int threeWaySeqScore_Reduced;
    private int HGSScore;
    
//    private int preOrderTwoWayScore;  //number of unique pairs in the session
//    private int preOrderThreeWayScore;
//    private int preOrderTwoWaySeqScore;
//    private int preOrderThreeWaySeqScore;

    /**
     * Constructor that initializes the ID of the test case and stores its
     * original index in the test suite.
     * @param id
     * @param index
     */
    public TestCase(String id, int index){
        this.ID = id;
        this.originalIndex = index;
        this.currentIndex = index;
        testCase = new String();
        frequencyLength2Map = new HashMap<String, Integer>();
        REDUCED = false;
        
        //Initialize gets, posts, params, and urls to 0
        numGets = 0;
        numPosts = 0;
        numParams = 0;
        numURLs = 0;
        
        //initialize scores to -1 to indicate they have not yet been calculated
        oneWayScore = -1;
        twoWayScore = -1;
        twoWayConScore = -1;
        twoWaySeqScore = -1;
        twoWayIntraScore = -1;
        HybridScore = -1;
        threeWayScore = -1;
        threeWaySeqScore = -1;
        oneWayScore_Reduced = -1;
        twoWayScore_Reduced = -1;
    	twoWayConScore_Reduced = -1;
        twoWaySeqScore_Reduced = -1;
    	twoWayIntraScore_Reduced = -1;
        threeWayScore_Reduced = -1;
        threeWaySeqScore_Reduced = -1;

	HGSScore = 0;
    }

    /**
     * Method used to store the contents of the test case as a string.
     * This method is used when displaying a single test case to the user.
     * @param line
     */
    public void recordTestCase(String line){
        if(testCase.isEmpty()){ 
            testCase += line;
        }
        else{
            testCase += "\n" + line;
        }        
    }

    public void updateFrequency(String previousUrl, String url){
        String key = previousUrl + "|" + url;
        if(!this.frequencyLength2Map.containsKey(key))
            this.frequencyLength2Map.put(key, 1);
        else
            this.frequencyLength2Map.put(key, this.frequencyLength2Map.get(key) + 1);
    }

    /**
     * The preorder score is the number of two way pairs contained within this test case.
     * After all the test cases have a preOrderScore set, they are reordered
     * so that the test case with the high number of two way pairs is re-scored first.
     * This pre-score reordering ensures that the case that will provide the most
     * coverage will have the highest score.
     */
//    public void setTwoWayPreOrderScore(int score){
//        this.preOrderTwoWayScore = score;
//    }
//    //begin REU 2012 code
//    public void setTwoWayPreOrderScoreSeq(int score){
//        this.preOrderTwoWaySeqScore = score;
//    }
//    public void setThreeWayPreOrderScoreSeq(int score){
//        this.preOrderThreeWaySeqScore = score;
//    }
//    //end REU 2012 code
//    public void setThreeWayPreOrderScore(int score){
//        this.preOrderThreeWayScore = score;
//    }
    
    public void resetReducedScores(){
        setOneWay(-1, ReductionValue.Combinatorial_1Way);
        setTwoWay(-1, ReductionValue.Combinatorial_1Way);
        setTwoWaySeq(-1, ReductionValue.Combinatorial_1Way);
        setTwoWayCon(-1, ReductionValue.Combinatorial_1Way);
        setTwoWayIntra(-1, ReductionValue.Combinatorial_1Way);
        setThreeWay(-1, ReductionValue.Combinatorial_1Way);
        setThreeWaySeq(-1, ReductionValue.Combinatorial_1Way);        
    }
    
    public void setReduced(boolean reduced){
        this.REDUCED = reduced;
    }

    public boolean getReduced(){
        return this.REDUCED;
    }

    public String getId(){
        return ID;
    }

    public int getIndex(){
        return originalIndex;
    }
    
    public int getCurrentIndex(){
        return currentIndex;
    }
    
    public void setCurrentIndex(int index){
        this.currentIndex = index;
    }

    public void setGetsPosts(){
        this.numGetsPosts = numGets + numPosts;
    }

    public void incrementGets(){
        this.numGets++;
    }

    public void incrementParams(int params){
        this.numParams += params;
    }

    public void setLength(int length){
        this.numGetsPosts = length;
    }

    public void setParams(int numParams){
        this.numParams = numParams;
    }

    public void setURLs(int numURLs){
        this.numURLs = numURLs;
    }

    public void setOneWay(int oneWayScore, ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.oneWayScore = oneWayScore;
        else
            this.oneWayScore_Reduced = oneWayScore;
    }

    public void setTwoWay(int twoWayScore, ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.twoWayScore = twoWayScore;
        else
            this.twoWayScore_Reduced = twoWayScore;
    }

    public void setThreeWay(int threeWayScore, ReductionValue reductionSelection) {
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.threeWayScore = threeWayScore;
        else
            this.threeWayScore_Reduced = threeWayScore;
    }
    
    public void setTwoWaySeq(int twoWayScore, ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.twoWaySeqScore = twoWayScore;
        else
            this.twoWaySeqScore_Reduced = twoWayScore;
    }

    public void setThreeWaySeq(int threeWayScore, ReductionValue reductionSelection) {
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.threeWaySeqScore = threeWayScore;
        else
            this.threeWaySeqScore_Reduced = threeWayScore;
    }
    
    public void setTwoWayCon(int twoWayScore, ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.twoWayConScore = twoWayScore;
        else
            this.twoWayConScore_Reduced = twoWayScore;
    }
    
    public void setTwoWayIntra(int twoWayScore, ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            this.twoWayIntraScore = twoWayScore;
        else
            this.twoWayIntraScore_Reduced = twoWayScore;
    }
    public void setHybrid(double HybridScore) {
    	this.HybridScore = HybridScore;
    }
    
    public void setHGS(int HGSScore){
        this.HGSScore = HGSScore;
    }
    

    public void incrementPosts(){
        this.numPosts++;
    }

    public void incrementParams(){
        this.numParams++;
    }

    public String getTestCase(){
        return testCase;
    }

    public int getGets(){
        return numGets;
    }

    public int getPosts(){
        return numPosts;
    }

    public int getParams(){
        return numParams;
    }

    public int getURLs(){
        return numURLs;
    }

    public int getGetsPosts(){
        return numGetsPosts;
    }

    public int getOneWay(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return oneWayScore;
        return oneWayScore_Reduced;
    }

    public int getTwoWay(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return twoWayScore;
        return twoWayScore_Reduced;
    }
    
    public int getThreeWay(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return threeWayScore;
        return threeWayScore_Reduced;
    }
    
    public int getTwoWaySeq(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return twoWaySeqScore;
        return twoWaySeqScore_Reduced;
    }
    
    public int getThreeWaySeq(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return threeWaySeqScore;
        return threeWaySeqScore_Reduced;
    }
    
    public int getTwoWayCon(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return twoWayConScore;
        return twoWayConScore_Reduced;
    }
    
    public int getTwoWayIntra(ReductionValue reductionSelection){
        if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
            return twoWayIntraScore;
        return twoWayIntraScore_Reduced;
    }
    
    public double getHybrid(){
    	return HybridScore;
    }
    
    public int getHGS(){
        return HGSScore;
    }
    

 

    protected enum ReductionValue {
        HGS_1Way,
        HGS_2Way,
        HGS_3Way,
        Combinatorial_1Way,
        Combinatorial_2Way,
        Combinatorial_3Way,
        Seq_2Way,
        Seq_3Way,
        HGS_2WaySeq,
        HGS_3WaySeq,
        HGS_2WayCon,
        HGS_2WayIntra,
        Con_2Way,
        Intra_2Way,
        NONE
    }

    
    protected enum PrioritizationValue {
        Length,
        Params,
        OneWay,
        TwoWay,
        TwoWayCon,
        TwoWaySeq,
        TwoWayIntra,
        HybridRank,
        HybridMerge,
        HybridChoice,
        ThreeWay,
        ThreeWaySeq,
        Frequency,
        MFPS,
        APS,
        WF,
        Random,
	NONE
    }

    /**
     * In order to utilize the Quick Sort algorithm for all the different
     * dataMembers stored in the TestCase class, this function will return
     * the 'Sorting Value'.  The parameter 'Criteria' determines which criteria
     * the user is performing the sort upon.
     * @param criteria
     * @return
     */
    public double getSortingValue(PrioritizationValue criteria, ReductionValue reductionSelection){
        switch(criteria){
            case Length:
                return numGetsPosts;
            case Params:
                return numParams;
            case OneWay:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return oneWayScore;
                else
                    return oneWayScore_Reduced;
            case TwoWay:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return twoWayScore;
                else
                    return twoWayScore_Reduced;
            case ThreeWay:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return threeWayScore;
                else
                    return threeWayScore_Reduced;
            case TwoWaySeq:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return twoWaySeqScore;
                else
                    return twoWaySeqScore_Reduced;
            case ThreeWaySeq:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return threeWaySeqScore;
                else
                    return threeWaySeqScore_Reduced;
            case TwoWayCon:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return twoWayConScore;
                else
                    return twoWayConScore_Reduced;
            case TwoWayIntra:
                if (reductionSelection == null || reductionSelection == ReductionValue.NONE)
                    return twoWayIntraScore;
                else
                    return twoWayIntraScore_Reduced;
            case HybridRank:
            case HybridMerge:
            case HybridChoice:
            	return HybridScore;
            case NONE:
                return originalIndex;
            default:
                return -1;  //signifies an incorrect criteria was selected
        }        
    }

    public int getFrequencyValue(String key){
        if(frequencyLength2Map.containsKey(key))
            return frequencyLength2Map.get(key);
        else
            return 0;
    }
	public HashMap<String, Integer> getFrequency(){
		return frequencyLength2Map;
	}
}
	