
package cput;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * @author Chelynn
 */
public class HGS2WayReducer {
    
    private ArrayList<List<? extends Edge>> graph;
    private TestCase.ReductionValue reduceType;
    private ArrayList<TestCase> testList;
    private MainScreen view;
    
    HGS2WayReducer(MainScreen theView, ArrayList<List<RegularEdge>> theGraph, ArrayList<TestCase> theTestList, TestCase.ReductionValue reductionType){
        testList=theTestList;
        testList.clear();
	graph= new ArrayList<List<? extends Edge>>();
        graph.addAll(theGraph);
        reduceType=reductionType;
	view=theView;
    }
    
    HGS2WayReducer(ArrayList<List<IntraEdge>> theGraph, ArrayList<TestCase> theTestList, TestCase.ReductionValue reductionType, MainScreen theView){
        testList=theTestList;
        testList.clear();
	graph= new ArrayList<List<? extends Edge>>();
	graph.addAll(theGraph);
        reduceType=reductionType;
	view=theView;
    }
    
    public ArrayList<TestCase> reduce() {
	int biggestCardinalityLeft = 1;
	int curCardinality = 0;
        
        ArrayList<Edge> edgesToCover = new ArrayList<Edge>();
        ArrayList<Integer> fromVertices = new ArrayList<Integer>();
        ArrayList<TestCase> coveringTests = new ArrayList<TestCase>();	//holds all tests that cover the edges
        ArrayList<Integer> coveringTestScores = new ArrayList<Integer>();	//how many edges each test covers
        
	while(biggestCardinalityLeft>curCardinality){
		curCardinality++;
                edgesToCover.clear();
                fromVertices.clear();
                coveringTests.clear();
                coveringTestScores.clear();

                biggestCardinalityLeft = getEdgesOfCardinality(curCardinality, edgesToCover, fromVertices, coveringTests, coveringTestScores);
		double progress=((double)curCardinality*100)/biggestCardinalityLeft;
		view.updateProgress((int)progress, false);
		double edgeCount=edgesToCover.size();
                //this loop continues until all edges are covered
                while(edgesToCover.size()>0){
		    double edgePercent=(((edgeCount-edgesToCover.size())*100)/edgeCount)/biggestCardinalityLeft;
		    view.updateProgress((int)(edgePercent+progress), false);
                        //gets the best test case, and adds it to the test list
                        TestCase bestTest=getMaximumCoveringTest(curCardinality, coveringTests, coveringTestScores);
                        testList.add(bestTest);
                        bestTest.setReduced(false);

                        //update coverage array lists
                        for(int curEdge = 0; curEdge < edgesToCover.size(); curEdge++){
                                Edge edge = edgesToCover.get(curEdge);
				LinkedList<TestCase> tests = edge.getApplicableTestCases(reduceType);
				if(tests.contains(bestTest)){
				    edgesToCover.remove(curEdge);
				    fromVertices.remove(curEdge);
				    curEdge--;
				    for(int curTest = 0; curTest < tests.size(); curTest++)
				    {
					int testIndex = coveringTests.indexOf(tests.get(curTest));
					coveringTestScores.set(testIndex, coveringTestScores.get(testIndex) - 1);
				    }
				}
                        }
                }
        }
        return testList;
    }
    
    //gets the coverage arrays for how many edges each test case covers
    private void getCoveringTests(Edge edge, ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestScores){
	LinkedList<TestCase> tests = edge.getApplicableTestCases(reduceType);
	for(int curTestCase = 0; curTestCase < tests.size(); curTestCase++){
	    TestCase testCase = tests.get(curTestCase);
	    int index = coveringTests.indexOf(testCase);
	    if(index != -1)		//the current test case is already in the array, so increment score
		    coveringTestScores.set(index, coveringTestScores.get(index)+1);
	    else {			//add it to the covering tests array and give it a score of 1
		    coveringTests.add(testCase);
		    coveringTestScores.add(1);
	    }
	}
    }

    //fill edgesToCover with all the edges with a given cardinality that are uncovered, then return if there are more edges to be covered
    //calls getCoveringTests to fill coveringTests with the tests that cover the uncovered edges,
    //and it also puts the counts of how many edges each test covers into coveringTestScores
    private int getEdgesOfCardinality(int curCardinality, ArrayList<Edge> edgesToCover, ArrayList<Integer> fromVertices, ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestScores){
        int maxCardinality=curCardinality;
	for(int curTestCase = 0; curTestCase < graph.size(); curTestCase++){
		List edgeList = graph.get(curTestCase);
		for(int curEdge = 0; curEdge < edgeList.size(); curEdge++){
			Edge edge = (Edge)edgeList.get(curEdge);
                        int cardinality = edge.getApplicableTestCases(reduceType).size();
			if(cardinality == curCardinality && !isCovered(edge, curTestCase)){
				edgesToCover.add(edge);
                                fromVertices.add(curTestCase);
				getCoveringTests(edge, coveringTests, coveringTestScores);
			}
			else if(cardinality > curCardinality && !isCovered(edge, curTestCase)){
				if(cardinality>maxCardinality)
				    maxCardinality = cardinality;	
                        }
		}
	}
	return maxCardinality;
    }

    //returns whether an edge has already been covered by tests added so far
    private boolean isCovered(Edge edge, int fromVertex){
	LinkedList<TestCase> tests = edge.getApplicableTestCases(reduceType);
	for(int curTestCase = 0; curTestCase < tests.size(); curTestCase++)
		if(testList.contains(tests.get(curTestCase)))
			return true;
	if(reduceType==TestCase.ReductionValue.HGS_2Way){
		if(fromVertex>edge.getConnectedVertex()){
		    //check to see if the flipped edge exists, if so, dont look at this edge, it will be covered
		    List<? extends Edge> edges=graph.get(edge.getConnectedVertex());
		    for(int i=0; i<edges.size(); i++)
			if(edges.get(i).getConnectedVertex()==fromVertex)
			return true;
		}
	}
	return false;
    }

    //determines which test case has the maximum coverage
    private TestCase getMaximumCoveringTest(int curCardinality, ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestScores){
	int maxScore =- 1;
	for(int index = 0; index < coveringTests.size(); index++){
	    System.out.println(coveringTests.get(index).getId()+" "+coveringTestScores.get(index));
		if(coveringTestScores.get(index) > maxScore)
			maxScore = coveringTestScores.get(index);
	}
	ArrayList<TestCase> maxTests = new ArrayList<TestCase>();
	for(int index = 0; index < coveringTests.size(); index++)
		if(coveringTestScores.get(index) == maxScore)
			maxTests.add(coveringTests.get(index));
	System.out.println("max tests at 0 is "+maxTests.get(0));
	if(maxTests.size() == 1)
		return maxTests.get(0);
	return tieBreak(curCardinality, maxTests);
    }

    //breaks ties between test cases
    private TestCase tieBreak(int curCardinality, ArrayList<TestCase> tiedTests){
        ArrayList<Edge> edgesToCover = new ArrayList<Edge>();
        ArrayList<Integer> fromVertices = new ArrayList<Integer>();
	ArrayList<TestCase> coveringTests = new ArrayList<TestCase>();	//holds all tests that cover the edges
	ArrayList<Integer> coveringTestScores = new ArrayList<Integer>();	//how many edges each test covers
	int biggestCardinalityLeft = getEdgesOfCardinality(curCardinality + 1, edgesToCover, fromVertices, coveringTests, coveringTestScores);
	view.updateProgress((int)(((double)curCardinality*100)/biggestCardinalityLeft), false);
	for(int index = 0; index < coveringTests.size(); index++){
		if(!tiedTests.contains(coveringTests.get(index))){
			coveringTests.remove(index);
			coveringTestScores.remove(index);
			index--;
		}
	}
	if((edgesToCover.isEmpty() && biggestCardinalityLeft>curCardinality) || coveringTests.isEmpty()){
		Random rand=new Random();
		return tiedTests.get(rand.nextInt(tiedTests.size()));
	}
	return getMaximumCoveringTest(curCardinality+1, coveringTests, coveringTestScores);
    }
}