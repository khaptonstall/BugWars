package cput;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;


/*
 * @author Nilesh
 * 
 * In this class, the frequency prioritization of the test cases i.e. All Present,
 *  Most Frequently present and Weighted Frequency criteria are implemented.
 * 
 * */
public class FrequencyPrioritizer {
	
//	//This is mapping between the sequence and the SequenceProperties object.
//	private HashMap<String, SequenceProperties> sequenceTestCaseMap = null;
	
	//The total number of test cases in a test suite.
	private int numberOfTestCases = 0;
	
	//The SequenceProperties object.
	private SequenceProperties sequenceProperties = null;
	
	//This is the list of all SequenceProperties objects in the test suite.
	private ArrayList<SequenceProperties> sequencePropertiesObjList = null;
	
	//This is the list of test cases sorted using the MFPS prioritization criteria.
	private List<String> mfps_ListOfTestCases  = null;
	
	//This is the list of test cases sorted using the APS prioritization criteria.
	private List<String> aps_ListOfTestCases = null;
	
	//This is the list of test cases sorted using the WF prioritization criteria.
	private List<String> wf_ListOfTestCases = null;
	
	//This is the mapping of a test case with its weight in the test suite. This is used in WF scenario.
	private Map<String,Integer> testCaseWeightMapping = null;
	
	//This value is an indicator of the current criteria by which the test cases are being prioritized.
	private String prioritizationCriteria;
	
	//Constant MFPS. Used to initialize prioritizationCriteria when test cases are being prioritized using MFPS criterion.
	private static final String MFPS = "MFPS";
	
	//Constant APS. Used to initialize prioritizationCriteria when test cases are being prioritized using APS criterion.
	private static final String APS = "APS";
	
	//Constant WF. Used to initialize prioritizationCriteria when test cases are being prioritized using WF criterion.
	private static final String WF = "WF";
	
	//The list of test cases that are to be prioritized.
	private List<String> allTestCases = null;

	//This boolean checks if copies of sequencePropertiesList have been made. 
	private boolean isCopiesCreated = false;
	
	//This is a copy of the list of all SequenceProperties objects in the test suite. Used for APS and WF frequency prioritization.
	private ArrayList<SequenceProperties> copy_sequencePropertiesObjList = null;
	
	/*
	 * Constructor.
	 */
	public FrequencyPrioritizer(){
		init();
	}
	
	/*
	 * This method initialises all the data structures that are required in this class.
	 */
	private void init(){
//		sequenceTestCaseMap = new HashMap<String, SequenceProperties>();
		sequencePropertiesObjList = new ArrayList<SequenceProperties>();
		mfps_ListOfTestCases = new ArrayList<String>();
		aps_ListOfTestCases = new ArrayList<String>();
		wf_ListOfTestCases = new ArrayList<String>();
		testCaseWeightMapping = new HashMap<String, Integer>();
		allTestCases = new ArrayList<String>();
	}
	
	
	/*
	 * Sets the number of test cases.
	 */
	public void setNumberOfTestCases(int numberOfTestCases) {
		this.numberOfTestCases = numberOfTestCases;
	}

	/*
	 * This method sets the sequence and testCase local count
	 * and test case total count properties in a SequenceProperties object.
	 * The object is then added to the sequencePropertiesObjList. If the
	 * sequence already exists in sequencePropertiesObjList , the local count 
	 * and total count for the object are incremented.
	 */
	public void addSequence(final String sequence, final String testCase){
		boolean isSequenceExists = false;
		if(!allTestCases.contains(testCase)){
			allTestCases.add(testCase);
		}
		if(sequencePropertiesObjList.size()!=0){
			for(int sequencePropertiesIndex = 0; sequencePropertiesIndex<sequencePropertiesObjList.size();
			sequencePropertiesIndex++){
				SequenceProperties tempSequenceProperties = sequencePropertiesObjList.get(sequencePropertiesIndex);
				if(sequence.equals(tempSequenceProperties.getSequence())){
					sequenceProperties = tempSequenceProperties;
					isSequenceExists = true;
				}
			}
		}
		if(isSequenceExists){

			sequenceProperties.setTestCaseFrequencyMapping(testCase);

		}else if(!isSequenceExists){
			sequenceProperties = new SequenceProperties();
			sequenceProperties.setSequence(sequence);
			sequenceProperties.setTestCaseFrequencyMapping(testCase);
			sequencePropertiesObjList.add(sequenceProperties);
		}
	}
	
	/*
	 * @return mfps_ListOfTestCases.
	 */
	public List<String> getMostFrequentSequences(){
		prioritizationCriteria = MFPS;
		if(!isCopiesCreated)
			createCopiesOfSequencePropertiesObjList();
		sortSequences(sequencePropertiesObjList);
		shuffle(sequencePropertiesObjList);
		updateMostFrequentSequenceList();
		return mfps_ListOfTestCases;
	}
	
	/*
	 * @return aps_ListOfTestCases.
	 */
	public List<String> getAllPresentSequences(){
		prioritizationCriteria = APS;
		if(!isCopiesCreated)
			createCopiesOfSequencePropertiesObjList();
		sortSequences(copy_sequencePropertiesObjList);
		shuffle(copy_sequencePropertiesObjList);
		updateAllPresentSequenceList();
		return aps_ListOfTestCases;
	}
	
	/*
	 * @return wf_ListOfTestCases.
	 */
	public List<String> getWeightFrequencySequences(){
		prioritizationCriteria = WF;
		if(!isCopiesCreated)
			createCopiesOfSequencePropertiesObjList();
		updateWeightFrequencySequenceList();
		return wf_ListOfTestCases;
	}
	
	/*
	 * This method creates a copy of the SequencePropertiesObjList. This is required
	 * because in the MFPS case, the SequenceProperties objects are deleted sequentially
	 * from the sequenceProperiesObjList. Since the same list has to be used for APS and
	 * wf scenarios, a copy of the list have to be maintained.
	 */
	private void createCopiesOfSequencePropertiesObjList(){
		copy_sequencePropertiesObjList = new ArrayList<SequenceProperties>();
		
		for(SequenceProperties sequenceProperties:sequencePropertiesObjList){
			final SequenceProperties tempSequenceProperties = new SequenceProperties();
			tempSequenceProperties.setSequence(sequenceProperties.getSequence());
			for(Iterator iterator = sequenceProperties.getTestCaseFrequencyMapping().entrySet().iterator();iterator.hasNext();){
				 Map.Entry entry = (Map.Entry) iterator.next();
				 String testCase = (String)entry.getKey();
			     tempSequenceProperties.setTestCaseFrequencyMapping(testCase);
			}
			tempSequenceProperties.setTotalSequenceCount(sequenceProperties.getTotalSequenceCount());
			copy_sequencePropertiesObjList.add(tempSequenceProperties);
		}
		isCopiesCreated = true;
	}
	
	/*
	 * This method sorts the SequenceProperties Object list
	 *  in a descending order based on the total count of
	 *  sequence in the test suite.
	 */
	private void sortSequences(final ArrayList<SequenceProperties> tempSequencePropertiesObjList){
		Collections.sort(tempSequencePropertiesObjList, new DescendingOrderOfFrequencies());
		
	}

	/*
	 * If a testCase does not exist in the mfps_ListOfTestCases,
	 * it is added to list. This is the final order of test cases for the
	 * MFPS scenario.
	 */
	private void setMFPSListOfTestCases(final String testCase) {
		boolean isSessionExistsInList = mfps_ListOfTestCases.contains(testCase);
		if(!isSessionExistsInList){
			mfps_ListOfTestCases.add(testCase);
		}
		
	}
	
	/*
	 * If a testCase does not exist in the aps_ListOfTestCases,
	 * it is added to list. This is the final order of test cases for the
	 * APS scenario.
	 */
	private void setAPSListOfTestCases(final String testCase) {
		boolean isSessionExistsInList = aps_ListOfTestCases.contains(testCase);
		if(!isSessionExistsInList){
			aps_ListOfTestCases.add(testCase);
		}
		
	}
	
	/*
	 * If a testCase does not exist in the wf_ListOfTestCases,
	 * it is added to list. This is the final order of test cases for the
	 * wf scenario.
	 */
	private void setwfListOfTestCases(final String testCase) {
		boolean isSessionExistsInList = wf_ListOfTestCases.contains(testCase);
		if(!isSessionExistsInList){
			wf_ListOfTestCases.add(testCase);
		}
		
	}		
	
	/*
	 * This method adds the test cases in the "Most Frequently Present Sequence"
	 * List. 
	 */
	private void updateMostFrequentSequenceList(){
			while(mfps_ListOfTestCases.size()<numberOfTestCases){
			 SequenceProperties tempSequenceProperties = sequencePropertiesObjList.get(0);
			 System.out.println("Current MFPS: "+tempSequenceProperties.getSequence()+
					 			" Total Frequency: "+tempSequenceProperties.getTotalSequenceCount());
			 Map<String,Integer> sessionFrequencyMapping = 
				tempSequenceProperties.getTestCaseFrequencyMapping();
			 SortedSet<Map.Entry<String,Integer>> sortedTestCaseFrequencyMapping = 
		    	  sortTestCaseFrequencyMapping(sessionFrequencyMapping);
			 	/*
			 	 * If the map of test cases and local count only has one element, 
			 	 * it does not need any shuffling in random order. 
			 	 * The test case can directly be added to the final list.
			 	 * Else, the map must be checked for duplicates and the duplicates
			 	 * values must be shuffled in random order before making entries 
			 	 * in the final list.
			 	 */
			 if(sortedTestCaseFrequencyMapping.size()==1){
					 choosePrioritizationListAndMakeEntry(sortedTestCaseFrequencyMapping.first().getKey());
					 
			}else{
					 shuffle(sortedTestCaseFrequencyMapping);
			}
			 /*
			  * Once the test cases associated with the first object are added to the final list,
			  * the object is removed from the SequenceProperties object list,
			  * as these test cases are to be removed from consideration while calculating the 
			  * next MFPS.
			  */
		      sequencePropertiesObjList.remove(0);
		      ArrayList<String> tempSessionList = (ArrayList<String>)mfps_ListOfTestCases;
		      for(SequenceProperties sequenceProperties:sequencePropertiesObjList){
		    	  Map<String,Integer> tempSequenceProperties2 = sequenceProperties.getTestCaseFrequencyMapping();
		    	  for(String session:tempSessionList){
		    		  if(tempSequenceProperties2.containsKey(session)){
		    			  sequenceProperties.decrementTotalCount((Integer)tempSequenceProperties2.get(session));
		    			  tempSequenceProperties2.remove(session);
		    		  }
		    	  }
		      }
		      
		      /*
		       * Once the object and local mappings are removed, the list must be sorted and shuffled again 
		       * in order to determine the next MFPS.
		       */
		      sortSequences(sequencePropertiesObjList);
		      shuffle(sequencePropertiesObjList);
			}
	}
	
	
	/*
	 * This method adds the test cases in the "All Present Sequence"
	 * List. 
	 */
	private void updateAllPresentSequenceList(){
		final ArrayList<String> tempTestCaseList = new ArrayList<String>();
		for(int sortedListIndex=0;sortedListIndex<copy_sequencePropertiesObjList.size();sortedListIndex++){
			if(aps_ListOfTestCases.size()<numberOfTestCases){
		 SequenceProperties tempSequenceProperties = copy_sequencePropertiesObjList.get(sortedListIndex);
		 Map<String,Integer> sessionFrequencyMapping = 
			tempSequenceProperties.getTestCaseFrequencyMapping();
		 SortedSet<Map.Entry<String,Integer>> sortedTestCaseFrequencyMapping = 
	    	  sortTestCaseFrequencyMapping(sessionFrequencyMapping);
		 	/*
		 	 * If the map of test cases and local count only has one element, 
		 	 * it does not need any shuffling in random order. 
		 	 * The test case can directly be added to the final list.
		 	 * Else, the map must be checked for duplicates and the duplicates
		 	 * values must be shuffled in random order before making entries 
		 	 * in the final list.
		 	 */
			if(sortedTestCaseFrequencyMapping.size()==1){
				 choosePrioritizationListAndMakeEntry(sortedTestCaseFrequencyMapping.first().getKey());
			}else{
				 shuffle(sortedTestCaseFrequencyMapping);
			 }
	      }else{
	    	  return;
	      }
	     
		}
		/*
		 * In case of APS, all test cases that do not have maximum local counts,
		 * must be shuffled in a random order before adding them in the final 
		 * list.
		 */
		if((aps_ListOfTestCases.size()<numberOfTestCases)){
			for(int sortedListIndex=0;sortedListIndex<allTestCases.size();sortedListIndex++){
				final String testCase = allTestCases.get(sortedListIndex);
			    	  if(!aps_ListOfTestCases.contains(testCase))
			    	  tempTestCaseList.add(testCase);
			    	  
				 
			}
			Collections.shuffle(tempTestCaseList);
			for(String testCase: tempTestCaseList){
				setAPSListOfTestCases(testCase);
			}
		}
	}
	
	
	/*
	 * This method adds the test cases in the "Weight Frequency Sequence"
	 * List. 
	 */
	private void updateWeightFrequencySequenceList(){
		int tempTotalSequenceCount = 0;
		Map<String, Integer> tempSessionFrequencyMapping = null;
		int tempWeight = 0;
		/*
		 * The sequencePropertiesObjList is iterated through, the test case frequency mapping
		 *  is obtained for each object, the local count of each test case is multiplied with
		 *  that total count of that session for that object. For a sequence, this is the weight
		 *  for a particular test case. The test case along with its current weight is updated in
		 *  a mapping of test case and weight.
		 */
		
		for(SequenceProperties sequenceProperties:copy_sequencePropertiesObjList){
			tempTotalSequenceCount = sequenceProperties.getTotalSequenceCount();
			tempSessionFrequencyMapping = sequenceProperties.getTestCaseFrequencyMapping();
			

			for(Iterator iterator = tempSessionFrequencyMapping.entrySet().iterator();iterator.hasNext();){
				 Map.Entry entry = (Map.Entry) iterator.next();
				 String testCase = (String)entry.getKey();
			      Integer localCount = (Integer)entry.getValue();
			      tempWeight = localCount * tempTotalSequenceCount;
			      
			      updateTestCaseWeightMapping(testCase, tempWeight);
			}
		}
		/*
		 * Once the test case weight mapping is created, the mapping is sorted based on its 
		 * weight values.
		 */
		SortedSet<Map.Entry<String,Integer>> sortedTestCaseFrequencyMapping = sortTestCaseFrequencyMapping(testCaseWeightMapping);
		
	 	/*
	 	 * If the map of test cases and local count only has one element, 
	 	 * it does not need any shuffling in random order. 
	 	 * The test case can directly be added to the final list.
	 	 * Else, the map must be checked for duplicates and the duplicates
	 	 * values must be shuffled in random order before making entries 
	 	 * in the final list.
	 	 */
		if(sortedTestCaseFrequencyMapping.size()==1){
			choosePrioritizationListAndMakeEntry(sortedTestCaseFrequencyMapping.first().getKey());
		 }else{
			 shuffle(sortedTestCaseFrequencyMapping);
		 }
		 
	}
	
	/*
	 * This method is used for printing the test case frequency mapping 
	 * before the sorting of the SequenceProperties object list is done
	 * based on the total counts of the sequences in the test suite.
	 * USED FOR TESTING.
	 */
	public void printUnsortedSequenceTestCaseMap(){
		for(int sortedListIndex=0;sortedListIndex<sequencePropertiesObjList.size();sortedListIndex++){
			 SequenceProperties tempSequenceProperties = sequencePropertiesObjList.get(sortedListIndex);
			 System.out.println("Sequence pattern:  Test cases: "+
					 tempSequenceProperties.getTestCaseFrequencyMapping()+" number "+tempSequenceProperties.getTotalSequenceCount()
					 +" sequence "+tempSequenceProperties.getSequence());
		 }
	}
	
	
	
	/*
	 * This method is used for printing the test case frequency mapping 
	 * after the sorting of the SequenceProperties object list is done
	 * based on the total counts of the sequences in the test suite.
	 * USED FOR TESTING.
	 */
	public void printSortedSequenceTestCaseMap(){
		 sortSequences(sequencePropertiesObjList);
		 for(int sortedListIndex=0;sortedListIndex<sequencePropertiesObjList.size();sortedListIndex++){
			 SequenceProperties tempSequenceProperties = sequencePropertiesObjList.get(sortedListIndex);
			 
			 System.out.println("Sorted Sequence pattern:  Test cases: "+
					 tempSequenceProperties.getTestCaseFrequencyMapping()+" number "+tempSequenceProperties.getTotalSequenceCount()
					 +" sequence "+tempSequenceProperties.getSequence());
		 }
	}
	/*
	 * This method is used for printing the values obtained
	 *  after sorting the test case frequency mapping.
	 * USED FOR TESTING.
	 */
	public void printTestCaseFrequencyMapping(){
		//sortSequences();
		for(int sortedListIndex=0;sortedListIndex<sequencePropertiesObjList.size();sortedListIndex++){
			 SequenceProperties tempSequenceProperties = sequencePropertiesObjList.get(sortedListIndex);
			 
			Map<String,Integer> sessionFrequencyMapping = 
				tempSequenceProperties.getTestCaseFrequencyMapping();
			 for(Iterator iterator = sessionFrequencyMapping.entrySet().iterator();iterator.hasNext();){
				 Map.Entry entry = (Map.Entry) iterator.next();
			      SortedSet<Map.Entry<String,Integer>> sortedSessionFrequencyMapping = 
			    	  sortTestCaseFrequencyMapping(sessionFrequencyMapping);
			      Iterator iterator2 = sortedSessionFrequencyMapping.iterator();
			      while(iterator2.hasNext()){
			    	  Map.Entry<String, Integer> entry2 = (Map.Entry) iterator2.next();
				      String key2 = (String)entry2.getKey();
				      Integer value2 = (Integer)entry2.getValue();
				      System.out.println("Sorted Sequence "+tempSequenceProperties.getSequence()+
				    		  " Session: "+key2+" Frequency "+value2+" Total number of Instances "+tempSequenceProperties.getTotalSequenceCount());
				      
			      }
				}
		 }
	}
	
	/*
	 * This method is used for printing the results of the MFPS.
	 * USED FOR TESTING.
	 */
	public void printMostFrequentSessionList(){
		List<String> mostFrequentSessionList = mfps_ListOfTestCases;
		for(int i = 0;i<mostFrequentSessionList.size();i++){
			System.out.println("Session "+mostFrequentSessionList.get(i));
		}
	}
	
	/*
	 * This method returns the sequence and local count mapping in a 
	 * descending order.
	 * @param The unsorted sequenceFrequencyMapping.
	 * @return The sorted set of the sequenceFrequencyMapping.
	 */
	private SortedSet<Map.Entry<String,Integer>> sortTestCaseFrequencyMapping(final Map<String, Integer> sequenceFrequencyMapping){
		Comparator<Map.Entry<String,Integer>> comparator = new Comparator<Map.Entry<String,Integer>>()  
		{  
		    public int compare(Map.Entry<String,Integer> entry1, Map.Entry<String,Integer> entry2)  
		    {  
		    	 int diff = entry2.getValue().compareTo(entry1.getValue());  
		    	    if (diff == 0)  
		    	    {  
		    	        diff = entry2.getKey().compareTo(entry1.getKey());  
		    	    }  
		    	    return diff; 
		    }  
		};  
		SortedSet<Map.Entry<String,Integer>> sortedSequences = new TreeSet<Map.Entry<String,Integer>>(comparator);  
		sortedSequences.addAll(sequenceFrequencyMapping.entrySet());
		return sortedSequences;
	}
	
	/*
	 * This method updates testCaseWeightMapping.
	 * If the test case exists in the mapping, the weight is added to its current weight.
	 * else if the test case does not exist in the mapping, the test case is added into
	 * the mapping along with the weight as the value.
	 */
	private void updateTestCaseWeightMapping(final String testCase, final int weight){
		if(testCaseWeightMapping.containsKey(testCase)){
			testCaseWeightMapping.put( testCase, testCaseWeightMapping.get( testCase ) + weight );
		}else{
			testCaseWeightMapping.put(testCase, weight);
		}
	}
	
    /*
     * This method sorts the list of sequence properties objects that have the same total frequency
     * count, in a random manner.
     */
	private void shuffle(final ArrayList<SequenceProperties> localSequencePropertiesList){
		int tempValue = 0;
		ArrayList<SequenceProperties> tempSequencePropertiesObjList = new ArrayList<SequenceProperties>();
		ArrayList<SequenceProperties> tempSequencePropertiesObjList2 = new ArrayList<SequenceProperties>();
		 
		 for(int index = 0;index<localSequencePropertiesList.size();index++){
			 		SequenceProperties tempSequenceProperties = localSequencePropertiesList.get(index);
			 		int totalFrequency = tempSequenceProperties.getTotalSequenceCount();
		    	  if(index==0){
		    		  tempValue = totalFrequency;
		    		  tempSequencePropertiesObjList.add(tempSequenceProperties);
		    	  }else{
		    		  if(totalFrequency==tempValue){
			    			  tempSequencePropertiesObjList.add(tempSequenceProperties);
			    			  if(index==(localSequencePropertiesList.size()-1)){
			    				  Collections.shuffle(tempSequencePropertiesObjList);
			    				  tempSequencePropertiesObjList2.addAll(tempSequencePropertiesObjList);
				    			  tempSequencePropertiesObjList.clear();
			    			  }
		    		  }else{
			    			  Collections.shuffle(tempSequencePropertiesObjList);
			    			  tempSequencePropertiesObjList2.addAll(tempSequencePropertiesObjList);
			    			  tempSequencePropertiesObjList.clear();
			    			  if(prioritizationCriteria.equalsIgnoreCase(MFPS)){
			    				  return;
			    			  }
			    			  if(index!=(localSequencePropertiesList.size()-1)){
			    				  tempValue = totalFrequency;
				    			  tempSequencePropertiesObjList.add(tempSequenceProperties);
			    			  }else{
			    				  tempSequencePropertiesObjList2.add(tempSequenceProperties);
			    			  }
			    			 
		    		  		}
		    	  }
		 }
		 localSequencePropertiesList.clear();
		 localSequencePropertiesList.addAll(tempSequencePropertiesObjList2);

	}
		    	  
	 /*
     * This method sorts the map of test cases that have the same local frequency
     * count, in a random manner.
     * @param Map of test case and local count in a SequencePropeties Object.
     */
	private void shuffle(final SortedSet<Map.Entry<String,Integer>> sortedTestCaseFrequencyMapping){
		int tempValue = 0;
		int count = 0;
		ArrayList<String> tempTestCaseList = new ArrayList<String>();
			
		for(Map.Entry<String, Integer> entry : sortedTestCaseFrequencyMapping){
		    	  String key = (String)entry.getKey();
		    	  int value = (Integer)entry.getValue();
		    	  if(count==0){
		    		  tempValue = value;
		    		  tempTestCaseList.add(key);
		    	  }else{

		    		  if(value==tempValue){
			    			  tempTestCaseList.add(key);
			    			  if(count==(sortedTestCaseFrequencyMapping.size()-1)){
			    				  Collections.shuffle(tempTestCaseList);
			    				  for(String testCase:tempTestCaseList){
			    					  choosePrioritizationListAndMakeEntry(testCase);
			    				  }
			    				 tempTestCaseList.clear();
			    			  }
		    		  }else{
			    			  Collections.shuffle(tempTestCaseList);
			    			  for(String testCase:tempTestCaseList){
			    				  choosePrioritizationListAndMakeEntry(testCase);
			    			  }
			    			  tempTestCaseList.clear();
			    			  if(prioritizationCriteria.equalsIgnoreCase(APS)){
			    				  return;
			    			  }
			    			  if(count!=(sortedTestCaseFrequencyMapping.size()-1)){
			    				  tempValue = value;
			    				  tempTestCaseList.add(key);
			    			  }else{
			    				  choosePrioritizationListAndMakeEntry(key);
			    			  }
			    		  }
		    	  }
		    	  count++;
		      }
		      count=0;		 
	}	    
	
	/*
	 * This method makes a choice based on the prioritizationCriteria value
	 * and makes an entry of the testCase in either of MFPS, APS and wf lists.
	 * @param testCase.
	 */
	private void choosePrioritizationListAndMakeEntry(final String testCase){
		if(prioritizationCriteria.equalsIgnoreCase(MFPS)){
			setMFPSListOfTestCases(testCase);
		}else if(prioritizationCriteria.equalsIgnoreCase(APS)){
			setAPSListOfTestCases(testCase);
		}else if(prioritizationCriteria.equalsIgnoreCase(WF)){
			setwfListOfTestCases(testCase);
		}
	}
	/*
	 * @author Nilesh
	 * This inner class orders SequenceProperties objects in the
	 *  descending order of their total sequence count.
	 */
	class DescendingOrderOfFrequencies implements Comparator<SequenceProperties>{
		@Override
		public int compare(SequenceProperties sequenceProperties1, SequenceProperties sequenceProperties2) {
			
			int comparison = ((Integer)sequenceProperties2.getTotalSequenceCount()).compareTo((Integer)sequenceProperties1.getTotalSequenceCount());
			return comparison;
		}		
	}
}
