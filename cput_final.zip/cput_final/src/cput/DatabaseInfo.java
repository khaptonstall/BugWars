/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cput;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Class that contains all of the necessary database connection info.  An instance
 * of this class is retained in memory during program runtime so the user only needs
 * to input their information once.  It is primarily utilized by the code that writes
 * the XML test cases.
 * @author Devin Minson & Schuyler Manchester
 */
public class DatabaseInfo {
    //private class members
    private String hostname;
    private String database;
    private String username;
    private String pword;
    private int port;
    private boolean hasUniqueUrls;
    private String[] parameters;
    private int numParameters;
    private dbWriteMethod writeMethod;

    /**
     * 
     */
    public enum dbWriteMethod {
        /**
         *
         */
        createNew,
        /**
         *
         */
        append,
        /**
         * 
         */
        overwrite
    };

    /**
     *
     * @param hostname
     * @param username
     * @param password
     * @param port
     */
    public DatabaseInfo(String hostname, String username, String password, int port){
        this.hostname = hostname;
        this.username = username;
        this.pword = password;
        this.port = port;
    }

    /**
     *
     * @param value
     */
    public void setHostname(String value){
        this.hostname = value;
    }

    /**
     *
     * @param value
     */
    
    // SRJ: converted the databaseName string to lower case.
    
    public void setDatabase(String value){
        this.database = value.toLowerCase();
    }

    /**
     *
     * @param value
     */
    public void setUsername(String value){
        this.username = value;
    }

    /**
     *
     * @param value
     */
    public void setPword(String value){
        this.pword = value;
    }

    /**
     *
     * @param value
     */
    public void setPort(int value){
        this.port = value;
    }

    /**
     *
     * @param value
     */
    public void setWriteMethod(dbWriteMethod value){
        this.writeMethod = value;
    }

    /**
     *
     * @param value
     */
    public void setHasUniqueUrls(boolean value){
        this.hasUniqueUrls = value;
    }

    /**
     *
     * @param value
     */
    public void setParameters(String value){
        String delimiters = "[,]";
        this.parameters = value.split(delimiters);
        if(value.isEmpty())
            this.numParameters = 0;
        else
            this.numParameters = this.parameters.length;
    }

    /**
     *
     * @param value
     */
    public void setParameters(String[] tokens){
        this.parameters = tokens;
        this.numParameters = this.parameters.length;
    }

    /**
     *
     * @return
     */
    public String getHostname(){
        return this.hostname;
    }

    /**
     *
     * @return
     */
    public String getDatabase(){
        return this.database;
    }

    /**
     *
     * @return
     */
    public String getUsername(){
        return this.username;
    }

    /**
     *
     * @return
     */
    public String getPword(){
        return this.pword;
    }

    /**
     *
     * @return
     */
    public int getPort(){
        return this.port;
    }

    /**
     *
     * @return
     */
    public dbWriteMethod getWriteMethod(){
        return this.writeMethod;
    }

    /**
     *
     * @param value
     */
    public boolean getHasUniqueUrls(){
        return this.hasUniqueUrls;
    }

    /**
     *
     * @param value
     */
    public String[] getParameters(){
        return this.parameters;
    }

    public int getNumParameters(){
        return this.numParameters;
    }

    /**
     * This function is used to get the list of all databases.
     * @param con The connection to database from which we need to get the list of database.
     * @return The array of string which is initialized with the list of database.
     */
    protected String[] getDBList(Connection con)
    {
        String dbName = "";
        Statement stmt;
        ResultSet results = null;
        String queryText = null;
         //The query to get information from postgres metadata table.
        //Select database names from cput_database_info table that also exist in the pg_database table (this is the table maintained by postgres),
        //such that the rows have the 'N' flag set. This retrieves all database names that are active.
        queryText = "SELECT DISTINCT datname dbname FROM pg_database, cput_database_info WHERE datname = dbname AND dropdbflag = 'N' ORDER BY 1;";
        try {
            stmt = con.createStatement();
            results = stmt.executeQuery(queryText);
            } catch (SQLException e) {
            System.out.println("Unable to create statement");
            e.printStackTrace();
        }
        if (results != null) {
            try {
                while(results.next())
                    dbName = dbName + results.getString("dbname")+ ",";
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        try {
            results.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        String[] dbList = dbName.split(",");
        return dbList;
    }     
}
