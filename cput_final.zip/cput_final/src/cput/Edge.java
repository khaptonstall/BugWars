/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cput;
import java.util.LinkedList;
/**
 *
 * @author Chelynn
 */
public abstract class Edge {
    private int connectedVertex;
    private boolean isCovered;

    public Edge(int cV){
        connectedVertex = cV;
        isCovered = false;
    }
    
    public boolean isCovered(){
        return isCovered;
    }
    
    public int getConnectedVertex(){
        return connectedVertex;
    }
    
    public void setCoverage(boolean covered){
        isCovered = covered;
    }
    
    public abstract LinkedList<TestCase> getApplicableTestCases(TestCase.ReductionValue reduction);
}
