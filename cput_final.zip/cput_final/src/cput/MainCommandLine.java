/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cput;

import java.io.File;
import java.io.PrintStream;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import javax.swing.DefaultListModel;

import org.apache.log4j.Logger;
/**
 *
 * @author Schuyler Manchester
 */
public class MainCommandLine {
    private DatabaseInfo _dbInfo;
    private String _weblogPath;
    private String _postgresHostName;
    private int _postgresPort;
    private String _postgresUsername;
    private String _postgresPassword;
    private boolean _hasUniqueURLS;
    private String[] _URLparams;
    private String _dbWriteMethod;
    private String _dbName;
    private String _prioritization;
    private String _exportFileName;
    private boolean _hasReduction;


    Logger _logger = Logger.getLogger(MainScreen.class);
    private DefaultListModel _testCaseOrder;
    private TestCase.PrioritizationValue _selection;
    private Validate _validater;
    private Project1 _parser;
    protected File _selectedXmlFile;
    private LogPrioritizer _prioritizer;
    /**
     * Constructor
     * @param args
     */
    public MainCommandLine(String[] args) {
        _validater = new Validate();
        _testCaseOrder = new DefaultListModel();
        _hasReduction = false;
        StartCommandLine(args);
    }
    /**
     * Primary running function for Command Line Interface that will call all subroutines 
     * @param args
     */
    private void StartCommandLine(String[] args){
        //Open Existing Test Suite
        if(args.length > 0 && args[0].equals("-openTestSuite")){
            OpenExistingTestSuiteArguments(args);
        }
        else if(args.length > 0 && args[0].equals("-startNewSession")){
            StartNewSessionArguments(args);
            ConnectToHost();
            SetupDatabase();
            ParseLog();
        }
        else{
            System.out.println("Invalid Script: the first flag must be either '-openTestSuite' or '-startNewSession'");
            System.exit(1);
        }
        ReadXml();
        PrioritizeTechnique();
        SetPrioritizedList();
        ExportPrioritizedList();
    }

    /**
     * Parses necessary arguments for Opening an Existing Test Suite
     * @param args
     */
    private void OpenExistingTestSuiteArguments(String[] args){
        int argIndex = 1; //Incremented after each argument is handled
        String[] tempArray;//used to assist in parsing of arguments
        if(args.length < 4){
            System.out.println("Invalid Script: when opening an existing suite make sure all 4 arguments were passed with script.");
            System.exit(1);
        }
        //First flag test suite path
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-testSuiteFile") && tempArray.length > 1){
            _selectedXmlFile = new File(tempArray[1]);
            System.out.println("Test Suite Path: " + tempArray[1]);
        }
        else{
            System.out.println("Invalid Script: Make sure first flag is '-testSuiteFile' with specified file path.");
            System.exit(1);
        }
        argIndex++;

        //Second flag prioritization technique
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-prioTech") && tempArray.length > 1){
            _prioritization = tempArray[1];
            System.out.println("Prioritization Technique: " + _prioritization);
        }
        else{
            System.out.println("Invalid Script: Make sure second flag is '-prioTech' with specified prioritization technique.");
            System.exit(1);
        }
        argIndex++;

        //Third flag Prioritization Order File Path
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-outputOrderFilePath") && tempArray.length > 1){
            _exportFileName = tempArray[1];
            if(tempArray[1].endsWith(".txt")) //User entered valid txt file
                System.out.println("Prioritization Output Path: " + _exportFileName + "\n");
            else{
                System.out.println("Invalid Script: Make sure '-outputOrderFilePath' file ends with a .txt");
                System.exit(1);
            }
        }
        else{
            System.out.println("Invalid Script: Make sure flag is '-outputOrderFilePath' with specified output path.");
            System.exit(1);
        }
    }

    /**
     * Parses necessary arguments for Starting a New Session
     * @param args
     */
    private void StartNewSessionArguments(String[] args){
        String portInput;
        int argIndex = 1; //increment after each argument has been handled
        String[] tempArray;//used to assist in parsing of arguments
        if(args.length < 11){
            System.out.println("Invalid Script: when starting a new session make sure all 11 arguments are passed with script.");
            System.exit(1);
        }
        //First flag Postgres Host Name
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-postgresHostName") && tempArray.length > 1){
            _postgresHostName = tempArray[1];
            System.out.println("\nHost Name: " + _postgresHostName);
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-postgresHostName' with specified host name.");
            System.exit(1);
        }
        argIndex++;

        //Second flag Postgres Username
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-postgresUser") && tempArray.length > 1){
            _postgresUsername = tempArray[1];
            System.out.println("Username: " + _postgresUsername);
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-postgresUser' with specified username.");
            System.exit(1);
        }
        argIndex++;

        //Third flag Postgres Password
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-postgresPass") && tempArray.length > 1){
            _postgresPassword = tempArray[1];
            System.out.println("Password Entered.");
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-postgresPass' with specified password.");
            System.exit(1);
        }
        argIndex++;

        //Fourth flag Postgres Port
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-postgresPort") && tempArray.length > 1){
            portInput = tempArray[1];
            try
            {
                _postgresPort = Integer.parseInt(portInput);
            }
            catch (NumberFormatException ex) {
                System.out.println("Invalid Script: Please enter a valid number for the port.");
                System.exit(1);
            }
            System.out.println("Port: " + _postgresPort);

        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-postgresPort' with specified port.");
            System.exit(1);
        }
        argIndex++;

        //Fifth flag URL specification
        tempArray = args[argIndex].split("[,]");
        if(tempArray[0].equals("-uniqueURL")){
            _hasUniqueURLS = true;
            System.out.println("Unique URL");
        }
        else if(tempArray[0].equals("-nonUniqueURL")){
            if(tempArray.length > 1){
            _hasUniqueURLS = false;
            _URLparams = Arrays.copyOfRange(tempArray, 1, tempArray.length);
            System.out.print("Non-Unique URL with parameters: ");
            for(int i = 0; i < _URLparams.length; i ++){
                System.out.print(_URLparams[i] + " ");
            }
            System.out.println("");
            }
            else{
                System.out.println("Invalid Script: Make sure when specifying '-nonUniqueURL' you pass at least 1 parameter. Ex: -nonUniqueURL,page");
                System.exit(1);
            }
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is either '-uniqueURL' or '-nonUniqueURL'");
            System.exit(1);
        }
        argIndex++;

        //Fifth flag DB write method
        if(args[argIndex].equals("-newdb") || args[argIndex].equals("-overwritedb") || args[argIndex].equals("-appenddb")){
            _dbWriteMethod = args[argIndex].substring(1);
            System.out.println("DB Write Method: " + _dbWriteMethod);
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is either '-newdb' '-appenddb' or 'overwritedb'");
            System.exit(1);
        }
        argIndex++;

        //sixth flag Postgres DB Name
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-dbName") && tempArray.length > 1){
            _dbName = tempArray[1];
            System.out.println("DB Name: " + _dbName);
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-dbName' with specified database name.");
            System.exit(1);
        }
        argIndex++;

        //Seventh flag Web Log File Name
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-logFileName") && tempArray.length > 1){
            _weblogPath = tempArray[1];
            System.out.println("Log File Path: " + _weblogPath);
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-logFileName' with specified log file name.");
            System.exit(1);
        }
        argIndex++;

        //Eighth flag Prioritization Technique
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-prioTech") && tempArray.length > 1){
            _prioritization = tempArray[1];
            System.out.println("Prioritization Technique: " + _prioritization);
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-priotech'  with specified prioritization technique.");
            System.exit(1);
        }
        argIndex++;

        //Tenth flag Prioritization Order File Path
        tempArray = args[argIndex].split("=");
        if(tempArray[0].equals("-outputOrderFilePath") && tempArray.length > 1){
            _exportFileName = tempArray[1];
            if(tempArray[1].endsWith(".txt")) //User entered valid txt file
                System.out.println("Prioritization Output Path: " + _exportFileName + "\n");
            else{
                System.out.println("Invalid Script: Make sure '-outputOrderFilePath' file ends with a .txt");
                System.exit(1);
            }
        }
        else{
            System.out.println("Invalid Script: Make sure flag " + (argIndex + 1) + " is '-outputOrderFilePath' with specified output path.");
            System.exit(1);
        }
        argIndex++;
    }

    /**
     * Connect to Database Host
     */
    private void ConnectToHost(){
        Connection con = null;
        Log mylog = new Log(_postgresHostName, _postgresPort);
        con = mylog.setConnection("postgres", _postgresUsername, _postgresPassword);
        if(con == null)
        {
            System.out.println("Invalid Script: Make sure to enter correct DB login credentials");
            System.exit(1);
        }
    	else
    	{
            _dbInfo = new DatabaseInfo(_postgresHostName, _postgresUsername, _postgresPassword, _postgresPort);
        }
    }

    /**
     * Setup Database Info
     */
    private void SetupDatabase(){
        //Validate DB Name
        if(!_validater.validateDBName(_dbName)){
            System.out.println("Invalid Script: Invalid DB Name");
            System.exit(1);
        }
        //Set Write Method
        if(_dbWriteMethod.equals("newdb")){
            _dbInfo.setWriteMethod(DatabaseInfo.dbWriteMethod.createNew);
        }
        else if(_dbWriteMethod.equals("appenddb")){
            _dbInfo.setWriteMethod(DatabaseInfo.dbWriteMethod.append);
        }
        else if(_dbWriteMethod.equals("overwritedb")){
            _dbInfo.setWriteMethod(DatabaseInfo.dbWriteMethod.overwrite);
        }
        else{
            System.out.println("Invalid Script: Make sure DB Write Method is either '-newdb' '-appenddb' or 'overwritedb'");
            System.exit(1);
        }
        _dbInfo.setDatabase(_dbName);
    }

    /**
     * Parses Raw Web Log into individual XML files (one per session) and one main xml file containing all sessions
     */
    private void ParseLog(){
        _dbInfo.setHasUniqueUrls(_hasUniqueURLS);
        if(!_hasUniqueURLS)
            _dbInfo.setParameters(_URLparams);
        System.out.println("Parsing Weblog...");
        _parser = new Project1(_dbInfo, _weblogPath, _logger);
        if (_parser == null || _parser.getXMLFilePath() == "") {
            System.out.println("\nError parsing weblog, please try again.");
            System.exit(1);
        } else {
            _selectedXmlFile = new File(_parser.getXMLFilePath());
        }
    }

    /**
     * Reads XML File generated by web log parser and gathers information and statistics
     */
    private void ReadXml(){
        _prioritizer = new LogPrioritizer();
        System.out.println("Reading Xml file...");
        _prioritizer.readXMLFile(_selectedXmlFile);
    }

    /**
     * Currently 7 different techniques : (2way, length, numParam, rand, mfps, aps and wf)
     */
    private void PrioritizeTechnique(){
        if(_prioritization.equals("2way")){
            _selection = TestCase.PrioritizationValue.TwoWay;
            _hasReduction = false;
            if(_hasUniqueURLS){
                System.out.println("Prioritizing by 2-way Coverage - Unique URLS");
            }
            else{
                System.out.println("Prioritizing by 2-way Coverage - Non-Unique URLs");
            }
        }
        else if(_prioritization.equals("2wayReduce")){
            _selection = TestCase.PrioritizationValue.TwoWay;
            _hasReduction = true;
            if(_hasUniqueURLS){
                System.out.println("Prioritizing by 2-way Coverage - Unique URLS");
            }
            else{
                System.out.println("Prioritizing by 2-way Coverage - Non-Unique URLs");
            }
        }
        else if(_prioritization.equals("length")){
            _selection = TestCase.PrioritizationValue.Length;
            System.out.println("Prioritizing by Length (Number of GETS/POSTS)");
        }
        else if(_prioritization.equals("numParam")){
            _selection = TestCase.PrioritizationValue.Params;
            System.out.println("Prioritizing by Number of Parameters");
        }
        else if(_prioritization.equals("rand")){
            _selection = TestCase.PrioritizationValue.Random;
            System.out.println("Prioritizing by Random");
        }else if (_prioritization.equalsIgnoreCase("mfps")) {
            _selection = TestCase.PrioritizationValue.MFPS;
            System.out.println("Prioritizing by MFPS Frequency");
        } else if (_prioritization.equalsIgnoreCase("aps")) {
            _selection = TestCase.PrioritizationValue.APS;
            System.out.println("Prioritizing by APS Frequency");
        } else if (_prioritization.equalsIgnoreCase("wf")) {
        	_selection = TestCase.PrioritizationValue.WF;
            System.out.println("Prioritizing by wf Frequency");
        }
        else{
            System.out.println(
            		"Invalid Prioritization: the requested prioritization must be either" +
            		" '2way' '2wayReduce' 'length' 'numParam' 'rand' 'mfps' 'aps' or 'wf'");
            System.exit(1);
        }
        _prioritizer.prioritize(_selection);
    }

    /**
     * Sets up Prioritization list based on requested prioritization technique
     */
    private void SetPrioritizedList(){
        int numSessions = 0;
        if(_hasReduction){
            for (int i = 0; i < _prioritizer.webList.size(); i++) {
                int selected = _prioritizer.getParentIndex(i);
                if(_prioritizer.webList.get(selected).getTwoWay(_prioritizer.getReductionType()) > 1){
                    _testCaseOrder.add(i, _prioritizer.getID(i));
                    numSessions++;
                }
            }
        }
        else{
            numSessions = _prioritizer.webList.size();
            for (int i = 0; i < _prioritizer.webList.size(); i++) {
                _testCaseOrder.add(i, _prioritizer.getID(i));
            }
        }
        NumberFormat formatter = new DecimalFormat("#0.00");
        System.out.println("\nTotal Sessions: " + numSessions);
        System.out.println("Total URLs: " + _prioritizer.getTotalURLs());
        System.out.println("Average Length(Gets/Posts): " + formatter.format(_prioritizer.getTotalLength() / (double) numSessions));
        System.out.println("Average # of Params: " + formatter.format(_prioritizer.getTotalParams() / (double) numSessions));
    }

    /**
     * Exports prioritization order to the same directory as Parsed Test Suite
     */
    private void ExportPrioritizedList(){
        System.out.println("Exporting Prioritized Order to: " + _exportFileName);
        File exportFile = new File(_exportFileName);
        PrintStream write; // declare a print stream object
        try {
            write = new PrintStream(exportFile);
            write.println(_selection.toString());
            for (int i = 0; i < _testCaseOrder.getSize(); i++) {
                Object item = _testCaseOrder.getElementAt(i);
                write.println(item);
            }
            write.close();
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }
    }
}
