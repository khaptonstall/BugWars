package cput;

/**
 * This class encapsulates the ID of a test case and it
 * index relative to the original ordering of the Test Suite.
 * This was necessary because after a Test Suite has been ordered,
 * only the IDs are stored for that ordering (to preserve space).
 * However, in order to display the contents of that case, the original
 * index is needed.
 * @author Devin Minson & Schuyler Manchester
 */
public class OrderedListItem {
    private int origIndex;
    private String ID;
    
    /**
     *
     * @param origIndex
     * @param ID
     */
    public OrderedListItem(int origIndex, String ID){
        this.ID = ID;
        this.origIndex = origIndex;
    }
    
    /**
     *
     * @return
     */
    public String getID(){
        return ID;
    }
    
    /**
     *
     * @return
     */
    public int getIndex(){
        return this.origIndex;
    }
}
