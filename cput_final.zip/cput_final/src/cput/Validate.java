package cput;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

public class Validate 
{
    static String defaultDateFormat = "EEE MMM dd HH:mm:ss yyyy"; //format of date against which raw web log file first line date will be checked
    static int maxLogSizeMB = 50;
    Logger logger = Logger.getLogger(Validate.class);
    /**
     *
     * @param logger
     */

    public Validate(){

    }
    public Validate(Logger logger) {
        this.logger = logger;
    }
	
    boolean fileExists(String path) {
        File f = new File(path);
        if(f.exists())
            return true;
        else
            return false;
    }

    /**
     * Function to check if file provided is valid file format or not
     * @param path The path of the log file which user provided
     * @return True if file is valid file format and false if not
     */
    @SuppressWarnings("deprecation")
    public boolean validateFileFormat(String path) {
        FileInputStream myLogFile = null;
        try {
            myLogFile = new FileInputStream(path);
        }
        catch (FileNotFoundException e1) {
            logger.error("File not Found");
            logger.error(e1);
            System.exit(0);
        }
        DataInputStream current = new DataInputStream(new BufferedInputStream(myLogFile));
		
        String line;
        //reading the first line of web log file
        //check for valid date format
        try {
            while((line = current.readLine()) != null) {
                String []logFileLineArray1 = new String[10192];
                logFileLineArray1 = line.split("]#");
                logger.debug("The first log line: "+ line);
                String timeStamp = logFileLineArray1[0].replace("[", "").replace("]", "");
					
                //If date format is valid, check for host and then method. Else return false
                if(isValidDate(timeStamp)) {
						
                    //Get the host IP, split it into 4 parts and check if each part is between 0-255
                    //return false if any part is greater than 255, else check for valid method.
                    if(isValidIpAddress(logFileLineArray1[1].replace(" ", ""))) {
                        //Get the HTTP Request method, and check if its any of valid method format.
                        String method = logFileLineArray1[2];
                        if(method.contains("GET")||method.contains("PUT")||method.contains("POST")||method.contains("HEAD"))
                            return true;
                        else
                            logger.error("Not a valid method "+method);
                    }
                    else
                        logger.error("Not a valid ip format");
                }
                else {
                    logger.error("Not a valid date format");
                    return false;
                }
            }
        }
        catch (IOException e) {
            logger.error("Problem in reading the file");
            logger.error(e);
        }
        return true;
    } // End of function validateFileFormat
	
    /**
     * Function to check if valid IP address is in web log file. Allowed format is
     * an IP address between 0.0.0.0 and 255.255.255.255
     * @param hostIP
     * @return
     */
    private boolean isValidIpAddress(String hostIP) {
        String [] iPparts = hostIP.split ("\\.");
        for (String s : iPparts) {
            int i = Integer.parseInt (s);
            if (i < 0 || i > 255)
                return false;
        }
        return true;
    }// End of function idValidIpAddress
	  
    /**
     * Function to check if date in log file is same as expected date format specified as static variable
     * @param inDate
     * @return
     */
    private boolean isValidDate(String inDate) {
        if (inDate == null)
            return false;

        //set the format to use as a constructor argument
        SimpleDateFormat dateFormat = new SimpleDateFormat(defaultDateFormat);
	    
        if (inDate.trim().length() != dateFormat.toPattern().length())
            return false;

        dateFormat.setLenient(false);
	    
        try {
            dateFormat.parse(inDate.trim());
        }
        catch (ParseException pe) {
              return false;
        }
        return true;
    }// End of function isValidDate

    /**
     * Takes path to TestCases directory and deletes all files starting with 1 and ending with .XML.
     * These are files that contain each individual XML test case.
     * @param dirPath path to TestCases directory
     * @return
     * @throws IllegalArgumentException
     */
    public boolean deleteFilesFromDir(String dirPath) throws IllegalArgumentException {
        File folder = new File(dirPath);
        File[] listOfFiles = folder.listFiles();
        logger.debug("in delete function "+dirPath);
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {    //Just check for files, we do not want to delete any directory
                String fileName = listOfFiles[i].getName();
                File file = new File(dirPath + fileName);
                if(fileName.startsWith("1")&&fileName.endsWith(".XML") && fileName.length() == 11) {
                    if (!file.canWrite()) {
                        logger.error("No write permissions on: "+fileName);
                        return false;
                    }
                    boolean deleteSuccessFlag = file.delete();
                    if(!deleteSuccessFlag) {
                        logger.error("Unable to delete file: "+fileName);
                        return false;
                    }
                }
            }
        }	//end of for loop
        return true;
    } // End of function dleteFilesFromDir
	
    /**
     * Function to check if database name is valid
     * @param dbName The database name, which needs to be validated
     * @return True if database name is valid, else it return false.
     */
    boolean validateDBName(String dbName) {
        //First check if dbName is empty string.
        if(dbName.equals(""))
            return false;
        //checks for absence of special characters in database name.
        //The special characters are ., @, _, ?, -, +, *, numbers 0-9.
        Pattern p = Pattern.compile("^\\.|\\@|^\\_|\\?|\\#|\\~|\\+|\\-|\\s|\\*|^[0-9]");

        Matcher m = p.matcher(dbName);
        boolean result = m.find();

        // replace all such characters with ""
        if(result == true)
            return false;
        else {
            // Double check if database name starts with letters followed by numbers and/or underscores which would return valid database name.
            p = Pattern.compile("[^A-Za-z0-9\\_]+");
            m = p.matcher(dbName);
            boolean result1 = m.find();
            if(result1 == true)
                    return false;
        }
        return true;
    }

    public boolean validateSize(File file){
        boolean isValid = true;
        long fileSize = file.length();
        long fileSizeMB = fileSize / 1048576;
        if(fileSizeMB > maxLogSizeMB)
            isValid = false;
        return isValid;
    }
}//End of class
