/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cput;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.String;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * This class is what contains all of the data for the TestSuite. If a new
 * Session is started with a raw web log, Sachin's code will create an XML parsed
 * file which will be sent to this code. This class contains methods to parse
 * that XML file into individual test cases as well as methods to calculate
 * scores for different criteria and then quickSort the individual test cases
 * based upon various sorting criteria.
 *
 * It also calculates the two way score by maintaining Hash table of all covered
 * pairs.
 *
 * @author Devin Minson & Schuyler Manchester @editorInChief Chelynn Day
 */
public class LogPrioritizer {
    // <editor-fold defaultstate="collapsed" desc="Graph variables">
    /** 
     * Each index in graph represents a vertex, 
     * and holds a list of edges associated with that vertex.
     * 
     * The intraGraph variable stores the information for
     * the 2-Way Intra prioritization since intra does not share
     * any pairs with any of the other prioritization methods.
     */
     private ArrayList<List<RegularEdge>> graph;
     private ArrayList<List<IntraEdge>> intraGraph;
     
     private VertexEncoder encoder;
    // </editor-fold>
     
    // <editor-fold defaultstate="collapsed" desc="Private Members & Constructor">

    protected ArrayList<TestCase> webList;
    protected ArrayList<OrderedListItem> orderedLog;
    protected boolean _webListBuilt = false;
    //Frequency Parameters
    protected ArrayList<TestCase> frequencyWebList;
    protected ArrayList<TestCase> preTwoWayOrdered;
    
    private int totalParams;
    private int totalLength;
    private int totalURLs;
    private int totalSessions;
    private int maxParams;
    private int minParams;
    private int maxLength;
    private int minLength;
    private int numInputParameters;
    private File XMLFile;
    private TestCase.PrioritizationValue prioritizationSelection;  //used to determine which dataMember will be used when sorting
    private String _selectionKey;
    private boolean hasUniqueURLs;
    private ArrayList<String> urlParams;
    private String[] urlNames;
    private String[] uniqueURLParams;
    private TestCase.ReductionValue reductionSelection;  //used to determine which dataMember will be used when sorting
    //private int _largestCardinalitySize = -1;
    protected ArrayList<TestCase> reducedWebList;
    public MainScreen parent;
    private FrequencyPrioritizer frequencyPrioritizer;//The Frequency Prioritizer object.
    //This boolean keeps track whether the 1st URL in the sequence
    //i.e. previous URL has been initialized or not.
    private boolean isPreviousURLInitialized = false;
    //This boolean keeps track whether the 2nd URL in the sequence
    //i.e. current URL has been initialized or not.
    private boolean isCurrentURLInitialized = false;
    //This is the list of all those test cases that do not contain sequences within themselves
    //i.e. they contain single URLs. This list has to be added in a random fashion to the final
    private List<String> singleURLTestCaseList = null;//list of test cases that have been prioritized.
    private List<String> mfpsSequenceList = null;//This is the list of sequences sorted based on the MFPS criteria.
    private List<String> apsSequenceList = null;//This is the list of sequences sorted based on the APS criteria.
    //This is the list of sequences sorted based on the wf criteria.
    private List<String> wfSequenceList = null;

    public LogPrioritizer(MainScreen screen) {
        encoder = new VertexEncoder();
        graph = new ArrayList<List<RegularEdge>>();
        intraGraph = new ArrayList<List<IntraEdge>>();
        parent = screen;
	
        webList = new ArrayList<TestCase>();
        orderedLog = new ArrayList<OrderedListItem>();
        reducedWebList = new ArrayList<TestCase>();


        urlParams = new ArrayList<String>();
        singleURLTestCaseList = new ArrayList<String>();

        maxLength = 0;
        maxParams = 0;
        minLength = Integer.MAX_VALUE;
        minParams = Integer.MAX_VALUE;
        numInputParameters = 0;

	this.prioritizationSelection = TestCase.PrioritizationValue.NONE;
        this.reductionSelection = TestCase.ReductionValue.NONE;
    }
    
    public LogPrioritizer() {
        encoder = new VertexEncoder();
        graph = new ArrayList<List<RegularEdge>>();
        intraGraph = new ArrayList<List<IntraEdge>>();
        
        webList = new ArrayList<TestCase>(); 
        orderedLog = new ArrayList<OrderedListItem>();
	reducedWebList = new ArrayList<TestCase>();
	
        urlParams = new ArrayList<String>();
        singleURLTestCaseList = new ArrayList<String>();

        maxLength = 0;
        maxParams = 0;
        minLength = Integer.MAX_VALUE;
        minParams = Integer.MAX_VALUE;
        numInputParameters = 0;

        this.prioritizationSelection = TestCase.PrioritizationValue.NONE;
        this.reductionSelection = TestCase.ReductionValue.NONE;
    }


    // initialize ordered log when first starting
    private void createInitialOrderedLog(ArrayList<TestCase> testList) {
        for (int i = 0; i < testList.size(); i++) {
            this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
        }
    }
    
    private void updateProgress(int percent, boolean isPrioritization){
        if(parent!=null)
            parent.updateProgress(percent, isPrioritization);
    }

    // </editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Web List Methods">
    /**
     * Stores the parsed XML file and then calls the function that will parse
     * this file and creates the instances of TestCases
     *
     * @param selectedFile
     */
    public synchronized void readXMLFile(File selectedFile) {
        this.XMLFile = selectedFile;
        buildWebList();
    }

    /**
     * Uses a DocumentBuilderFactory to parse the XML file. The file is first
     * parsed into Session nodes. For each session node, it creates a new node
     * list of URLs. For each URL node, it creates a node list of parameters.
     * For each parameter a InputParameter instance is created and added to the HashTable
     * for that session. This will later be used to determine the two way score.
     * Every other prioritization criteria value is calculated during this
     * parsing. criteria
     */
        private void buildWebList() {
        //This .1 second delay is to avoid conflicts within the GUI when opening files
        long sleep = System.currentTimeMillis() + 100;
        while (sleep > System.currentTimeMillis()){}
        
        try {
            totalSessions = 0;
            totalParams = 0;
            totalLength = 0;
            totalURLs = 0;
            _webListBuilt = false;

            try {//Handle the URL Comment for unique/non-unique urls
                BufferedReader reader = new BufferedReader(new FileReader(XMLFile));
                String URLComment;
                String[] URLTokens;
                String delim = "[|]";
                URLComment = reader.readLine();
                URLComment = URLComment.substring(4, URLComment.length() - 3);
                URLTokens = URLComment.split(delim);
                uniqueURLParams = new String[URLTokens.length - 1];
                System.arraycopy(URLTokens, 1, uniqueURLParams, 0, URLTokens.length - 1);
                if (URLTokens[0].equals("Unique")) {
                    hasUniqueURLs = true;
                } else if (URLTokens[0].equals("Not Unique")) {
                    hasUniqueURLs = false;
                    for (int i = 1; i < URLTokens.length; i++) {
                        urlParams.add(URLTokens[i]);
                    }
                }
            } catch (IOException e) {
                System.out.println(e);
            }
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(XMLFile);

            // normalize text representation
            doc.getDocumentElement().normalize();

            NodeList listOfSessions = doc.getElementsByTagName("session");
            totalSessions = listOfSessions.getLength();
            FileReader fileRead = new FileReader(XMLFile.getPath());
            BufferedReader bufferRead = new BufferedReader(fileRead);

            String line, previousURL = null, currentURL;
            int currentSession = 0;
            frequencyPrioritizer = new FrequencyPrioritizer();

            for (int i = 0; i < totalSessions; i++) {
                
                Node sessionNode = listOfSessions.item(i);
                if (sessionNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element sessionElement = (Element) sessionNode;
                    final String sessionID = sessionElement.getAttribute("id");
                    TestCase thisCase = new TestCase(sessionID, i);
                    parent.updateUploadProgressTitle("Loading: " + sessionElement.getAttribute("id"));
                    parent.updateUploadProgress(((i * 99)+1)/totalSessions);

                    //////////////////////////////
                    //record the actual text of the test case

                    // Made changes in the code so that <testSuite> is displayed.
                    // This is hard coded here.
                    thisCase.recordTestCase("<testSuite>");
                    line = bufferRead.readLine();
                    while (!line.contains("<session")) {
                        line = bufferRead.readLine();
                    }
                    thisCase.recordTestCase(line);
                    line = bufferRead.readLine();
                    while (!line.contains("session>")) {
                        thisCase.recordTestCase(line);
                        line = bufferRead.readLine();
                    }
                    thisCase.recordTestCase(line);
                    line = "</testSuite>";
                    thisCase.recordTestCase(line + "\n");
                    ///////////////////////////////

                    //Get all of the URL nodes
                    NodeList URLList = sessionElement.getElementsByTagName("url");

                    thisCase.setURLs(URLList.getLength());
                    this.totalURLs += URLList.getLength();

                    urlNames = new String[URLList.getLength()];
                    //First loop through all URLs and parameters to encode them in the correct order (the order they appear).
                    for (int urlNum = 0; urlNum < URLList.getLength(); urlNum++) {
                        Element URLSesh = (Element) URLList.item(urlNum);
                        //get all of the parameters in the URL Node
                        NodeList Params = URLSesh.getElementsByTagName("param");

                        //NodeList newParamsList = URLSession.getChildNodes();
                        urlNames[urlNum] = getURLName(URLSesh);

                        for (int paramIndex = 0; paramIndex < Params.getLength(); paramIndex++) {
                            Element parameter = (Element) Params.item(paramIndex);
                            //System.out.println("Line 283 Encoder");
                            int vertex = encoder.encode(urlNames[urlNum], getTextValue(parameter, "name"), getTextValue(parameter, "value"));
                            if (vertex > graph.size() - 1) {
                                graph.add(new LinkedList<RegularEdge>());
                            }
                            if (vertex > intraGraph.size() - 1) {
                                intraGraph.add(new LinkedList<IntraEdge>());
                            }
                        }
                    }
                    
                    //Once everything is encoded, do the real work!
                    //loop through each URL node in the current session
                    for (int urlIndex = 0; urlIndex < URLList.getLength(); urlIndex++) {

                        Element URLSession = (Element) URLList.item(urlIndex);

                        //get all of the parameters in the URL Node
                        NodeList ParamList = URLSession.getElementsByTagName("param");


                        //Here the sets of two consecutive urls from each test case are taken and
                        //updated in the frequencyPrioritizer object.
                        //For test cases that do not contain sequences, a separate list of test
                        //cases is maintained. This list is added to the final list in a random 
                        //manner.
                        if (URLList.getLength() == 1) {
			    singleURLTestCaseList.add(sessionID);
                        } else if (URLList.getLength() > 1) {
                            if (currentSession == i) {
                                if (!isPreviousURLInitialized || !isCurrentURLInitialized) {

                                    if (!isPreviousURLInitialized && !isCurrentURLInitialized) {//1st case
                                        previousURL = urlNames[urlIndex];
                                        isPreviousURLInitialized = true;
                                    } else {
                                        if (!isPreviousURLInitialized) {//Unlikely. Might remove this condition
                                            previousURL = urlNames[urlIndex];
                                            isPreviousURLInitialized = true;
                                        } else if (!isCurrentURLInitialized) {
                                            currentURL = urlNames[urlIndex];
                                            isCurrentURLInitialized = true;

                                            updateFrequencySequenceMap(previousURL, currentURL, sessionID);
                                            previousURL = currentURL;
                                            isCurrentURLInitialized = false;
                                        }
                                    }
                                }
                            } else if (currentSession != i) {
                                currentSession = i;
                                isPreviousURLInitialized = true;
                                previousURL = urlNames[urlIndex];
                                isCurrentURLInitialized = false;
                            }
                        }

                        //The number of parameters must be done after url generation,
                        //since that is where the parameters are removed due to non-unique urls
                        thisCase.incrementParams(ParamList.getLength());
                        this.totalParams += ParamList.getLength();

                        //loop through the Parameters
                        for (int paramIndex = 0; paramIndex < ParamList.getLength(); paramIndex++) {

                            Element parameter = (Element) ParamList.item(paramIndex);
                            //the parameter is encoded as an integer representing the vertex.
                            //System.out.println("Line 348 Encoder");
                            int vertex1 = encoder.encode(urlNames[urlIndex], getTextValue(parameter, "name"), getTextValue(parameter, "value"));

                            //iterate through all of the parameters on the same page and add to intrawindow graph
                            for (int paramIndexIntra = paramIndex + 1; paramIndexIntra < ParamList.getLength(); paramIndexIntra++) {
                                Element parameterIntra = (Element) ParamList.item(paramIndexIntra);
                                int vertexIntra = encoder.encode(urlNames[urlIndex], getTextValue(parameterIntra, "name"), getTextValue(parameterIntra, "value"));                                
                                boolean added = false;
                                for (int intraEdgeIndex = 0; intraEdgeIndex < intraGraph.get(vertex1).size(); intraEdgeIndex++) {
                                    if (intraGraph.get(vertex1).get(intraEdgeIndex).getConnectedVertex() == vertexIntra) {
                                        intraGraph.get(vertex1).get(intraEdgeIndex).addTestCase(thisCase);
                                        added = true;
                                        break;
                                    }
                                }
                                if (!added) {
                                    IntraEdge newEdge = new IntraEdge(vertexIntra, thisCase);
                                    intraGraph.get(vertex1).add(newEdge);
                                }
                            }

                            //iterate through all the parameters on the next page and add to regular graph consecutive

                            int nextURL = urlIndex + 1;
                            if ((nextURL < URLList.getLength()) && (!urlNames[urlIndex].equals(urlNames[nextURL]))) {
                                Element URLSessionConsec = (Element) URLList.item(nextURL);
                                NodeList ParamListConsec = URLSessionConsec.getElementsByTagName("param");
                                for (int paramIndexConsec = 0; paramIndexConsec < ParamListConsec.getLength(); paramIndexConsec++) {
                                    Element parameterConsec = (Element) ParamListConsec.item(paramIndexConsec);
                                    int vertexConsec = encoder.encode(urlNames[nextURL], getTextValue(parameterConsec, "name"), getTextValue(parameterConsec, "value"));
                                    boolean added = false;
                                    for (int edgeIndexConsec = 0; edgeIndexConsec < graph.get(vertex1).size(); edgeIndexConsec++) {
                                        if (graph.get(vertex1).get(edgeIndexConsec).getConnectedVertex() == vertexConsec) {
                                            graph.get(vertex1).get(edgeIndexConsec).addForwardTestCase(thisCase);
                                            graph.get(vertex1).get(edgeIndexConsec).addConsecutiveTestCase(thisCase);
                                            added = true;
                                            break;
                                        }
                                    }
                                    if (!added) {
                                        RegularEdge newEdge = new RegularEdge(vertexConsec, thisCase, true, true);
                                        graph.get(vertex1).add(newEdge);
                                    }
                                }
                            }

                            //iterate through all the rest of the urls and add to the graph
                            for (nextURL = urlIndex + 2; nextURL < URLList.getLength(); nextURL++) {
                                Element URLSession2 = (Element) URLList.item(nextURL);

                                NodeList ParamList2 = URLSession2.getElementsByTagName("param");

                                //this will get the name of the next URL, to compare to the name of url of the current vertex       
                                if (urlNames[urlIndex].equals(urlNames[nextURL])) {
                                    continue;
                                }


                                //get all of the parameters in the URL Node
                                throughParameters:
                                for (int paramIndex2 = 0; paramIndex2 < ParamList2.getLength(); paramIndex2++) {
                                    //only add edge if the url names are not equal
                                    Element parameter2 = (Element) ParamList2.item(paramIndex2);
                                    int vertex2 = encoder.encode(urlNames[nextURL], getTextValue(parameter2, "name"), getTextValue(parameter2, "value"));
                                    boolean added = false;
                                    for (int edgeIndex = 0; edgeIndex < graph.get(vertex1).size(); edgeIndex++) {
                                        if (graph.get(vertex1).get(edgeIndex).getConnectedVertex() == vertex2) {
                                            graph.get(vertex1).get(edgeIndex).addForwardTestCase(thisCase);
                                            added = true;
                                            break;
                                        }
                                    }
                                    if (!added) {
                                        RegularEdge newEdge = new RegularEdge(vertex2, thisCase, true);
                                        graph.get(vertex1).add(newEdge);
                                    }

                                }
                            }
                        }
                    }

                    //-------RECORD LENGTH BY GETS/POSTS
                    NodeList requestTypeList = sessionElement.getElementsByTagName("request_type");
                    thisCase.setLength(requestTypeList.getLength());
                    this.totalLength += thisCase.getGetsPosts();
                    //Set Max params or Min params if appropriate
                    if (thisCase.getParams() > this.maxParams) {
                        this.maxParams = thisCase.getParams();
                    } else if (thisCase.getParams() < this.minParams) {
                        this.minParams = thisCase.getParams();
                    }
                    //Set Max length or Min length if appropriate
                    if (thisCase.getGetsPosts() > this.maxLength) {
                        this.maxLength = thisCase.getGetsPosts();
                    } else if (thisCase.getGetsPosts() < this.minLength) {
                        this.minLength = thisCase.getGetsPosts();
                    }

                    this.webList.add(thisCase);
                }//end of if clause
            }//end of for loop with i var
            
            parent.updateUploadProgressTitle("Finalizing...");
            parent.updateUploadProgress(99);
            //create new directed + ordered edges
            orderGraph();
            createInitialOrderedLog(webList);
            _webListBuilt = true;

            frequencyPrioritizer.setNumberOfTestCases(totalSessions - singleURLTestCaseList.size());
            Collections.shuffle(singleURLTestCaseList);

            /*
             * PLEASE NOTE: All three of these lists access a common list of
             * SequenceProperties object for their prioritization which is used
             * for prioritization.The Most Frequent Sequence list must be
             * accessed after APS and wf because elements from the
             * SequencePropeties list are deleted in the MFPS prioritization.
             */
            wfSequenceList = frequencyPrioritizer.getWeightFrequencySequences();
            wfSequenceList.addAll(singleURLTestCaseList);

            apsSequenceList = frequencyPrioritizer.getAllPresentSequences();
            apsSequenceList.addAll(singleURLTestCaseList);

            mfpsSequenceList = frequencyPrioritizer.getMostFrequentSequences();
            mfpsSequenceList.addAll(singleURLTestCaseList);

        } catch (SAXParseException err) {
            System.out.println("** Parsing error" + ", line "
                    + err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println(" " + err.getMessage());
        } catch (SAXException e) {
            Exception x = e.getException();
            ((x == null) ? e : x).printStackTrace();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        
        //printGraph();
        parent.updateUploadProgress(100);
    }
    
    /**
     * Iterates through graph, and for each edge with the first vertex greater than the first
     * adds a backwards directed edge representing the same connection.
     * This is used to make non-sequential scoring more efficient.
     */
        private void orderGraph() {
        //for graph
        for (int i = 1; i < graph.size(); i++) {
            edgeLoop:
            for (RegularEdge edge : graph.get(i)) {
                int j = edge.getConnectedVertex();
                if (i > j) {
                    boolean isAdded = false;
                    for (int edgeIndex = 0; edgeIndex < graph.get(j).size(); edgeIndex++) {
                        if (graph.get(j).get(edgeIndex).getConnectedVertex() == i) {
                            graph.get(j).get(edgeIndex).addBackwardTestCases(edge.getForwardTestCases());
                            isAdded = true;
                            break;
                        }
                    }
                    if (!isAdded) {
                        RegularEdge newEdge = new RegularEdge(i, edge.getForwardTestCases());
                        graph.get(j).add(newEdge);
                    }
                }
            }
        }
        //for intra graph
        for (int i = 1; i < intraGraph.size(); i++) {
            edgeLoop:
            for (IntraEdge edge : intraGraph.get(i)) {
                int j = edge.getConnectedVertex();
                if (i > j) {
                    boolean isAdded = false;
                    for (int edgeIndex = 0; edgeIndex < intraGraph.get(j).size(); edgeIndex++) {
                        if (intraGraph.get(j).get(edgeIndex).getConnectedVertex() == i) {
                            intraGraph.get(j).get(edgeIndex).addTestCases(edge.getApplicableTestCases(reductionSelection));
                            isAdded = true;
                            break;
                        }
                    }
                    if (!isAdded) {
                        IntraEdge newEdge = new IntraEdge(i, edge.getApplicableTestCases(reductionSelection));
                        intraGraph.get(j).add(newEdge);
                    }
                }
            }
        }
        /*for (int index=1; index<graph.size(); index++){
            int edgeCount = 0;
            for (Edge edge: graph.get(index)){
                System.out.println(edgeCount++);
            }
        }*/
    }
    
    private String getURLName(Element URLElem) {
        String URLname;
        NodeList Params = URLElem.getElementsByTagName("param");
        if (hasUniqueURLs) {
            URLname = getTextValue(URLElem, "baseurl");
        } else {
            URLname = getTextValue(URLElem, "baseurl");
            for (int k = 0; k < Params.getLength(); k++) {
                Element parameter = (Element) Params.item(k);
                if (urlParams.contains(getTextValue(parameter, "name"))) {
                    URLname += "/" + getTextValue(parameter, "name") + "=" + getTextValue(parameter, "value");
                    parameter.getParentNode().removeChild(parameter);
                    k--;
                }
            }
        }
        return URLname;
    }

    /**
     * Takes XML element and the tag name, looks for the tag and gets the text
     * content i.e for <param><name>Username</name></param> XML snippet if the
     * Element points to parameter node and tagName is 'name', this will return
     * Username
     *
     * @param ele
     * @param tagName
     * @return String textValue
     */
    private String getTextValue(Element ele, String tagName) {
        String textVal = null;
        NodeList nl = ele.getElementsByTagName(tagName);
        if (nl != null && nl.getLength() > 0) {
            Element el = (Element) nl.item(0);
            //if the field was blank, return an empty string
            if (el.getFirstChild() == null) {
                textVal = "";
            } else {
                textVal = el.getFirstChild().getNodeValue();
            }
        }
        return textVal;
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters">
    /**
     * Returns the ID of the test case at the specified index. The
     * prioritization criteria that is selected will determine which ID is
     * returned.
     *
     * @param index
     * @param selection
     * @return String ID
     */
    protected String getID(int index) {
        return (orderedLog != null && orderedLog.size() > index) ? orderedLog.get(index).getID() : "";
    }

    /**
     * Returns the index of the test case in reference to the original ordering.
     * This is used to get the entire text of the test case to display to the
     * user.
     *
     * @param childIndex
     * @return
     */
    public int getParentIndex(int childIndex) {
        int returnValue;
        if (prioritizationSelection == null) {
            returnValue = childIndex;
        } else {
            returnValue = orderedLog.get(childIndex).getIndex();
        }
        return returnValue;
    }

    public String[] getURLParams() {
        return uniqueURLParams;
    }

    public boolean getHasUniqueURLs() {
        return hasUniqueURLs;
    }

    public int getTotalLength() {
        return this.totalLength;
    }

    public int getMaxLength() {
        return this.maxLength;
    }

    public int getMinLength() {
        return this.minLength;
    }

    public int getNumInputParameters() {
        return this.numInputParameters;
    }

    public int getTotalSessions() {
        return this.totalSessions;
    }

    public int getTotalParams() {
        return this.totalParams;
    }

    public int getMaxParams() {
        return this.maxParams;
    }

    public int getMinParams() {
        return this.minParams;
    }

    public int getTotalURLs() {
        return this.totalURLs;
    }
    
    public TestCase.PrioritizationValue getPrioritizationType() {
        return this.prioritizationSelection;
    }
    
    public TestCase.ReductionValue getReductionType() {
        return this.reductionSelection;
    }
    // </editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Reset Methods">
    public void resetPrioritizationType() {
        this.prioritizationSelection = TestCase.PrioritizationValue.NONE;
    }
    
    public void resetReductionType() {
        this.reductionSelection = TestCase.ReductionValue.NONE;
    }
    
    private void resetCoverage(){
        //Clears the coverage of all edges
        for (int i=0; i<graph.size(); i++){
            for (RegularEdge edge : graph.get(i)){
                edge.setCoverage(false);
            }
        }
        for (int i=0; i<intraGraph.size(); i++){
            for (IntraEdge edge : intraGraph.get(i)){
                edge.setCoverage(false);
            }
        }
    }
    
    private void resetWebList(){
        for (TestCase tc: webList){
            tc.setReduced(false);
            tc.resetReducedScores();
        }
    }
    // </editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Print Graph Methods">
    public void printGraphAsText(){
        for (int i=0; i<graph.size(); i++){
            System.out.println("vertex (" + i + ")" +encoder.getHashKey(i) +  " has edges to:");
            for (RegularEdge e : graph.get(i)){
                System.out.println("     (" + e.getConnectedVertex() + ")" + encoder.getHashKey(e.getConnectedVertex()));
                System.out.println("in test cases:");
                for (TestCase tc : e.getForwardTestCases()){
                    System.out.println("          "+tc.getIndex());
                }
                System.out.println("backwards:");
                for (TestCase tc : e.getBackwardTestCases()){
                    System.out.println("          "+tc.getIndex());
                }
                
            }
        }
    }
    
    public void printGraph(){
        System.out.println("Entering printGraph");
        //Graph
        //Column by row
        // Vertex|Edge number | forward test cases| backwards| both
        Object[][] vectorTableData = new Object[graph.size()][9];
        String[] vectorTableColumnNames = {
	    "#Vertices",    //index 0
	    "#Edges",	    //index 1
	    "#Forwards",    //index 2
	    "#Backwards",   //index 3
	    "#Both",	    //index 4
	    "#ForwardsTC ", //index 5
	    "#BackwardsTC", //index 6
	    "#Average Testcase for fowarded",	//index 7
	    "#Average Testcase for backwards"	//index 8
	};
        for (int i=0; i<graph.size(); i++){
            vectorTableData[i][0] = i +"";
            //System.out.println("vertex (" + i + ")" +encoder.getHashKey(i) +  " has edges to:");
            int numEdgeCounter = 0;
            int numForwardEdges = 0;
            int numBackwardEdges = 0;
            int numBothwardEdges = 0;
            int numForwardTestCasesCounter = 0;
            int numBackwardTestCasesCounter = 0;
            
            for (RegularEdge e : graph.get(i)){
                numEdgeCounter++;
                if (e.getForwardTestCases().size() > 0){
                    numForwardEdges++;
                    if (e.getBackwardTestCases().size() > 0){
                        numBackwardEdges++;
                        numBothwardEdges++;
                    }
                }
                else if(e.getBackwardTestCases().size() > 0){
                    numBackwardEdges++;
                }
                //System.out.println("     (" + e.getConnectedVertex() + ")" + encoder.getHashKey(e.getConnectedVertex()));
                //System.out.println("in test cases:");
                for (TestCase tc : e.getForwardTestCases()){
                    numForwardTestCasesCounter++;
                    //System.out.println("          "+tc.getIndex());
                }
                //System.out.println("backwards:");
                for (TestCase tc : e.getBackwardTestCases()){
                    numBackwardTestCasesCounter++;
                    //System.out.println("          "+tc.getIndex());
                }
                
            }
            if(numEdgeCounter == 0) vectorTableData[i][1] ="";
	    else    vectorTableData[i][1] = numEdgeCounter + "";
            
            if(numForwardEdges == 0)	vectorTableData[i][2] ="";
            else    vectorTableData[i][2] = numForwardEdges + "";

            if(numBackwardEdges == 0)	vectorTableData[i][3] ="";
            else    vectorTableData[i][3] = numBackwardEdges + "";
            
            if(numBothwardEdges == 0)	vectorTableData[i][4] ="";
            else    vectorTableData[i][4] = numBothwardEdges + "";

            if(numForwardTestCasesCounter == 0)	vectorTableData[i][5] ="";
            else    vectorTableData[i][5] = numForwardTestCasesCounter + "";
            
            if(numBackwardTestCasesCounter == 0)    vectorTableData[i][6] ="";
            else    vectorTableData[i][6] = numBackwardTestCasesCounter + "";


            if(numForwardTestCasesCounter == 0 || numForwardEdges == 0)	vectorTableData[i][7] = "";
            else    vectorTableData[i][7] = ((1.0 * numForwardTestCasesCounter) / numForwardEdges) +"";
	    
            if(numBackwardTestCasesCounter == 0 || numBackwardEdges == 0)   vectorTableData[i][8] = "";
            else    vectorTableData[i][8] = ((1.0 * numBackwardTestCasesCounter) / numBackwardEdges) +"";
	    
            System.out.println(i + "|" + numForwardEdges + "|" + numBackwardEdges + "|" + numBothwardEdges + "|" + numForwardTestCasesCounter + "|" + numBackwardTestCasesCounter);
            
        }
        VertexTable x = new VertexTable(vectorTableData,vectorTableColumnNames);
        x.createAndShowGUI();
        System.out.println("Exiting printGraph");
    }
    // </editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Reduction Methods">
    
    public void reduce(TestCase.ReductionValue reductionSelection) {
        resetWebList();
        reducedWebList.clear();
        reducedWebList.addAll(webList);
        reduce(reductionSelection, reducedWebList);
        
    }
    
    public void reduce(TestCase.ReductionValue reductionSelection, ArrayList<TestCase> testList) {
	if(reductionSelection==this.reductionSelection)
	    return;
        this.reductionSelection = reductionSelection;
        this.prioritizationSelection = TestCase.PrioritizationValue.NONE;
        //set all test cases to reduced until they're included
        for (int i = 0; i < testList.size(); i++){
            testList.get(i).setReduced(true);
            if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                testList.get(i).resetReducedScores();
        }
        //sort back into original order.
        sortDescending(testList, TestCase.PrioritizationValue.NONE);
        this.orderedLog.clear();
        switch (reductionSelection) {
            case HGS_1Way:
                HGS1WayReducer oneWayReducer=new HGS1WayReducer(parent, graph, testList);
		oneWayReducer.reduce();
                for (int i = 0; i < reducedWebList.size(); i++) {
                    this.orderedLog.add(i, new OrderedListItem(webList.indexOf(reducedWebList.get(i)), reducedWebList.get(i).getId()));
                }
                break;
            case HGS_2Way:
	    case HGS_2WaySeq:
	    case HGS_2WayCon:
                HGS2WayReducer reducer=new HGS2WayReducer(parent, graph, testList, reductionSelection);
                reducer.reduce();
                for (int i = 0; i < reducedWebList.size(); i++) {
                    this.orderedLog.add(i, new OrderedListItem(webList.indexOf(reducedWebList.get(i)), reducedWebList.get(i).getId()));
                    testList.get(i).setReduced(false);
                }
                break;
	    case HGS_2WayIntra:
		HGS2WayReducer intraReducer=new HGS2WayReducer(intraGraph, testList, reductionSelection, parent);
                intraReducer.reduce();
                for (int i = 0; i < reducedWebList.size(); i++) {
                    this.orderedLog.add(i, new OrderedListItem(webList.indexOf(reducedWebList.get(i)), reducedWebList.get(i).getId()));
                    reducedWebList.get(i).setReduced(false);
                }
                break;
            case HGS_3Way:
            case HGS_3WaySeq:
                HGS3WayReducer reducer3Way = new HGS3WayReducer(parent, graph, testList, reductionSelection, encoder);
                reducer3Way.reduce();
                for (int i = 0; i < reducedWebList.size(); i++) {
                    this.orderedLog.add(i, new OrderedListItem(webList.indexOf(reducedWebList.get(i)), reducedWebList.get(i).getId()));
                    testList.get(i).setReduced(false);
                }
                break;
            case Combinatorial_1Way:
                oneWayOrder(testList);
                orderedLog.clear();
                sortDescending(testList, TestCase.PrioritizationValue.OneWay);
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getOneWay(reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case Combinatorial_2Way:
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                twoWayOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(true);
                orderedLog.clear();
                sortDescending(testList, TestCase.PrioritizationValue.TwoWay);
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getTwoWay(this.reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case Seq_2Way:
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                twoWaySeqOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(true);
                orderedLog.clear();
                sortDescending(testList, TestCase.PrioritizationValue.TwoWaySeq);
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getTwoWaySeq(this.reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case Con_2Way:
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                twoWayConOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(true);
                orderedLog.clear();
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getTwoWayCon(reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case Intra_2Way:
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                twoWayIntraOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(true);
                orderedLog.clear();
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getTwoWayIntra(reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case Combinatorial_3Way:
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                threeWayOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(true);
                orderedLog.clear();
                sortDescending(testList,TestCase.PrioritizationValue.ThreeWay);
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getThreeWay(reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case Seq_3Way:
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                threeWaySeqOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(true);
                orderedLog.clear();
                sortDescending(testList,TestCase.PrioritizationValue.ThreeWaySeq);
                for (int i = 0; i < testList.size(); i++) {
                    if (testList.get(i).getThreeWaySeq(reductionSelection) > 0) {
                        orderedLog.add(i, new OrderedListItem(webList.indexOf(testList.get(i)), testList.get(i).getId()));
                        testList.get(i).setReduced(false);
                    }
                    else{
                        testList.remove(i);
                        i--;
                    }
                }
                break;
            case NONE:
            default:
                for (int i = 0; i < testList.size(); i++) {
                    this.orderedLog.add(i, new OrderedListItem(i, webList.get(i).getId()));
                }
        }
        resetCoverage();
    }

    //</editor-fold>

    // <editor-fold desc="Prioritize Methods">
    /**
     * This function is called by the listener of the Radio buttons. Depending
     * upon which button is selected, the parameter 'selection' will change. It
     * first creates a copy of the weblist which will then be sorted. When the
     * list is sorted, it stores the ordering in an ArrayList so the work won't
     * have to be done again.
     *
     * @param selection
     */
    
    public void prioritize(TestCase.PrioritizationValue selection) {
        if(reductionSelection == null || reductionSelection == TestCase.ReductionValue.NONE)
            prioritize(selection, webList);   
        else
            prioritize(selection, reducedWebList);
    }
    
    public void prioritize(TestCase.PrioritizationValue selection, ArrayList<TestCase> testList) {
        if (this.prioritizationSelection == selection && prioritizationSelection != TestCase.PrioritizationValue.NONE) {
            return;
        }
        this.prioritizationSelection = selection;
        //sort back into original order.
        //quickSort(0, testList.size()-1, testList, TestCase.PrioritizationValue.NONE);
        this.orderedLog.clear();
	boolean isPrioritization = prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE;
        switch (selection) {
            case NONE:
                if (reductionSelection != TestCase.ReductionValue.NONE)
                    reduce(TestCase.ReductionValue.NONE);
                else{
                    sortAscending(testList, TestCase.PrioritizationValue.NONE);
                    for (int i = 0; i < testList.size(); i++) {
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                    }
                }
                for (int i = 0; i < testList.size(); i++)
                    testList.get(i).setReduced(false);
                break;
            case TwoWay:
                twoWayOrder(testList);
                sortDescending(testList, prioritizationSelection);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case TwoWaySeq:
                twoWaySeqOrder(testList);
                sortDescending(testList, prioritizationSelection);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case TwoWayCon:
                twoWayConOrder(testList);
                //sortDescending(testList,this.prioritizationSelection.TwoWayCon);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case TwoWayIntra:
                twoWayIntraOrder(testList);
                //sortDescending(testList,this.prioritizationSelection.TwoWayIntra);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case HybridRank:
            	if (testList.size() == 0)
            		break;
            	HashMap<String,TestCase> tHashMap = new HashMap<String,TestCase>();
            	for (int i = 0; i < testList.size(); i++) {
            		tHashMap.put(testList.get(i).getId(), (TestCase) DeepCopy.copy(testList.get(i)));
                }
            	twoWayOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                	tHashMap.get(testList.get(i).getId()).setTwoWay(testList.get(i).getTwoWay(null), null);
            	twoWayIntraOrder(testList);
                sortDescending(testList, TestCase.PrioritizationValue.TwoWayIntra);
                for (int i = 0; i < testList.size(); i++)
                	tHashMap.get(testList.get(i).getId()).setTwoWayIntra(testList.get(i).getTwoWayIntra(null), null);
                ArrayList<TestCase> tList = new ArrayList<TestCase>(tHashMap.values());
                for (int i = 0; i < tList.size(); i++) {
            		tList.get(i).setHybrid(tList.get(i).getTwoWay(null) + (tList.get(i).getTwoWayIntra(null)/(testList.get(0).getTwoWayIntra(null)+1.0)));
                }
                sortDescending(tList, TestCase.PrioritizationValue.HybridRank);
                testList.clear();
                testList.addAll(tList);
                for (int i = 0; i < testList.size(); i++) {
                	testList.get(i).setCurrentIndex(i);
                    this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case HybridMerge:
            	HashMap<String,TestCase> temporaryHashMap = new HashMap<String,TestCase>();
            	for (int i = 0; i < testList.size(); i++) {
            		temporaryHashMap.put(testList.get(i).getId(), (TestCase) DeepCopy.copy(testList.get(i)));
                }
            	twoWayIntraOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                	temporaryHashMap.get(testList.get(i).getId()).setTwoWayIntra(testList.get(i).getTwoWayIntra(null), null);
            	twoWayOrder(testList);
                for (int i = 0; i < testList.size(); i++)
                	temporaryHashMap.get(testList.get(i).getId()).setTwoWay(testList.get(i).getTwoWay(null), null);
                ArrayList<TestCase> temporaryList = new ArrayList<TestCase>(temporaryHashMap.values());
                for (int i = 0; i < temporaryList.size(); i++) {
                		temporaryList.get(i).setHybrid(temporaryList.get(i).getTwoWay(null) + temporaryList.get(i).getTwoWayIntra(null));
                }
                sortDescending(temporaryList, TestCase.PrioritizationValue.HybridMerge);
                testList.clear();
                testList.addAll(temporaryList);
                for (int i = 0; i < testList.size(); i++) {
                	testList.get(i).setCurrentIndex(i);
                    this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case HybridChoice:
            	if (testList.size() == 0)
            		break;
            	HashMap<String,TestCase> tstHashMap = new HashMap<String,TestCase>();
            	for (int i = 0; i < testList.size(); i++) {
            		tstHashMap.put(testList.get(i).getId(), (TestCase) DeepCopy.copy(testList.get(i)));
                }
            	twoWayOrder(testList);
                sortDescending(testList, TestCase.PrioritizationValue.TwoWay);
                int tmpTWL = testList.get(0).getTwoWay(null);
                for (int i = 0; i < testList.size(); i++)
                	tstHashMap.get(testList.get(i).getId()).setTwoWay(testList.get(i).getTwoWay(null), null);
            	twoWayIntraOrder(testList);
                sortDescending(testList, TestCase.PrioritizationValue.TwoWayIntra);
                int tmpTWIL = testList.get(0).getTwoWayIntra(null);
                for (int i = 0; i < testList.size(); i++)
                	tstHashMap.get(testList.get(i).getId()).setTwoWayIntra(testList.get(i).getTwoWayIntra(null), null);
                ArrayList<TestCase> tstList = new ArrayList<TestCase>(tstHashMap.values());
                for (int i = 0; i < tstList.size(); i++) {
                	double tmpTwoWay = tstList.get(i).getTwoWay(null)/(tmpTWL + 1.0);
                	double tmpTwoWayIntra = tstList.get(i).getTwoWayIntra(null)/(tmpTWIL + 1.0);
                	if (tmpTwoWay > tmpTwoWayIntra)
                		tstList.get(i).setHybrid(tmpTwoWay*100);
                	else
                		tstList.get(i).setHybrid(tmpTwoWayIntra*100);
                }
                sortDescending(tstList, TestCase.PrioritizationValue.HybridRank);
                testList.clear();
                testList.addAll(tstList);
                for (int i = 0; i < testList.size(); i++) {
                	testList.get(i).setCurrentIndex(i);
                    this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case ThreeWay:
                threeWayOrder(testList);
                sortDescending(testList, prioritizationSelection);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case ThreeWaySeq:
                threeWaySeqOrder(testList);
                sortDescending(testList, prioritizationSelection);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case MFPS:
                ArrayList<String> mostFrequentSequences = (ArrayList<String>) mfpsSequenceList;
                for (int i = 0; i < mostFrequentSequences.size(); i++) {
                    updateProgress((int) ((double) i * 100) / mostFrequentSequences.size(), isPrioritization);
		    
                    TestCase tempTestCase = null;
                    for (TestCase testCase : testList) {
                        if (testCase.getId().equalsIgnoreCase(mostFrequentSequences.get(i))) {
                            tempTestCase = testCase;
                            break;
                        }
                    }
                    if(testList.contains(tempTestCase))
                        this.orderedLog.add(new OrderedListItem(webList.indexOf(tempTestCase), mostFrequentSequences.get(i)));
                }
                break;
            case APS:
                ArrayList<String> allPresentSequences = (ArrayList<String>) apsSequenceList;
                for (int i = 0; i < allPresentSequences.size(); i++) {
                    updateProgress((int) ((double) i * 100) / allPresentSequences.size(), isPrioritization);
                    
                    TestCase tempTestCase = null;
                    for (TestCase testCase : testList) {
                        if (testCase.getId().equalsIgnoreCase(allPresentSequences.get(i))) {
                            tempTestCase = testCase;
                            break;
                        }
                    }
                    if(testList.contains(tempTestCase))
                        this.orderedLog.add(new OrderedListItem(webList.indexOf(tempTestCase), allPresentSequences.get(i)));
                }
                break;
            case WF:
                ArrayList<String> weightPresentSequences = (ArrayList<String>) wfSequenceList;
                for (int i = 0; i < weightPresentSequences.size(); i++) {
                    updateProgress((int) ((double) i * 100) / weightPresentSequences.size(), isPrioritization);
		    
                    TestCase tempTestCase = null;
                    for (TestCase testCase : testList) {
                        if (testCase.getId().equalsIgnoreCase(weightPresentSequences.get(i))) {
                            tempTestCase = testCase;
                            break;
                        }
                    }
                    if(testList.contains(tempTestCase))
                        this.orderedLog.add(new OrderedListItem(webList.indexOf(tempTestCase), weightPresentSequences.get(i)));
                }
                break;
            case Length:
                sortDescending(testList, prioritizationSelection);
                for (int i = 0; i < testList.size(); i++) {
                    updateProgress((int) ((double) (i * 99) / testList.size()), isPrioritization);
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                updateProgress((int) 100, isPrioritization);
                break;
            case Params:
                sortDescending(testList, prioritizationSelection);
                for (int i = 0; i < testList.size(); i++) {
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                break;
            case Random:
                Collections.shuffle(testList);
                for (int i = 0; i < testList.size(); i++) {
                    //updateProgress((int) ((double) i * 100) / testList.size(), this.reductionSelection == TestCase.ReductionValue.NONE);
                    updateProgress((int) ((double) i * 100) / testList.size(), true);
                    if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE)
                        this.orderedLog.add(i, new OrderedListItem(testList.get(i).getIndex(), testList.get(i).getId()));
                    else
                        this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
                updateProgress(100, true);
                break;
            default:
                for (int i = 0; i < testList.size(); i++) {
                    this.orderedLog.add(i, new OrderedListItem(i, testList.get(i).getId()));
                }
        }
        resetCoverage();
    }

    //<editor-fold desc="1-Way Prioritization">
    @SuppressWarnings("unchecked")
    private void oneWayOrder(ArrayList<TestCase> testList) {
	// If the scores have already been computed, just sort by that score.
	if(testList.get(0).getOneWay(reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.OneWay);
	    return;
	}
	ArrayList<Integer> vertices = new ArrayList<Integer>();
	ArrayList<List<TestCase>> verticeTests = new ArrayList<List<TestCase>>();
	ArrayList<TestCase> coveringTests = new ArrayList<TestCase>();
	ArrayList<Integer> testScores = new ArrayList<Integer>();
	
	for(int curVertex = 0; curVertex <graph.size(); curVertex++){
	    vertices.add(curVertex);
	    verticeTests.add(new ArrayList<TestCase>());
	}
	for(int curVertex = 0; curVertex <graph.size(); curVertex++){
	    List<TestCase> tests = verticeTests.get(curVertex);
	    List<RegularEdge> edges = graph.get(curVertex);
	    for(int curEdge = 0; curEdge < edges.size(); curEdge++){
		RegularEdge e = edges.get(curEdge);
		List<TestCase> testCases = e.getApplicableTestCases(reductionSelection);
		for(int i = 0; i < testCases.size(); i++){
		    TestCase t = testCases.get(i);
		    int scoreIndex = coveringTests.indexOf(t);
		    if(scoreIndex == -1){
			coveringTests.add(t);
			testScores.add(0);
			scoreIndex = coveringTests.indexOf(t);
		    }
		    if(!tests.contains(t)){
			tests.add(t);
			testScores.set(scoreIndex, testScores.get(scoreIndex)+1);
		    }
		    if(!verticeTests.get(e.getConnectedVertex()).contains(t)){
			verticeTests.get(e.getConnectedVertex()).add(t);
			testScores.set(scoreIndex, testScores.get(scoreIndex)+1);
		    }

		}
	    }
	}
	while(!vertices.isEmpty()){
	    
	    // Get best test case.
	    int maxIndex=0;
	    for(int curTest = 1; curTest < coveringTests.size(); curTest++)
		if(testScores.get(curTest)>testScores.get(maxIndex))
		    maxIndex=curTest;
	    TestCase bestTest = coveringTests.get(maxIndex);
	    bestTest.setOneWay(testScores.get(maxIndex),reductionSelection);
	    // Update coverage array lists.
	    for(int curVertex = 0; curVertex < vertices.size(); curVertex++){
		    List<TestCase> tests = verticeTests.get(vertices.get(curVertex));
		    if(tests.contains(bestTest)){
			    for(int curTest = 0; curTest < tests.size(); curTest++)
			    {
				    int testIndex = coveringTests.indexOf(tests.get(curTest));
				    testScores.set(testIndex, testScores.get(testIndex) - 1);
			    }
			    vertices.remove(curVertex);
			    curVertex--;
		    }
	    }
	    int bestTestIndex = coveringTests.indexOf(bestTest);
	    coveringTests.remove(bestTestIndex);
	    testScores.remove(bestTestIndex);
	}
	sortDescending(testList, TestCase.PrioritizationValue.OneWay);
    }
    //</editor-fold>
    
    //<editor-fold desc="2-way Prioritization">
    /**
     * This function calculates the two way score for each session. It does so
     * by looping through the entire graph n times, where n is the number of test cases.
     * At each pass, it finds the test case with the next highest number of unique pairs covered
     * and swaps it with the i-th member of the list. It finds the next highest by incrementing 
     * the score for each test case a pair covers, unless that pair is covered by a test case
     * between 0 and i.
     */
    @SuppressWarnings("unchecked")
    private void twoWayOrder(ArrayList<TestCase> testList) {
	// If the scores have already been computed, just sort by that score.
	if(testList.get(0).getTwoWay(this.reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.TwoWay);
	    return;
	}
        // Loops through and set coverage variables to false.
        for (int g = 0; g < graph.size(); g++){
            for (RegularEdge e : graph.get(g)){
                e.setCoverage(false);
            }
        }
        // Main For loop, the index of which indicates how many of the test cases have been ordered.
        for (int i = 0; i < testList.size(); i++) {
            
            // Updates the appropriate progress bar.
            boolean isPrioritized = prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE;
	    updateProgress((int) ((double) i * 100) /testList.size(), isPrioritized);
            
            // Resets unsorted test case's scores to zero and resets the unsorted
            // test case's current index before the next run through
            for (int j = i; j < testList.size(); j++) {
                testList.get(j).setTwoWay(0,this.reductionSelection);
                testList.get(j).setCurrentIndex(j);
            }
            // Keeps track of the current highest score and the index of the testList which has it while iterating.
            int highestScore = -1;
            int indexOfHighest = i;
            vertexLoop:
            for (int vertex = 0; vertex < graph.size(); vertex++) {
                edgeLoop:
                for (RegularEdge edge : graph.get(vertex)) {
                    if (edge.isCovered())
                        continue edgeLoop;
                    // Do not count edges from a greater vertex to a lesser one, as they have already been counted.
                    // Note: Only necessary for the nonsequential version.
                    int vertex2 = edge.getConnectedVertex();
                    if (vertex2 < vertex)
                        continue edgeLoop;
                    
                    LinkedList<TestCase> allCases = new LinkedList<TestCase>();
                    allCases.addAll(edge.getForwardTestCases());
                    allCases.addAll(edge.getBackwardTestCases());
                    // Checks that the current edge hasn't been included in a previous test case
                     for (int sortedTests = 0; sortedTests < i; sortedTests++) {
                         for (TestCase testCaseCheck : allCases) {
                             if (testCaseCheck.getIndex() == testList.get(sortedTests).getIndex()){
                                 edge.setCoverage(true);
                                 continue edgeLoop;
                             }
                         }                 
                     }
                     
                     // If not, increment the score for all the test cases that include that edge.
                     testCaseLoop:
                     for (TestCase test : allCases){ 
                         if (test.getReduced())
                            continue;
                        if (test.getCurrentIndex() >= testList.size())
                            continue;
                         if (test.getCurrentIndex() >= i) {
                             int newScore = test.getTwoWay(this.reductionSelection) + 1;
                             if (newScore > highestScore) {
                                 highestScore = newScore;
                                 indexOfHighest = test.getCurrentIndex();
                             }
                             test.setTwoWay(newScore,this.reductionSelection);
                         }
                     }
                }   
            } 
            // After iterating through vertices each time, take the highest test case and switch it with the next place.
            if (i != testList.size()-1 || i != indexOfHighest)
                swapTestCases(i, indexOfHighest, testList);
        }
    }
    //</editor-fold>
    
    //<editor-fold desc="2-waySeq Prioritization">
    /**
     * This function calculates the two way sequential score for each session.
     * Beginning with the first session, it loops through all of the parameters
     * in that session. Each URLs unique parameter name-value pair is paired
     * with every other parameter in that session. If the parameters share the
     * same URL, or if that same pair has already been covered in that session
     * or a previous session, the session doesn't get a 'point'. Only pairs in
     * the same order are counted as the same. It receives a point for all other
     * pairs. The covered pairs are stored in the Hashtable twoWaySeqPairs.
     */
    @SuppressWarnings("unchecked")
    private void twoWaySeqOrder(ArrayList<TestCase> testList) {
	// If the scores have already been computed, just sort by that score.
	if(testList.get(0).getTwoWaySeq(this.reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.TwoWaySeq);
	    return;
	}
        // Main For loop, the index of which indicates how many of the test cases have been ordered.
        for (int g = 0; g < graph.size(); g++){
            for (RegularEdge e : graph.get(g)){
                e.setCoverage(false);
            }
        }
        // We loop through the test listList
        for (int i = 0; i < testList.size(); i++) {
            // Updates the appropriate progress bar.
            if(prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE){
                updateProgress((int) ((double) i * 100) /testList.size(), true);
            }
            else{
                updateProgress((int) ((double) i * 100) / testList.size(), false);
            }
            // Resets unsorted test case's scores to zero and resets the unsorted
            // test case's current index before the next run through
            for (int j = i; j < testList.size(); j++) {
                testList.get(j).setTwoWaySeq(0,this.reductionSelection);
                testList.get(j).setCurrentIndex(j);
            }
            
            // We want to keep track of the high score and the index of the highscore for reference.
            int highestScore = -1;
            int indexOfHighest = i;
            vertexLoop:
            for (int vertex = 0; vertex < graph.size(); vertex++) {
                // Grab the edges.
                edgeLoop:
                for (RegularEdge edge : graph.get(vertex)) {
                    if (edge.isCovered())
                        continue edgeLoop;
                    if (edge.getForwardTestCases().isEmpty())
                        continue vertexLoop;
                    // Checks that the current vertex (parameter) isn't included in a previous test case.
                    for (int sortedTests = 0; sortedTests < i; sortedTests++) {
                        //after the first loop, we check to see if we have a recounting the 
                        //a edge
                        for (TestCase testCaseCheck : edge.getForwardTestCases()) {
                            if (testList.get(sortedTests).getIndex() == testCaseCheck.getIndex()) {
                                //if one of the sorted test cases already contains this vertex, continue vertex loop
                                edge.setCoverage(true);
                                continue edgeLoop;
                            }
                        }
                    }
                    // We have found a vertex that does not have correspnding edges at this point.
                    for (TestCase vertexTest : edge.getForwardTestCases()) {
                        if (vertexTest.getReduced())
                            continue;
                        if (vertexTest.getCurrentIndex() >= testList.size())
                            continue;
                        // Increment every unsorted test case's score. 
                        int newScore = vertexTest.getTwoWaySeq(this.reductionSelection)+1;
                        vertexTest.setTwoWaySeq(newScore,this.reductionSelection);
                        if (newScore > highestScore) {
                            highestScore = newScore;
                            indexOfHighest = vertexTest.getCurrentIndex();
                        }

                    }
                }
            }
            // After iterating through vertices each time, take the highest test case and switch it with the next place.
            if (i != testList.size() - 1)
                swapTestCases(i, indexOfHighest, testList);
        }
    }
    //</editor-fold>
    
    //<editor-fold desc="2-wayCon Prioritization">
    /**
     * This function orders the sessions based on their two way consecutive
     * score. It loops through the entire graph, incrementing the score for each
     * test case in each edge and keeping track of the highest. At each
     * Iteration, it sorts one more test case, (the current highest) and will
     * not count edges that that test case covers in future iteration.
     */
    @SuppressWarnings("unchecked")
    private void twoWayConOrder(ArrayList<TestCase> testList) {
	// If the scores have already been computed, just sort by that score.
	if(testList.get(0).getTwoWayCon(reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.TwoWayCon);
	    return;
	}
        // Loops through and sets coverage variables to false
        for (int g = 0; g < graph.size(); g++) {
            for (RegularEdge e : graph.get(g)) {
                e.setCoverage(false);
            }
        }

        // Main For loop, the index of which indicates how many of the test cases have been ordered.
        for (int i = 0; i < testList.size(); i++) {
            // Updates the appropriate progress bar.
            if (prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE) {
                updateProgress((int) ((double) i * 100) / testList.size(), true);
            } else {
                updateProgress((int) ((double) i * 100) / testList.size(), false);
            }
            
            // Resets unsorted test case's scores to zero and resets the unsorted
            // test case's current index before the next run through
            for (int j = i; j < testList.size(); j++) {
                testList.get(j).setTwoWayCon(0,reductionSelection);
                testList.get(j).setCurrentIndex(j);
            }
            
            // We want to keep track of the high score and the index of the highscore for reference.
            int highestScore = -1;
            int indexOfHighest = i;
            vertexLoop:
            for (int vertex = 0; vertex < graph.size(); vertex++) {
                // Grab the edges. 
                edgeLoop:
                for (RegularEdge edge : graph.get(vertex)) {
                    if (edge.isCovered()) {
                        continue edgeLoop;
                    }
                    // Checks that the current vertex (parameter) isn't included in a previous test case.
                    for (int sortedTests = 0; sortedTests < i; sortedTests++) {
                        // After the first loop, we check to see if we have a recounting the 
                        for (TestCase testCaseCheck : edge.getConsecutiveTestCases()) {
                            if (testList.get(sortedTests).getIndex() == testCaseCheck.getIndex()) {
                                // If one of the sorted test cases already contains this vertex, continue vertexLoop.
                                edge.setCoverage(true);
                                continue edgeLoop;
                            }
                        }
                    }
                    // We have found a vertex that does not have correspnding edges at this point.
                    for (TestCase vertexTest : edge.getConsecutiveTestCases()) {
                        if (vertexTest.getReduced())
                            continue;
                        if (vertexTest.getCurrentIndex() >= testList.size())
                            continue;
                        // Increment every unsorted test case's score.
                        int newScore = vertexTest.getTwoWayCon(reductionSelection) + 1;
                        vertexTest.setTwoWayCon(newScore,reductionSelection);
                        if (newScore > highestScore) {
                            highestScore = newScore;
                            indexOfHighest = vertexTest.getCurrentIndex();
                        }

                    }
                }
            }
            // After iterating through vertices each time, take the highest test case and switch it with the next place.
            if (i != testList.size() - 1) {
                swapTestCases(i, indexOfHighest, testList);
            }
        }
    }
    //</editor-fold>
    
    //<editor-fold desc="2-wayIntra Prioritization">
    /**
     * This function orders the sessions based on their two way consecutive
     * score. It loops through the entire graph, incrementing the score for each
     * test case in each edge and keeping track of the highest. At each
     * Iteration, it sorts one more test case, (the current highest) and will
     * not count edges that that test case covers in future iteration.
     */
    @SuppressWarnings("unchecked")
    private void twoWayIntraOrder(ArrayList<TestCase> testList) {
	// If the scores have already been computed, just sort by that score.
	if(testList.get(0).getTwoWayIntra(reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.TwoWayIntra);
	    return;
	}
        // Loops through and sets coverage variables to false.
        for (int g = 0; g < intraGraph.size(); g++) {
            for (IntraEdge e : intraGraph.get(g)) {
                e.setCoverage(false);
            }
        }

        // Main For loop, the index of which indicates how many of the test cases have been ordered.
        for (int i = 0; i < testList.size(); i++) {
            // Updates the appropriate progress bar.
            if (prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE) {
                updateProgress((int) ((double) i * 100) / testList.size(), true);
            } else {
                updateProgress((int) ((double) i * 100) / testList.size(), false);
            }
            // Resets unsorted test case's scores to zero and resets the unsorted
            // test case's current index before the next run through
            for (int j = i; j < testList.size(); j++) {
                testList.get(j).setTwoWayIntra(0,reductionSelection);
                testList.get(j).setCurrentIndex(j);
            }
            // We want to keep track of the high score and the index of the highscore for reference.
            int highestScore = -1;
            int indexOfHighest = i;
            vertexLoop:
            for (int vertex = 0; vertex < intraGraph.size(); vertex++) {
                // Grab the edges.
                edgeLoop:
                for (IntraEdge edge : intraGraph.get(vertex)) {
                    if (edge.isCovered() || (vertex > edge.getConnectedVertex())) {
                        continue edgeLoop;
                    }
                    // Checks that the current vertex (parameter) isn't included in a previous test case.
                    for (int sortedTests = 0; sortedTests < i; sortedTests++) {
                        // After the first loop, we check to see if we have a recounting the 
                        for (TestCase testCaseCheck : edge.getApplicableTestCases(reductionSelection)) {
                            if (testList.get(sortedTests).getIndex() == testCaseCheck.getIndex()) {
                                // If one of the sorted test cases already contains this vertex, continue vertexLoop.
                                edge.setCoverage(true);
                                continue edgeLoop;
                            }
                        }
                    }
                    // We have found a vertex that does not have correspnding edges at this point
                    for (TestCase vertexTest : edge.getApplicableTestCases(reductionSelection)) {
                        if (vertexTest.getReduced())
                            continue;
                        if (vertexTest.getCurrentIndex() >= testList.size())
                            continue;
                        // Increment every unsorted test case's score.
                        int newScore = vertexTest.getTwoWayIntra(reductionSelection) + 1;
                        vertexTest.setTwoWayIntra(newScore,reductionSelection);
                        if (newScore > highestScore) {
                            highestScore = newScore;
                            indexOfHighest = vertexTest.getCurrentIndex();
                        }

                    }
                }
            }
            // After iterating through vertices each time, take the highest test case and switch it with the next place.
            if (i != testList.size() - 1)
                swapTestCases(i, indexOfHighest, testList);
        }
    }
    //</editor-fold>
    
    //<editor-fold desc="3-way Prioritization">
    /**
     * This function Orders the testList by threeWaySequential Pairs.
     * It does so by looping through the entire graph n times, where n is the length of the test list.
     * For each edge, go to its connecting vertex and find each of it's edges. 
     * Compare the test case lists to find the relevant test cases and increment their scores.
     * Then, on each pass, find the next highest score and swap it with the i-th index.
     */
    @SuppressWarnings("unchecked")
    private void threeWayOrder(ArrayList<TestCase> testList) {
        // If the scores have already been computed, just sort by that score.
	if(testList.get(0).getThreeWay(reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.ThreeWay);
	    return;
	}
        // Main For loop, the index of which indicates how many of the test cases have been ordered.
        for (int i = 0; i < testList.size(); i++) {
            // Updates the appropriate progress bar.
            if(prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE){
                updateProgress((int) (((double) (i * 99)) / testList.size())+1, true);
            }
            else{
                updateProgress((int) (((double) (i * 99)) / testList.size())+1, false);
            }
            
            // Resets unsorted test case's scores to zero and resets the unsorted
            // test case's current index before the next run through
            for (int j = i; j<testList.size(); j++){
                testList.get(j).setThreeWay(0,reductionSelection);
                testList.get(j).setCurrentIndex(j);
            }
            
            // Keeps track of the current highest score and the index of the testList which has it while iterating.
            int highestScore = -1;
            int indexOfHighest = i;
            vertexLoop:
            for (int vertex = 0; vertex < graph.size(); vertex++) {
                edgeLoop1:
                for (RegularEdge edge1 : graph.get(vertex)) {
                    //If the current edge is covered, skip to the next one.
                    if (edge1.isCovered())
                        continue edgeLoop1;
                    
                    // Don't count edges from a greater vertex to a lesser one, as they have already been counted.
                    int vertex2 = edge1.getConnectedVertex();
                    if (vertex > vertex2) {
                        continue edgeLoop1;
                    }

                    LinkedList<TestCase> allEdge1Tests = new LinkedList<TestCase>();
                    allEdge1Tests.addAll(edge1.getForwardTestCases());
                    allEdge1Tests.addAll(edge1.getBackwardTestCases());
                    
                    edgeLoop2:
                    for (RegularEdge edge2 : graph.get(vertex2)){
                        // If the current edge is covered, skip to the next one.
                        if (edge2.isCovered())
                            continue edgeLoop2;
                        
                         // Don't count edges from a greater vertex to a lesser one, as they have already been counted.
                         // Also don't count three way edges that begin and end on the same URL.
                        if ((vertex2 > edge2.getConnectedVertex())||encoder.haveSameURL(vertex, edge2.getConnectedVertex()))
                            continue edgeLoop2;
                        
                        // Finds all test cases that cover both edge1 and edge2.
                        LinkedList<TestCase> threeWayCoverage = new LinkedList<TestCase>();
                                                

                        //find all test cases that cover both edge1 and edge2
                        for (TestCase test : allEdge1Tests){
                            if (edge2.getForwardTestCases().contains(test) || edge2.getBackwardTestCases().contains(test))  
                                threeWayCoverage.add(test);
                        }
                        
                        // Skip to next edge if edge1 and edge2 don't share any test cases.
                        if (threeWayCoverage.size() == 0)
                            continue edgeLoop2;
                        
                        // Determines if an edge has been covered or not, an edge
                        // is covered when all test cases in the forward & backward
                        // test case lists have been sorted.
                        edge1.setCoverage(true);
                        edge2.setCoverage(true);
                        boolean currentCovered = false;
                        tcLoop1:
                        for (TestCase covTest: edge1.getForwardTestCases()){
                            currentCovered = false;
                            if (covTest.getReduced()){
                                currentCovered=true;
                                continue tcLoop1;
                            }
                            for (int sortIndex = 0; sortIndex < i; sortIndex++){
                                if(covTest.getIndex() == testList.get(sortIndex).getIndex()){
                                    currentCovered = true;
                                    break;
                                }
                            }
                            if (!currentCovered){
                            break;
                            }
                        }
                        if (currentCovered){
                            tcLoop2:
                            for (TestCase covTest: edge1.getBackwardTestCases()){
                                currentCovered = false;
                                if (covTest.getReduced()){
                                    currentCovered=true;
                                    continue tcLoop2;
                                }
                                for (int sortIndex = 0; sortIndex < i; sortIndex++){
                                    if(covTest.getIndex() == testList.get(sortIndex).getIndex()){
                                        currentCovered = true;
                                        break;
                                    }
                                }
                                if (!currentCovered){
                                break;
                                }
                            }
                        }
                        edge1.setCoverage(currentCovered);
                        tcLoop3:
                        for (TestCase covTest: edge2.getForwardTestCases()){
                            currentCovered = false;
                            if (covTest.getReduced()){
                                currentCovered=true;
                                continue tcLoop3;
                            }
                            for (int sortIndex = 0; sortIndex < i; sortIndex++){
                                if(covTest.getIndex() == testList.get(sortIndex).getIndex()){
                                    currentCovered = true;
                                    break;
                                }
                            }
                            if (!currentCovered){
                            break;
                            }
                        }
                        if (currentCovered){
                            tcLoop4:
                            for (TestCase covTest: edge2.getForwardTestCases()){
                                currentCovered = false;
                                if (covTest.getReduced()){
                                    currentCovered=true;
                                    continue tcLoop4;
                                }
                                for (int sortIndex = 0; sortIndex < i; sortIndex++){
                                    if(covTest.getIndex() == testList.get(sortIndex).getIndex()){
                                        currentCovered = true;
                                        break;
                                    }
                                }
                                if (!currentCovered){
                                break;
                                }
                            }
                        }
                        edge2.setCoverage(currentCovered);
                        if (edge1.isCovered())
                            continue edgeLoop1;
                        if (edge2.isCovered())
                            continue edgeLoop2;
                        
                        // Then checks if any of those test cases are any of the sorted ones 
                        // (ie, the three way pair is already covered by an existing test case)
                        for (int sortedTests = 0; sortedTests < i; sortedTests++){
                            for (TestCase coveringTest : threeWayCoverage){
                                if (coveringTest.getIndex() == testList.get(sortedTests).getIndex()){
                                    continue edgeLoop2;
                                }
                            }
                        }
                        
                        // If they are not sorted, increment each score.
                        for (TestCase toIncrement : threeWayCoverage){
                            if (toIncrement.getReduced())
                                continue edgeLoop2;
                            if (toIncrement.getCurrentIndex() >= testList.size()){
                                System.out.println("Index too high. " + toIncrement.getCurrentIndex() + ":" + testList.size());
                                continue;
                            }
                            int newScore = toIncrement.getThreeWay(reductionSelection) + 1;
                            if (newScore > highestScore){
                                highestScore = newScore;
                                indexOfHighest = toIncrement.getCurrentIndex();
                            }
                            toIncrement.setThreeWay(newScore,reductionSelection);
                        }
                    }
                }
            }
            // After iterating through vertices each time, take the highest test case and switch it with the next place.
            if (i < testList.size()-1)
                    swapTestCases(i, indexOfHighest, testList);
	}
    }

    //<editor-fold desc="3-way Seq Prioritization">
    /**
     * This function Orders the testList by threeWaySequential Pairs.
     * It does so by looping through the entire graph n times, where n is the length of the test list.
     * For each edge, go to its connecting vertex and find each of it's edges. 
     * Compare the test case lists to find the relevant test cases and increment their scores.
     * Then, on each pass, find the next highest score and swap it with the i-th index.
     */
    @SuppressWarnings("unchecked")
    private void threeWaySeqOrder(ArrayList<TestCase> testList) {
        // If the scores have already been computed, just sort by that score.
	if(testList.get(0).getThreeWaySeq(reductionSelection)!=-1){
	    sortDescending(testList, TestCase.PrioritizationValue.ThreeWay);
	    return;
	}
        // Main For loop, the index of which indicates how many of the test cases have been ordered.
        for (int i = 0; i < testList.size(); i++) {
            // Updates the appropriate progress bar.
            if(prioritizationSelection != null && prioritizationSelection != TestCase.PrioritizationValue.NONE){
                updateProgress((int) (((double) (i * 99)) / testList.size())+1, true);
            }
            else{
                updateProgress((int) (((double) (i * 99)) / testList.size())+1, false);
            }
            // Resets unsorted test case's scores to zero and resets the unsorted
            // test case's current index before the next run through
            for (int j = i; j<testList.size(); j++){
                testList.get(j).setThreeWaySeq(0,reductionSelection);
                testList.get(j).setCurrentIndex(j);
            }
            // Keeps track of the current highest score and the index of the testList which has it while iterating.
            int highestScore = -1;
            int indexOfHighest = i;
            vertexLoop:
            for (int vertex = 0; vertex < graph.size(); vertex++) {
                edgeLoop1:
                for (RegularEdge edge1 : graph.get(vertex)) {
                    //If the current edge is covered, skip to the next one.
                    if (edge1.isCovered())
                        continue edgeLoop1;
                    
                    // If the current has not forward test cases then skip to the
                        // next vertex, since all remaining edges only have backward
                        // edges which aren't considered in sequential ordering
                    if (edge1.getForwardTestCases().isEmpty())
                        continue vertexLoop;
                    int vertex2 = edge1.getConnectedVertex();
                    edgeLoop2:
                    for (RegularEdge edge2 : graph.get(vertex2)){
                        // If the current edge is covered, skip to the next one.
                        if (edge2.isCovered())
                            continue edgeLoop2;
                        
                        // If the current has not forward test cases then skip to the
                        // next edge, since all remaining edge2's only have backward
                        // edges which aren't considered in sequential ordering
                        if (edge2.getForwardTestCases().isEmpty())
                            continue edgeLoop1;
                        
                        // Don't count backward edges during sequential ordering.
                        // Also don't count three way edges that begin and end on the same URL.
                        if (encoder.haveSameURL(vertex, edge2.getConnectedVertex()))
                            continue edgeLoop2;
                        
                        // Stores the test cases that are common to both edges
                        LinkedList<TestCase> threeWayCoverage = new LinkedList<TestCase>();
                        
                        // Finds all test cases that cover both edge1 and edge2.
                        for (TestCase test : edge2.getForwardTestCases()){
                            if (edge1.getForwardTestCases().contains(test))  
                                threeWayCoverage.add(test);
                        }
                        
                        // Skip to next edge if edge1 and edge2 don't share any test cases.
                        if (threeWayCoverage.size() == 0)
                            continue edgeLoop2;
                        
                        // Determines if an edge has been covered or not, an edge
                        // is covered when all test cases in the forward test
                        // case list have been sorted.
                        edge1.setCoverage(true);
                        edge2.setCoverage(true);
                        boolean currentCovered = false;
                        tcLoop1:
                        for (TestCase covTest: edge1.getForwardTestCases()){
                            currentCovered = false;
                            if (covTest.getReduced()){
                                currentCovered=true;
                                continue tcLoop1;
                            }
                            sortLoop:
                            for (int sortIndex = 0; sortIndex < i; sortIndex++){
                                if(covTest.getIndex() == testList.get(sortIndex).getIndex()){
                                    currentCovered = true;
                                    continue tcLoop1;
                                }
                            }
                            if (!currentCovered)
                                break;
                        }
                        edge1.setCoverage(currentCovered);
                        tcLoop2:
                        for (TestCase covTest: edge1.getForwardTestCases()){
                            currentCovered = false;
                            if (covTest.getReduced()){
                                currentCovered=true;
                                continue tcLoop2;
                            }
                            sortLoop:
                            for (int sortIndex = 0; sortIndex < i; sortIndex++){
                                if(covTest.getIndex() == testList.get(sortIndex).getIndex()){
                                    currentCovered = true;
                                    continue tcLoop2;
                                }
                            }
                            if (!currentCovered)
                                break;
                        }
                        edge2.setCoverage(currentCovered);
                        if (edge1.isCovered())
                            continue edgeLoop1;
                        if (edge2.isCovered())
                            continue edgeLoop2;
                        
                        // Then checks if any of those test cases are any of the sorted ones 
                        // (ie, the three way pair is already covered by an existing test case)
                        for (int sortedTests = 0; sortedTests < i; sortedTests++){
                            for (TestCase coveringTest : threeWayCoverage){
                                if (coveringTest.getIndex() == testList.get(sortedTests).getIndex()){
                                    continue edgeLoop2;
                                }
                            }
                        }
                        
                        // If they are not sorted, increment each score.
                        for (TestCase toIncrement : threeWayCoverage){
                            if (reductionSelection != null && reductionSelection != TestCase.ReductionValue.NONE && toIncrement.getReduced())
                                continue;
                            int newScore = toIncrement.getThreeWaySeq(reductionSelection) + 1;
                            if (newScore > highestScore){
                                highestScore = newScore;
                                indexOfHighest = toIncrement.getCurrentIndex();
                            }
                            toIncrement.setThreeWaySeq(newScore,reductionSelection);
                        }
                    }
                }
            }
            // After iterating through vertices each time, take the highest test case and switch it with the next place.
            if (i != testList.size()-1)
                swapTestCases(i, indexOfHighest, testList);
        }
    }
    //</editor-fold>
    

    public boolean isSeq() {
        return ((prioritizationSelection == TestCase.PrioritizationValue.TwoWaySeq)
                || (prioritizationSelection == TestCase.PrioritizationValue.ThreeWaySeq));
    }
    //</editor-fold>
    //</editor-fold>

    //<editor-fold desc="Sorting and List Methods">

    protected void swapTestCases(int first, int second, ArrayList<TestCase> testList) {
        TestCase temp = testList.get(first);
        testList.set(first, testList.get(second));
        testList.set(second, temp);
    }

    protected void sortDescending(ArrayList<TestCase> testList, final TestCase.PrioritizationValue prioritizationSelection){
	Collections.sort(testList, new Comparator<TestCase>(){
	    @Override
		public int compare(TestCase t1, TestCase t2){
		    double val1=t1.getSortingValue(prioritizationSelection,reductionSelection);
		    double val2=t2.getSortingValue(prioritizationSelection,reductionSelection);
		    if(val1==val2)
			return 0;
		    if(val1>val2)
			return -1;
		    return 1;
		}
	    });
    }

    protected void sortAscending(ArrayList<TestCase> testList, final TestCase.PrioritizationValue prioritizationSelection){
	Collections.sort(testList, new Comparator<TestCase>(){
	    @Override
		public int compare(TestCase t1, TestCase t2){
		    double val1=t1.getSortingValue(prioritizationSelection,reductionSelection);
		    double val2=t2.getSortingValue(prioritizationSelection,reductionSelection);
		    if(val1==val2)
			return 0;
		    if(val1<val2)
			return -1;
		    return 1;
		}
	    });
    }
    //</editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Frequency Methods">

    protected void sortFrequencyDescending(ArrayList<TestCase> testList){
	Collections.sort(testList, new Comparator<TestCase>(){
	    @Override
		public int compare(TestCase t1, TestCase t2){
		    int val1=t1.getFrequencyValue(_selectionKey);
		    int val2=t2.getFrequencyValue(_selectionKey);
		    if(val1==val2)
			return 0;
		    if(val1>val2)
			return -1;
		    return 1;
		}
	    });
    }

    protected void removeFrequencies(ArrayList<TestCase> testList) {
        for (int i = 0; i < testList.size(); i++) {
            if (testList.get(i).getFrequencyValue(_selectionKey) > 0) {
                frequencyWebList.add(testList.get(i));
                testList.remove(i);
                i--;
            }
        }
    }

    protected void moveRemainingToTestList(ArrayList<TestCase> testList) {
        for (int i = 0; i < testList.size(); i++) {
            frequencyWebList.add(testList.get(i));
            testList.remove(i);
            i--;
        }
    }

    /*
     * This method creates a sequence of two URLs and adds it to the
     * frequencyPrioritizer object.
     */
    private void updateFrequencySequenceMap(final String previousURL, final String currentURL, final String session) {
        final String sequence = previousURL + "|" + currentURL;
        frequencyPrioritizer.addSequence(sequence, session);
    }

    public ArrayList<TestCase> getWebList() {
        return webList;
    }
    //</editor-fold>
}