/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cput;
import java.util.LinkedList;
/**
 *
 * @author Michael
 */
public class RegularEdge extends Edge{
    private LinkedList<TestCase> forwardTestCases;
    private LinkedList<TestCase> backwardTestCases;
    private LinkedList<TestCase> consecutiveTestCases;

    public RegularEdge(int cV, TestCase firstTestCase, boolean isForward){
	super(cV);
        forwardTestCases = new LinkedList<TestCase>();
        backwardTestCases = new LinkedList<TestCase>();
        consecutiveTestCases = new LinkedList<TestCase>();
        if (isForward)
            forwardTestCases.add(firstTestCase);
        else
            backwardTestCases.add(firstTestCase);
    }
    
    //used to create a copy of a an edge with all it's forward test cases in the other direction.
    public RegularEdge(int cV, LinkedList<TestCase> testCases){
	super(cV);
        forwardTestCases = new LinkedList<TestCase>();
        consecutiveTestCases = new LinkedList<TestCase>();
        backwardTestCases = new LinkedList<TestCase>(testCases);
    }
    
    //used to create an edge between consecutive urls
    public RegularEdge(int cV, TestCase firstTestCase, boolean isForward, boolean isConsecutive){
	super(cV);
        forwardTestCases = new LinkedList<TestCase>();
        backwardTestCases = new LinkedList<TestCase>();
        consecutiveTestCases = new LinkedList<TestCase>();
        if (isForward){
            forwardTestCases.add(firstTestCase);
        }
            consecutiveTestCases.add(firstTestCase);

    }

    public LinkedList<TestCase> getForwardTestCases() {
        return forwardTestCases;
    }

    public LinkedList<TestCase> getBackwardTestCases() {
        return backwardTestCases;
    }
    
    public LinkedList<TestCase> getConsecutiveTestCases(){
        return consecutiveTestCases;
    }
    
    @Override
    public LinkedList<TestCase> getApplicableTestCases(TestCase.ReductionValue reduction){
	if(reduction == TestCase.ReductionValue.HGS_2WayCon)
	    return consecutiveTestCases;
	if(reduction == TestCase.ReductionValue.HGS_2Way || reduction == TestCase.ReductionValue.Combinatorial_1Way || reduction == TestCase.ReductionValue.HGS_1Way){
	    LinkedList<TestCase> tests = new LinkedList<TestCase>();
	    tests.addAll(forwardTestCases);
	    for(int i=0; i<backwardTestCases.size(); i++)
		if(!tests.contains(backwardTestCases.get(i)))
		    tests.add(backwardTestCases.get(i));
	    return tests;
	}
	return forwardTestCases;
    }

    public void addForwardTestCase(TestCase tC) {
        if (!forwardTestCases.contains(tC)) {
            forwardTestCases.add(tC);
        }
    }
    
    public void addConsecutiveTestCase(TestCase tC){
        consecutiveTestCases.add(tC);
    }
    
    public void addBackwardTestCases(LinkedList<TestCase> tCs) {
        for (TestCase tC : tCs) {
            if (!backwardTestCases.contains(tC) && !forwardTestCases.contains(tC)) {
                backwardTestCases.add(tC);
            }
        }
    }   
}