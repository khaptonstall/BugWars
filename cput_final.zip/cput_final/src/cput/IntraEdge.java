
package cput;
import cput.TestCase.ReductionValue;
import java.util.LinkedList;
/**
 *
 * @author taranoble
 */
public class IntraEdge extends Edge{
    private LinkedList<TestCase> testCases;
    
    public IntraEdge(int connected, TestCase firstTestCase){
	super(connected);
        testCases = new LinkedList<TestCase>();
        testCases.add(firstTestCase);
    }
    
    //used in orderGraph()
    public IntraEdge(int connected, LinkedList<TestCase> testCases){
	super(connected);
        this.testCases = new LinkedList<TestCase>(testCases);
    }
    
    public void addTestCase(TestCase tc){
        if (!testCases.contains(tc))
            testCases.add(tc);
    }
    
    public void addTestCases(LinkedList<TestCase> tcs){
        for (TestCase tc : tcs){
            addTestCase(tc);
        }
    }

    @Override
    public LinkedList<TestCase> getApplicableTestCases(ReductionValue reduction) {
	return testCases;
    }
}