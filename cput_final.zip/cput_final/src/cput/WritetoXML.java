package cput;

/**
*
* @author Sachinkumar Jain
*/


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

import org.apache.log4j.Logger;

public class WritetoXML {

    /**
     * Reads the test_suite table and write the tests in an XML format to file
     * @param con connection to database
     * @param fdir the directory where the XML-format tests are to be created
     * @param XMLFileName a string that represents the XML file name. It is the same as the log file name with the extension .xml
     */
    String rootTag = "testSuite";                      // The root tag value

    Connection con = null;
    Logger logger = Logger.getLogger(WritetoXML.class);

    /**
     * Constructor that takes database connection and logger as input
     * @param con
     * @param logger
     */
    public WritetoXML(Connection con, Logger logger) {
        this.con = con;
        this.logger = logger;
    }
    /**
     * Default constructor
     *
     */
    public WritetoXML(){

    }
	
    /**
     * Method to read test_suite table and write to XML files
     * @param fdir target directory that will contain the XML test cases
     * @param XMLFileName filename of XML file that would contain all the test cases
     */
    public void parseTable(String fdir, String XMLFileName, DatabaseInfo dbInfo) {
        FileWriter fstream2 = null;
        String UrlComment = "";
        try{ //Write URL Comment to file before adding remaining info.
            if(dbInfo.getHasUniqueUrls())
                UrlComment = "<!--Unique-->\n";
            else{
                UrlComment = "<!--Not Unique";
                for(int i = 0; i < dbInfo.getParameters().length; i++){
                    //UrlComment += "|Param" + (i + 1) + "='" + dbInfo.getParameters()[i].trim() +  "'";
                    UrlComment += "|" + dbInfo.getParameters()[i].trim();
                }
                UrlComment += "-->\n";
            }
            fstream2 = new FileWriter(fdir+XMLFileName); //create stream to write every test case to single XML file
        }
        catch (IOException e3) {
            logger.error(e3);
        }
        BufferedWriter singleFileBuf = new BufferedWriter(fstream2);

        writeToOneFile(singleFileBuf, UrlComment);
        Statement stmt1 = null;

        try {
            stmt1 = con.createStatement();
        }
        catch (SQLException e2) {
            logger.error("Error creating statemtnt during create test cases");
            logger.error(e2);
        }
		
        ResultSet rs1 = null;
        //get test-ids of all test cases
        String query = "select distinct test_id from test_suite order by test_id;";


        try {
            rs1 = stmt1.executeQuery(query);
        }
        catch (SQLException e2) {
            logger.error("Problem while executing the query :\n"+query);
            logger.error(e2);
        }
        writeToOneFile(singleFileBuf, "<"+ rootTag +">\n");


        if(rs1!=null) {
            try {
                while(rs1.next()) {
                    int test_id = rs1.getInt("test_id");
                    String fname = test_id+".XML";
                    FileWriter fstream1 = null;
                    try {
                        fstream1 = new FileWriter(fdir+fname);        //create stream to write every test case to individual XML file

                    }
                    catch (IOException e3) {
                        e3.printStackTrace();
                    }
                    BufferedWriter multipleFileBuf = new BufferedWriter(fstream1);
                    writeToOneFile(multipleFileBuf, UrlComment);

                    writeToOneFile(multipleFileBuf, "<"+ rootTag +">\n");
                    String text = "<session id=\"" +fname+"\">\n";
                    writeToFile(multipleFileBuf, singleFileBuf, text);

                    Statement stmt2 = null;
                    try {
                        stmt2 = con.createStatement();
                    }
                    catch (SQLException e2) {
                        logger.error("Error creating statemtnt during creating test cases");
                        logger.error(e2);
                    }
                    ResultSet rs2 = null;
                    //get all rows for each test case
                    String innerQuery = "select " +
                                        "ltrim(rtrim(method)) method, "+
                                        "ltrim(rtrim(url)) url, "+
                                        "ltrim(rtrim(postdata)) postdata "+
                                        "from test_suite "+
                                        "where test_id = "+ test_id +
                                        "order by row_id;";

                    try {
                        rs2 = stmt2.executeQuery(innerQuery);
                    }
                    catch (SQLException e2) {
                        logger.error("Problem while executing the query :\n"+innerQuery);
                        logger.error(e2);
                    }
                    if (rs2 != null) {
                        while(rs2.next()) {
                            String fileText="";
                            String method   = rs2.getString("method");
                            String url	    = rs2.getString("url");

                            String tempUrl = "";
                            tempUrl = url.replace("\\", "\\\\");
                            url = tempUrl;
                            tempUrl = url.replace("<script>", "");
                            url = tempUrl;
                            tempUrl = url.replace("</script>", "");
                            url = tempUrl;
                            tempUrl =url.replace("<", "&lt;");
                            url = tempUrl;
                            tempUrl = url.replace(">", "&gt;");
                            url = tempUrl;

                            String postData = rs2.getString("postdata");

                            if (method.equals("GET")) {
                                if(url.contains("?")) {
                                    int pos = url.indexOf("?");
                                    String dataPart = url.substring(pos+1, url.length());
                                    url = url.substring(1, pos);

                                    fileText = fileText + "<url>\n" +  "\t<request_type>"+method+"</request_type>\n"+"\t<baseurl>"+url+"</baseurl>\n";
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                    fileText = "";

                                    fileText = getNameValuePair(dataPart);
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                }
                                else {
                                    fileText = fileText + "<url>\n" +  "\t<request_type>"+method+"</request_type>\n"+"\t<baseurl>"+url+"</baseurl>\n";
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                }
                                writeToFile(multipleFileBuf, singleFileBuf, "</url>\n");
                            } //End if(method = GET)
                            else if(method.equals("POST")) {
                                if(url.contains("?")) {
                                    int pos = url.indexOf("?");
                                    String dataPart = url.substring(pos+1, url.length());
                                    url = url.substring(1, pos);

                                    fileText = "<url>\n" +  "\t<request_type>"+method+"</request_type>\n"+"\t<baseurl>"+url+"</baseurl>\n";
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                    String data = postData.substring(9, postData.length());
                                    fileText = getNameValuePair(data);
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);

                                    fileText = getNameValuePair(dataPart);
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                }
                                else {
                                    fileText = "<url>\n" +  "\t<request_type>"+method+"</request_type>\n"+"\t<baseurl>"+url+"</baseurl>\n";
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                    String data = postData.substring(9, postData.length());
                                    fileText = getNameValuePair(data);
                                    writeToFile(multipleFileBuf, singleFileBuf, fileText);
                                }
                                writeToFile(multipleFileBuf, singleFileBuf, "</url>\n");
                            }// End if method is post
                        }			//end of inner while loop
                    }
                    writeToFile(multipleFileBuf, singleFileBuf, "</session>\n");
                    writeToOneFile(multipleFileBuf, "</"+ rootTag +">\n");

                    try {
                        multipleFileBuf.close();
                    }
                    catch (IOException e) {
                        logger.error(e);
                    }

                }   //end of outer while loop
                writeToOneFile(singleFileBuf, "</"+ rootTag +">\n");
                try {
                    singleFileBuf.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
            catch (SQLException e) {
                logger.error("Problem executing while loop in rs1");
                logger.error(e);
            }
        }   //end of if loop
    }   //end of function parseTable
	
	
    /**
    * Writes data to the file.
    * @param FileBuf stream to which data is to be written.
    * @param fileText data to be written to file.
    */

    void writeToOneFile(BufferedWriter FileBuf, String fileText) {
        try {
            FileBuf.write(fileText);
        }
        catch (IOException e1) {
            logger.error("Unable to write to file");
            logger.error(e1);
        }
    }
	
    /**
    * Writes data to files (both individual test case file and a single file that contains all test cases)
    * @param multipleFileBuf stream that connects to individual test case file
    * @param singleFileBuf stream that connects to single file that contains all test cases
    * @param fileText data to be written to file
    */
    void writeToFile(BufferedWriter multipleFileBuf, BufferedWriter singleFileBuf, String fileText) {
        try {
            multipleFileBuf.write(fileText);
            singleFileBuf.write(fileText);
        }
        catch (IOException e1) {
            logger.error("Unable to write to file");
            logger.error(e1);
        }
    }
	
    /**
    * Returns the name-value pairs in required XML format
    * @param data the name-values pairs as they appear in the test_suite_table
    */
    String getNameValuePair(String data) {
        int cnt = (data.split("&")).length;
        String []nameValue = data.split("&");
        String fileText = "";

        for(int i = 0; i < cnt; i++) {
            String []pair = nameValue[i].split("=");
            //This check is needed to exclude scripts from messing up the xml file.
            if(pair.length > 1){
                if(((!pair[0].contains("<script>") && !pair[0].contains("</script>")))
                        && ((!pair[1].contains("<script>") && !pair[1].contains("</script>")))){

                    //Escape angle brackets
                    String tempPair0 = "";
                    tempPair0 = pair[0].replace("<", "&lt;");
                    pair[0] = tempPair0;
                    tempPair0 = pair[0].replace(">", "&gt;");
                    pair[0] = tempPair0;

                    String tempPair1 = "";
                    tempPair1 = pair[1].replace("<", "&lt;");
                    pair[1] = tempPair1;
                    tempPair1 = pair[1].replace(">", "&gt;");
                    pair[1] = tempPair1;


                    fileText = fileText +"\t<param>\n"+"\t\t<name>"+pair[0]+"</name>\n";
                    try  {
                        fileText = fileText + "\t\t<value>"+pair[1]+"</value>\n";
                    }
                    catch(Exception e) {
                        fileText = fileText + "\t\t<value></value>\n";
                    }
                    fileText = fileText + "\t</param>\n";
                }
            }
        }// End of for loop
        return fileText;
    }   //End of function getNameValuePair
}   //end of class

