
package cput;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author chelynn
 */
public class VertexEncoder {
    private int nextIndex;
    private HashMap<String, Integer> verticeMap;
    private ArrayList<String> reverseMapping;
    
    public VertexEncoder(){
        nextIndex = -1;
        verticeMap = new HashMap<String, Integer>();
        reverseMapping = new ArrayList<String>();
    }
    
    public int encode(String url, String param, String value){
        String vertex = url+" "+param+"-"+value;
        if(verticeMap.containsKey(vertex)){
            return verticeMap.get(vertex);
        }
        nextIndex++;
        verticeMap.put(vertex, nextIndex);
        reverseMapping.add(nextIndex, vertex);
        return nextIndex;
    }
    
    public String getURL(int vertexId){
        String vertex=reverseMapping.get(vertexId);
        return vertex.substring(vertex.indexOf(' '));
    }
    
    public String getHashKey(int vertexId){
        return reverseMapping.get(vertexId);
    }
    
    public boolean haveSameURL(int vertex1Id, int vertex2Id){
        String vertex_one=reverseMapping.get(vertex1Id);
        String vertex_two=reverseMapping.get(vertex2Id);
        vertex_one=vertex_one.substring(0, vertex_one.indexOf(' '));
        vertex_two=vertex_two.substring(0, vertex_two.indexOf(' '));
        return(vertex_one.equals(vertex_two));
    }
}