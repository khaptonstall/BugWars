
package cput;

import java.util.*;

/**
 * @author Chelynn
 */
//Possible optimization: mark triples as covered
public class HGS3WayReducer {
    
    private ArrayList<List<RegularEdge>> graph;
    private ArrayList<ThreeWayEdge> allTriples;
    private TestCase.ReductionValue reductionType;
    private ArrayList<TestCase> testList;
    private MainScreen view;
    private VertexEncoder encoder;
    
    HGS3WayReducer(MainScreen theView, ArrayList<List<RegularEdge>> theGraph, ArrayList<TestCase> theTestList, TestCase.ReductionValue reduction, VertexEncoder theEncoder){
        testList=theTestList;
        testList.clear();
        graph=theGraph;
        reductionType=reduction;
	view=theView;
        encoder = theEncoder;
        allTriples = new ArrayList<ThreeWayEdge>();
        buildTripleList();
    }
    
   private void buildTripleList(){
        for (int vertex = 0; vertex < graph.size(); vertex++){
	    view.updateProgress((int)((double)vertex*75)/graph.size(),false);
            for (RegularEdge edge1 : graph.get(vertex)){
                //get the vertex that edge leads to, and loop through all its edges
                edgeLoop:
                for (RegularEdge edge2 : graph.get(edge1.getConnectedVertex()))
                {
                    //check if edge1 and edge2 are already covered by another test
                    for (TestCase sortedTest : testList){
                        if (edge1.getApplicableTestCases(reductionType).contains(sortedTest) && edge2.getApplicableTestCases(reductionType).contains(sortedTest)){
                            sortedTest.setHGS(sortedTest.getHGS()+1);
                            continue edgeLoop; 
                        }
                    }
                    //if the beginning and ending vertex are not on the same URL
                    if (!encoder.haveSameURL(vertex, edge2.getConnectedVertex())){
                        ArrayList<TestCase> tests = new ArrayList<TestCase>();
                       
                        for (TestCase test : edge1.getApplicableTestCases(reductionType)){
                            //if both edges contain the same test case, add it to tests
                            if (edge2.getApplicableTestCases(reductionType).contains(test))
                                    tests.add(test);
                        }
                        //if there is only one test (a cardinality of one), just mark that as covered
                        if (tests.size() == 1){
                            tests.get(0).setHGS((tests.get(0).getHGS()+1));
                            testList.add(tests.get(0));
                        }
                        //if they have common tests, then it is a triple, so add it to the allTriples list
                        else if(!tests.isEmpty()){
                            ThreeWayEdge triple = new ThreeWayEdge(vertex, edge1.getConnectedVertex(), edge2.getConnectedVertex(), tests);
                            allTriples.add(triple);
                        }
                    }
                }
            }
        }
        sortDescending(testList);
    }
    
    public ArrayList<TestCase> reduce() {
	int biggestCardinalityLeft = 1;
	int curCardinality = 0;
        
        //triplesToCover 1 and 2 together represent the three way edges, 
        //with corresponding indices holding the two parts of a three way edge.
        //tests between represents the tests that cover those Edges
        ArrayList<ThreeWayEdge> triplesToCover = new ArrayList<ThreeWayEdge>();

        ArrayList<TestCase> coveringTests = new ArrayList<TestCase>();	//holds all tests that cover the edges
        ArrayList<Integer> coveringTestScores = new ArrayList<Integer>();	//how many edges each test covers
        
	while(biggestCardinalityLeft>curCardinality){
		curCardinality++;
                triplesToCover.clear();
                coveringTests.clear();
                coveringTestScores.clear();

                biggestCardinalityLeft = getEdgesOfCardinality(curCardinality, triplesToCover, coveringTests, coveringTestScores);
                System.out.println("BIGGEST CARDINALITY LEFT: " +biggestCardinalityLeft);
		double progress=(((double)curCardinality*25)+75)/biggestCardinalityLeft;
		view.updateProgress((int)progress, false);
		double edgeCount=triplesToCover.size();
                //this loop continues until all edges are covered
                while(triplesToCover.size()>0){
                        double edgePercent=((((edgeCount-triplesToCover.size())*25)+75)/edgeCount)/biggestCardinalityLeft;
                        
                        view.updateProgress((int)(edgePercent+progress), false);
                        //gets the best test case, and adds it to the test list
                        TestCase bestTest = getMaximumCoveringTest(coveringTests, coveringTestScores);
                        testList.add(bestTest);

                        //update coverage array lists
                        for(int curTriple = 0; curTriple < triplesToCover.size(); curTriple++){
                                ThreeWayEdge triple = triplesToCover.get(curTriple);
                                ArrayList<TestCase> allEdgeTests = triple.getCommonTests();
                                if(allEdgeTests.contains(bestTest)){
                                        triplesToCover.remove(curTriple);
                                        curTriple--;
                                        for(int curTest = 0; curTest < allEdgeTests.size(); curTest++)
                                        {
                                                TestCase tc = allEdgeTests.get(curTest);
                                                int testIndex = coveringTests.indexOf(tc);
                                                coveringTestScores.set(testIndex, coveringTestScores.get(testIndex) - 1);
                                            
                                        }
                                }
                        }
                }
        }
        return testList;
    }
    
    //gets the coverage arrays for how many edges each test case covers
    private void getCoveringTests(ThreeWayEdge triple, ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestScores) {
        ArrayList<TestCase> allEdgeTests = triple.getCommonTests();

        for (TestCase testCase : allEdgeTests){ 
            int index = coveringTests.indexOf(testCase);
            if (index != -1) //the current test case is already in the array, so increment score
            {
                coveringTestScores.set(index, coveringTestScores.get(index) + 1);
            } else {			//add it to the covering tests array and give it a score of 1
                coveringTests.add(testCase);
                coveringTestScores.add(1);
            }

        }
    }

    //fill triplesToCover with all the edges with a given cardinality that are uncovered, then return if there are more edges to be covered
    //calls getCoveringTests to fill coveringTests with the tests that cover the uncovered edges,
    //and it also puts the counts of how many edges each test covers into coveringTestScores
    private int getEdgesOfCardinality(int curCardinality, ArrayList<ThreeWayEdge> triplesToCover, ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestScores){
        int maxCardinality = curCardinality;
        for (ThreeWayEdge triple : allTriples) {
            int cardinality = triple.getCommonTests().size();
            if (cardinality == curCardinality && !isCovered(triple)) {
                triplesToCover.add(triple);
                getCoveringTests(triple, coveringTests, coveringTestScores);
            } else if (cardinality > maxCardinality && !isCovered(triple)) {
                    maxCardinality = cardinality;
            }
        }
	return maxCardinality;
    }

    //returns whether an edge has already been covered by tests added so far
    private boolean isCovered(ThreeWayEdge triple){
        ArrayList<TestCase> allTests = triple.getCommonTests();
	for(int curTestCase = 0; curTestCase < allTests.size(); curTestCase++){
            TestCase testCase = allTests.get(curTestCase);
		if(testList.contains(testCase))
			return true;
        }
        
        if(reductionType == TestCase.ReductionValue.HGS_3Way){
            if (!triple.sequentialVertices())
            //this case is covered in the backwards version. 
                return true;
        }
	return false;
    }

    //determines which test case has the maximum coverage
    private TestCase getMaximumCoveringTest(ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestScores){
	int maxScore =- 1;
	TestCase maxTest = null;
        for (int i = 0; i < coveringTests.size(); i++){
            if (coveringTestScores.get(i) > maxScore){
                maxScore = coveringTestScores.get(i);
                maxTest = coveringTests.get(i);
            }
        }
        return maxTest;
    }
    
     protected void sortDescending(ArrayList<TestCase> testList){
	Collections.sort(testList, new Comparator<TestCase>(){
	    @Override
		public int compare(TestCase t1, TestCase t2){
		    int val1=t1.getHGS();
		    int val2=t2.getHGS();
		    if(val1==val2)
			return 0;
		    if(val1>val2)
			return -1;
		    return 1;
		}
	    });
    }
}
