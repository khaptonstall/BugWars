package cput;

import java.io.File;

/**
 * This class is used with the JFileChooser to filter displayed files.  It is used
 * to display only TXT files.
 * @author Michael
 */
public class TXTFileFilter extends javax.swing.filechooser.FileFilter {
    public boolean accept(File f) {
        return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
    }

    public String getDescription() {
        return ".txt files";
    }
}
