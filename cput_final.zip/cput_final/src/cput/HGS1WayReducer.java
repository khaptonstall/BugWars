/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cput;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Chelynn
 */
public class HGS1WayReducer {
    
    private ArrayList<List<RegularEdge>> graph;
    private ArrayList<TestCase> testList;
    private MainScreen view;
    ArrayList<Integer> vertices;
    ArrayList<List<TestCase>> verticeTests;
    
    HGS1WayReducer(MainScreen theView, ArrayList<List<RegularEdge>> theGraph, ArrayList<TestCase> theTestList){
        testList=theTestList;
        testList.clear();
        graph=theGraph;
	view=theView;
	vertices=new ArrayList<Integer>();
	verticeTests = new ArrayList<List<TestCase>>();
	initialize();
    }
    
    public ArrayList<TestCase> reduce() {
	int biggestCardinalityLeft = 1;
	int curCardinality = 0;
        
        ArrayList<Integer> verticesToCover = new ArrayList<Integer>();
        ArrayList<TestCase> coveringTests = new ArrayList<TestCase>();	//holds all tests that cover the edges
        ArrayList<Integer> testScores = new ArrayList<Integer>();	//how many edges each test covers
        
	while(biggestCardinalityLeft>curCardinality){
		curCardinality++;
                verticesToCover.clear();
                coveringTests.clear();
                testScores.clear();

                biggestCardinalityLeft = getVerticesOfCardinality(curCardinality, verticesToCover, coveringTests, testScores);
		double progress=((double)curCardinality*100)/biggestCardinalityLeft;
		view.updateProgress((int)progress, false);
		double verticeCount=verticesToCover.size();
                //this loop continues until all edges are covered
                while(verticesToCover.size()>0){
		    double edgePercent=(((verticeCount-verticesToCover.size())*100)/verticeCount)/biggestCardinalityLeft;
		    view.updateProgress((int)(edgePercent+progress), false);
                        //gets the best test case, and adds it to the test list
                        TestCase bestTest=getMaximumCoveringTest(curCardinality, coveringTests, testScores);
                        testList.add(bestTest);

                        //update coverage array lists
                        for(int curVertex = 0; curVertex < verticesToCover.size(); curVertex++){
				List<TestCase> tests = verticeTests.get(verticesToCover.get(curVertex));
				if(tests.contains(bestTest)){
                                        for(int curTest = 0; curTest < tests.size(); curTest++)
                                        {
                                                int testIndex = coveringTests.indexOf(tests.get(curTest));
                                                testScores.set(testIndex, testScores.get(testIndex) - 1);
                                        }
					verticesToCover.remove(curVertex);
                                        curVertex--;
				}
			}
			int bestTestIndex = coveringTests.indexOf(bestTest);
			coveringTests.remove(bestTestIndex);
			testScores.remove(bestTestIndex);
		}
	}
	return testList;
    }
    
    private void initialize(){
	for(int curVertex = 0; curVertex <graph.size(); curVertex++){
	    vertices.add(curVertex);
	    verticeTests.add(new ArrayList<TestCase>());
	}
	for(int curVertex = 0; curVertex <graph.size(); curVertex++){
	    List<TestCase> tests = verticeTests.get(curVertex);
	    List<RegularEdge> edges = graph.get(curVertex);
	    for(int curEdge = 0; curEdge < edges.size(); curEdge++){
		RegularEdge e = edges.get(curEdge);
		List<TestCase> testCases = e.getApplicableTestCases(TestCase.ReductionValue.HGS_1Way);
		for(int i = 0; i < testCases.size(); i++){
		    TestCase t = testCases.get(i);
		    if(!tests.contains(t))
			tests.add(t);
		    if(!verticeTests.get(e.getConnectedVertex()).contains(t))
			verticeTests.get(e.getConnectedVertex()).add(t);
		}
	    }
	}
    }
    
    //gets the coverage arrays for how many edges each test case covers
    private void addCoveringTests(int vertexIndex, ArrayList<TestCase> coveringTests, ArrayList<Integer> testScores){
        for(int curTestCase = 0; curTestCase < verticeTests.get(vertexIndex).size(); curTestCase++){
		TestCase testCase = verticeTests.get(vertexIndex).get(curTestCase);
		int index = coveringTests.indexOf(testCase);
		if(index != -1)		//the current test case is already in the array, so increment score
			testScores.set(index, testScores.get(index)+1);
		else {			//add it to the covering tests array and give it a score of 1
			coveringTests.add(testCase);
			testScores.add(1);
		}
	}
    }

    //fill verticesToCover with all the edges with a given cardinality that are uncovered, then return if there are more edges to be covered
    //calls getcoveringTests to fill coveringTests with the tests that cover the uncovered edges,
    //and it also puts the counts of how many edges each test covers into coveringTestscores
    private int getVerticesOfCardinality(int curCardinality, ArrayList<Integer> verticesToCover, ArrayList<TestCase> coveringTests, ArrayList<Integer> testScores){
        int maxCardinality=curCardinality;
	for(int curVertex = 0; curVertex < vertices.size(); curVertex++){
	    if(!isCovered(curVertex)){
		int cardinality = verticeTests.get(curVertex).size();
		if(cardinality == curCardinality){
		    verticesToCover.add(vertices.get(curVertex));
		    addCoveringTests(curVertex, coveringTests, testScores);
		}
		else if(cardinality > maxCardinality)
		    maxCardinality = cardinality;
	    }
	}
	return maxCardinality;
    }
    
    private boolean isCovered(int vertex){
	List<TestCase> tests = verticeTests.get(vertex);
	for(int curTest = 0; curTest < tests.size(); curTest++)
	    if(testList.contains(tests.get(curTest)))
		return true;
	return false;
    }

    //determines which test case has the maximum coverage
    private TestCase getMaximumCoveringTest(int curCardinality, ArrayList<TestCase> coveringTests, ArrayList<Integer> coveringTestscores){
	int maxScore =- 1;
	for(int index = 0; index < coveringTests.size(); index++){
		if(coveringTestscores.get(index) > maxScore)
			maxScore = coveringTestscores.get(index);
	}
	ArrayList<TestCase> maxTests = new ArrayList<TestCase>();
	for(int index = 0; index < coveringTests.size(); index++)
		if(coveringTestscores.get(index) == maxScore)
			maxTests.add(coveringTests.get(index));
	if(maxTests.size() == 1)
		return maxTests.get(0);
	return tieBreak(curCardinality, maxTests);
    }

    //breaks ties between test cases
    private TestCase tieBreak(int curCardinality, ArrayList<TestCase> tiedTests){
        ArrayList<Integer> verticesToCover = new ArrayList<Integer>();
	ArrayList<TestCase> coveringTests = new ArrayList<TestCase>();	//holds all tests that cover the edges
	ArrayList<Integer> testScores = new ArrayList<Integer>();	//how many edges each test covers
	int biggestCardinalityLeft = getVerticesOfCardinality(curCardinality + 1, verticesToCover, coveringTests, testScores);
	view.updateProgress((int)(((double)curCardinality*100)/biggestCardinalityLeft), false);
	for(int index = 0; index < coveringTests.size(); index++){
		if(!tiedTests.contains(coveringTests.get(index))){
			coveringTests.remove(index);
			testScores.remove(index);
			index--;
		}
	}
	if((verticesToCover.isEmpty() && biggestCardinalityLeft>curCardinality) || coveringTests.isEmpty()){
		Random rand=new Random();
		return tiedTests.get(rand.nextInt(tiedTests.size()));
	}
	return getMaximumCoveringTest(curCardinality+1, coveringTests, testScores);
    }
}