package cput;

/**
 * Class the contains a pair of tuples.  Each tuple contains its parameter name
 * and value and can be hashed together to ensure the same pair isn't covered
 * by a later session. 
 * @author Devin Minson & Schuyler Manchester
 */
public class TwoWayPair {
    private InputParameter first;
    private InputParameter second;

    /**
     *
     * @param first
     * @param second
     */
    public TwoWayPair(InputParameter first, InputParameter second){
        this.first = first;
        this.second = second;
    }

    /**
     * Creates a hash value of both parameters name and values.  It checks to see
     * which tuple has a lower value and ensures it be placed first.  This will make
     * sure that a pair A-B can't be counted as B-A a second time.
     * @return String key
     */
    public String createHashKey(){
        String key;
        if(first.createHash().compareTo(second.createHash()) <= 0)
            key = first.createHash() + ":" + second.createHash();
        else
            key = second.createHash() + ":" + first.createHash();
        return key;
    }
    
    /**
     * Creates a hash value of both parameters name and values.  
     * The ordering of first and second is relevant.
     * @return String key
     */
    public String createHashKeySeq(){
        String key;
        key = first.createHash() + ":" + second.createHash();
        return key;
    }

    /**
     * Creates a reverse hash value of both parameters name and values.  It checks to see
     * which tuple has a lower value and ensures it be placed second.  This function
     * is only used as a check when placing pairs in the hashtable.
     * @return String key
     */
    public String createReverseHashKey(){
        String key;
        if(first.createNonURLHash().compareTo(second.createNonURLHash()) > 0)
            key = first.createNonURLHash() + ":" + second.createNonURLHash();
        else
            key = second.createNonURLHash() + ":" + first.createNonURLHash();
        return key;

    }
    
    /**
     * Creates a reverse hash value of both parameters name and values.  It checks to see
     * which tuple has a lower value and ensures it be placed second.  This function
     * is only used as a check when placing pairs in the hashtable.
     * @return String key
     */
    public String createReverseHashKeySeq(){
        String key;
        key = first.createNonURLHash() + ":" + second.createNonURLHash();
        return key;

    }
}
