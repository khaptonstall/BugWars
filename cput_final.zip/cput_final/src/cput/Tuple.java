package cput;

/**
 * Class to store the tuple used in the two way priorization.
 * @author Devin Minson & Schuyler Manchester
 */
public class Tuple {
    private String URL;  //base URL of the request type
    private String param;
    private String value;
    protected boolean isUsed;

    /**
     *
     * @param baseURL
     * @param param
     * @param value
     */
    public Tuple(String baseURL, String param, String value){
        this.URL = baseURL;
        this.param = param;
        this.value = value;
        isUsed = false;
    }

    /**
     * Returns the baseURL of this parameter.  If two parameters have the same URL
     * they won't be paired
     * @return String URL
     */
    public String getURL(){
        return this.URL;
    }

    /**
     * creates a hash key for this tuple.  It includes the URL to ensure that an
     * identical parameter from the same URL isn't added to the list again.
     * @return String hashValue
     */
    public String createHash(){
        return URL + "-" + param + "-" + value;
    }

    /**
     * Creates a hash based soley on the name and value of the parameter.  This
     * will be stored in a hashtable accessed by all sessions.  Not including the
     * URL ensures that an identical pair won't be counted twice, regardless of session
     * @return String hashValue
     */
    public String createNonURLHash(){
        return param + "-" + value;
    }


}
