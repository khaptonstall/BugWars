/**
 * Class CreateTestCases.java
 * Version      : 1.0
 * Developed By : Jain Sachinkumar
 * Date         : 02-22-2010
 * This class reads the log_data table, applies heuristics to generate test cases and inserts test cases 
 * into test_suite table.
 * It uses test_id as sequence number to generate unique test id.
 * 
 */
package cput;

/**
*
* @author Sachinkumar Jain
*/


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class CreateTestCases {

    /**
     * Description	: This is the main function for this class that applies the heuristics, creates the test cases and inserts test cases into the database table.
     * @param con	: the connection to database.
     */

    boolean rollbackFlag = false;
    Connection con = null;
    Logger logger = Logger.getLogger(CreateTestCases.class);
    int startRowNum = 0;

    /**
     * Constructor with connection, logger and starting row num (starting row number to start creating test cases)
     * @param con
     * @param logger
     * @param startRowNum
     */
    public CreateTestCases(Connection con, Logger logger, int startRowNum) {
            this.con = con;
            this.logger = logger;
            this.startRowNum = startRowNum;
    }
    /**
     * Default constructor
     *
     */
    public CreateTestCases(){

    }
    /**
     * Function that decides whether to use the with_cookie algorithm or the with_ip_address_only algorithm
     *
     */
    public void generateTestCase() {
        int countCookieNull = 0, countCookieNotNull = 0;
        Statement stmt = null;

        stmt = createMyStatement(con);
        ResultSet results = null;

        String queryText = null;

        //The query to get information from log_data table to determine the ratio of number of rows with cookie value null and rows that have cookie.
        //The ratio will decide as which test case generation algorithm should be used.
        //The calculation is as follows
        //If 10% of total rows is >= total number of rows with cookie value null, then we will go with algorithm to generate test cases based on Cookies
        //else we will use algorithm to generate test cases based on IP address.

        //if cookie is null incremenet null_cookie_counter, else increment cookie_counter
        //in this query, A represents null_cookie and B represents cookie_present
        //retrieve number of A's and number of B's later in the method
        queryText = "SELECT COUNT(*) cnt, " +
                    "case when cookie = ' (null) ' then 'A' else 'B' end as cookie_value "+
                    "FROM log_data " +
                    "WHERE rownum > " + startRowNum +
                    "GROUP BY cookie_value ORDER BY cookie_value;";
        try {
            results = stmt.executeQuery(queryText);
        }
        catch (SQLException e) {
            logger.error(e);
            rollbackFlag = true;
            return;
        }
        // if query executed successful
        if (results != null) {
            //I know that there will be only two rows.
            try {
                if(results.next())
                    countCookieNull = results.getInt("cnt"); //since results are ordered by cookie_value, A's will be first and B's will be next
                if(results.next())
                    countCookieNotNull = results.getInt("cnt");
            }
            catch (SQLException e) {
                logger.error(e);
                rollbackFlag = true;
                return;
            }
        }
        try {
            results.close();
        }
        catch (SQLException e) {
            logger.error(e);
            rollbackFlag = true;
            return;
        }
        int totalRowCount = countCookieNull + countCookieNotNull;

        //if 10% of total row count is more than the number of rows where cookie is null, then the with_ip_address_only algorithm is used
        if((0.1*totalRowCount)>=countCookieNull) {
            generateTestCaseCookie(con);
            logger.debug("Algorithm for test case generation called based of Cookie");
        }
        else {
            generateTestCaseIPAddress(con);
            logger.debug("Algorithm for test case generation called based of IP Addresses");
        }
    } // End function

    /**
     * Function that is called when cookies are not present in the raw web log data
     * @param con
     */
    private void generateTestCaseIPAddress(Connection con) {
        String cookie = null;
        String ip = null;
        String method = null;
        String url = null;
        String postData = null;
        String date_string = null;
        String time_string = null;
        String postFile = null;
        @SuppressWarnings("unused")
        String referrer = null;
        int unix_time = 0;
        int rownum = 0;
        int testCaseId;

        String tuple = null;

        Statement stmt = null;

        stmt = createMyStatement(con);

        ResultSet results = null;
        String queryText = null;

        /*
         * Query to get all the rows from log_data table where rownum > startRowNum (particularly useful for append, where we need to append after a certain number)
         * All the columns are self explanatory. Attribute unix_time is derived from date_string and time_string
         *
         */

        queryText = "SELECT " +
                    "rownum , " +
                    "extract (epoch FROM to_timestamp(date_string||' '||time_string,'yyyy-mm-dd hh24:mi:ss'))::integer unix_time, " +
                    "date_string, "+
                    "time_string, "+
                    "method , " +
                    "ip , " +
                    "cookie , " +
                    "url , "+
                    "postdata, "+
                    "referrer, "+
                    "postfile " +
                    "FROM log_data " +
                    "WHERE url not like '%ico%' AND url not like '%gif%' AND url not like '%jpg%;' "+
                    "AND rownum > " + startRowNum +" "+
                    "ORDER BY rownum";

        /**
         * Execute the query. If there are any errors, log it to error.log file.
         */

        try {
            results = stmt.executeQuery(queryText);
        }
        catch (SQLException e) {
            logger.error(e);
            rollbackFlag = true;
            return;
        }

        if (results != null) {
            try {
                while(results.next()) {
                     //For each row, fetch all the values from result set.
                    rownum 		= results.getInt("rownum");
                    unix_time 	= results.getInt("unix_time");
                    cookie 		= results.getString("cookie");
                    ip 			= results.getString("ip");
                    url 		= results.getString("url");
                    postData 	= results.getString("postdata");
                    method 		= results.getString("method");
                    date_string = results.getString("date_string");
                    time_string = results.getString("time_string");
                    postFile 	= results.getString("postfile");
                    referrer    = results.getString("referrer");
                    Statement stmt1 = null;
                    stmt1 = createMyStatement(con);

                    ResultSet r1 = null;
                    //Retrieve the last row from test_suite table IP is same as current row's.

                    //ToDo: Check if I can add one more condition in where clause like
                    //      referrer of current row is same as url of the last row from test_suite table.
                    queryText = "SELECT row_id,unix_time, test_id from "+
                                "(	select row_id, "+
                                "test_id, "+
                                "extract (epoch FROM to_timestamp(date_string||' '||time_string,'yyyy-mm-dd hh24:mi:ss'))::integer unix_time, "+
                                "RANK() OVER (order by row_id desc) as pos "+
                                "FROM test_suite "+
                                "WHERE ip = '"+ ip +"' " +
                                "AND row_id > "+ startRowNum +
                                ") as foo "+
                                "WHERE pos = 1;";

                    r1 = stmt1.executeQuery(queryText);
                    if(r1 != null) {
                        boolean flag = true;
                        flag = r1.next();
                        if (flag == false) {
                            //there are no rows  in response to above select query, and create a new test case
                            //	start of new test case
                            testCaseId = getSequenceNo(con);
                            url = sanitizeUrl(url);
                            cookie = sanitizeCookie(cookie);
                            referrer = sanitizeReferrer(referrer);
                            postData = sanitizePostData(postData);
                            tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                            insertToTest_Suite(tuple, con);
                        }
                        else {
                            //if multiple rows are returned,
                            // this part is to check if timestamp is greater than 45 min or less
                            // if less than 45 minutes then it belongs to same test case
                            // else new test case is to be created
                            if(unix_time - r1.getInt("unix_time")  <= 2700) {
                                //this row belongs to the same test case
                                //get the existing test case id and create a test case
                                testCaseId = r1.getInt("test_id");
                                url = sanitizeUrl(url);
                                cookie = sanitizeCookie(cookie);
                                referrer = sanitizeReferrer(referrer);
                                postData = sanitizePostData(postData);
                                tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                                insertToTest_Suite(tuple, con);
                            }
                            else {
                                //New test case needs to be created
                                testCaseId = getSequenceNo(con);
                                url = sanitizeUrl(url);
                                cookie = sanitizeCookie(cookie);
                                referrer = sanitizeReferrer(referrer);
                                postData = sanitizePostData(postData);
                                tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                                insertToTest_Suite(tuple, con);
                            }
                        }
                    }
                    r1.close();
                }   //end of main while loop
            }
            catch (SQLException e) {
                logger.error(e);
                rollbackFlag = true;
                return;
            }
        }   //end of main outer if
        try {
            results.close();
        }
        catch (SQLException e) {
            logger.error(e);
            rollbackFlag = true;
            return;
        }
    }  // end of function generateTestCaseIPAddress()

    public String sanitizeUrl(String url) {
        if(url != null) {
            String tempUrl = "";
            tempUrl = url.replaceAll("'", "''");
            url = tempUrl;
            tempUrl = url.replace("\\", "\\\\");
            url = tempUrl;
        }
        return url;
    }

    public String sanitizeCookie(String cookieId) {
        if(cookieId != null) {
            String tempCookie = "";
            tempCookie = cookieId.replaceAll("'", "''");
            cookieId = tempCookie;
            tempCookie = cookieId.replace("\\", "\\\\");
            cookieId = tempCookie;
        }
        return cookieId;
    }

    public String sanitizeReferrer(String referrer) {
        if(referrer != null) {
            String tempReferrer = "";
            tempReferrer = referrer.replaceAll("'", "''");
            referrer = tempReferrer;
            tempReferrer = referrer.replace("\\", "\\\\");
            referrer = tempReferrer;
        }
        return referrer;
    }

    public String sanitizePostData(String postData) {
        if(postData != null) {
            String tempPostData = "";
            tempPostData = postData.replaceAll("'", "''");
            postData = tempPostData;
            tempPostData = postData.replace("\\", "\\\\");
            postData = tempPostData;
        }
        return postData;
    }

    /**
     * Function to create test cases when cookies are present
     * @param con
     */
    private void generateTestCaseCookie(Connection con) {
        String cookie = null;
        String ip = null;
        String method = null;
        String url = null;
        String postData = null;
        String date_string = null;
        String time_string = null;
        String postFile = null;
        String referrer = null;
        int unix_time = 0;
        int rownum = 0;
        int testCaseId;

        String tuple = null;

        Statement stmt = null;

        stmt = createMyStatement(con);

        ResultSet results = null;
        String queryText = null;

        /*
         * Query to get all the rows from log_data table.
         * First, select all rows where cookie is not null.
         * All the columns are self explanatory. Attribute unix_time is derived from date_string and time_string
         */
        //Ignoring requests where cookie is NULL, these requests are handled later in this code
        //Usually the first time when a user access the website, cookie is null.
        //Todo: Add code that takes care of applications which do not use cookies
        queryText = "SELECT " +
                    "rownum , " +
                    "extract (epoch FROM to_timestamp(date_string||' '||time_string,'yyyy-mm-dd hh24:mi:ss'))::integer unix_time, " +
                    "date_string, "+
                    "time_string, "+
                    "method , " +
                    "ip , " +
                    "cookie , " +
                    "url , "+
                    "postdata, "+
                    "referrer, "+
                    "postfile " +
                    "FROM log_data " +
                    "WHERE url not like '%ico%' and url not like '%gif%' AND url not like '%jpg%' "+
                    "AND rownum > " + startRowNum +" "+
                    "AND cookie != ' (null) ' "+
                    "order by rownum;";
        /**
         * Execute the query. If there are any errors, log it to error.log file.
         */
        try {
            results = stmt.executeQuery(queryText);
        }
        catch (SQLException e) {
            logger.error("problem in executing the select statement");
            logger.error(e);
            rollbackFlag = true;
            return;
        }

        if (results != null) {
            try {
                while(results.next()) {
                    //For each row, fetch all the values from result set.
                    rownum 		= results.getInt("rownum");
                    unix_time 	= results.getInt("unix_time");
                    cookie 		= results.getString("cookie");
                    ip              = results.getString("ip");
                    url 		= results.getString("url");
                    postData 	= results.getString("postdata");
                    method 		= results.getString("method");
                    date_string = results.getString("date_string");
                    time_string = results.getString("time_string");
                    postFile 	= results.getString("postfile");
                    referrer    = results.getString("referrer");

                    //Case 1: When cookie is present
                    if(!cookie.contains("null")) {
                        Statement stmt1 = null;
                        stmt1 = createMyStatement(con);

                        ResultSet r1 = null;
                        //Retrieve the last row from test_suite table where cookie and ip is same as current row's.

                        queryText = "SELECT row_id,unix_time, test_id from "+
                                    "(	SELECT row_id, "+
                                    "test_id, "+
                                    "extract (epoch from to_timestamp(date_string||' '||time_string,'yyyy-mm-dd hh24:mi:ss'))::integer unix_time, "+
                                    "RANK() OVER (order by row_id desc) as pos "+
                                    "FROM test_suite "+
                                    "WHERE (cookie = '" + cookie + "') "+
                                    "AND ip = '"+ip+"' "+
                                    "AND row_id > "+ startRowNum +
                                    ") as foo "+
                                    "WHERE pos = 1;";
                        r1 = stmt1.executeQuery(queryText);

                        if(r1 != null) {
                            boolean flag = true;
                            flag = r1.next();

                            if (flag == false) {
                                //there are no rows, and create a new test case
                                //	start of new test case
                                testCaseId = getSequenceNo(con);
                                url = sanitizeUrl(url);
                                cookie = sanitizeCookie(cookie);
                                referrer = sanitizeReferrer(referrer);
                                postData = sanitizePostData(postData);
                                tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                                insertToTest_Suite(tuple, con);
                            }
                            else {
                                // this part is to check if timestamp is greater than 45 min or less
                                // if less than 45 minutes then it belongs to same test case
                                // else new test case is to be created
                                if(unix_time - r1.getInt("unix_time")  <= 2700) {
                                    //this row belongs to the same test case
                                    //get the existing test case id and create a test case
                                    testCaseId = r1.getInt("test_id");
                                    url = sanitizeUrl(url);
                                    cookie = sanitizeCookie(cookie);
                                    referrer = sanitizeReferrer(referrer);
                                    postData = sanitizePostData(postData);
                                    tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                                    insertToTest_Suite(tuple, con);
                                }
                                else {
                                    //New test case needs to be created
                                    testCaseId = getSequenceNo(con);
                                    url = sanitizeUrl(url);
                                    cookie = sanitizeCookie(cookie);
                                    referrer = sanitizeReferrer(referrer);
                                    postData = sanitizePostData(postData);
                                    tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                                    insertToTest_Suite(tuple, con);
                                }
                            }
                        }
                        r1.close();
                    }
                }   //end of main while loop
            }
            catch (SQLException e) {
                logger.error("problem in main while loop");
                logger.error(e);
                rollbackFlag = true;
                return;
            }
        }   //end of main outer if

        try {
            results.close();
            logger.debug("I am closing results");
        }
        catch (SQLException e) {
            logger.error("problem in closing resultsSet results");
            logger.error(e);
            rollbackFlag = true;
            return;
        }

        // part to handle requests whose cookie is NULL (i.e., usually, the first request in a user's session)

        Statement stmt1 = null;

        stmt1 = createMyStatement(con);
        //selecting all such requests whose cookie is NULL from the log_data table
        ResultSet rs2 = null;
        String query = null;
        @SuppressWarnings("unused")
        int cnt = 0;
        query = "SELECT " +
                "rownum , " +
                "extract (epoch FROM to_timestamp(date_string||' '||time_string,'yyyy-mm-dd hh24:mi:ss'))::integer unix_time, " +
                "date_string, "+
                "time_string, "+
                "method , " +
                "ip , " +
                "cookie , " +
                "url , "+
                "postdata, "+
                "postfile " +
                "FROM log_data " +
                "WHERE url not like '%ico%' AND url not like '%gif%' AND url not like '%jpg%' " +
                "AND rownum > " + startRowNum +" "+
                "AND cookie = ' (null) ' "+
                "ORDER BY rownum;";

        try {
            rs2 = stmt1.executeQuery(query);
        }
        catch (SQLException e) {
            logger.error("problem in executing the select statement");
            logger.error(e);
            rollbackFlag = true;
            return;
        }

        if (rs2 != null) {
            try {
                while(rs2.next()) {
                    rownum 		= rs2.getInt("rownum");
                    unix_time 	= rs2.getInt("unix_time");
                    cookie 		= rs2.getString("cookie");
                    ip 			= rs2.getString("ip");
                    url 		= rs2.getString("url");
                    postData 	= rs2.getString("postdata");
                    method 		= rs2.getString("method");
                    date_string = rs2.getString("date_string");
                    time_string = rs2.getString("time_string");
                    postFile 	= rs2.getString("postfile");
                    //String referrer =  rs2.getString("referrer");

                    Statement stmt3 = null;
                    stmt3 = createMyStatement(con);
                    ResultSet rs3 = null;
                    String qry = null;

                    // select rows from test_suite table ordered by timestamp and then rownumber. ensures first request of test case is retrieved.
                    //and check if current row is within 10 seconds of row returend by query

                    qry =   "SELECT * FROM (" +
                            "SELECT " +
                            "extract (epoch FROM to_timestamp(date_string||' '||time_string,'yyyy-mm-dd hh24:mi:ss'))::integer - " + unix_time +" unix_time , "+
                            "* "+
                            "FROM test_suite "+
                            "WHERE ip = '"+ip+ "' " +
                            "AND row_id > " + startRowNum +" "+
                            "ORDER BY unix_time, row_id) as foo "+
                            "WHERE unix_time <= 2700 "+
                            "AND unix_time >= 0 "+
                            "LIMIT 1;";

                    rs3 = stmt3.executeQuery(qry);

                    if(rs3 != null) {
                        boolean flag = true;
                        flag = rs3.next();
                        //If a request does not come within a 45 minute interval from the first request of any other test case, then this request
                        //belongs to a test case by itself.
                        if (flag == false) {
                            // This is the case where a request was made to first page and there are no further
                            //requests. For such cases, new test cases are to be created and to be
                            //inserted at the end of the test_suite table. Note that these test cases won't be
                            //in the order in which they appear in the log file, but will be at the end of the test suite.

                            testCaseId = getSequenceNo(con);
                            url = sanitizeUrl(url);
                            cookie = sanitizeCookie(cookie);
                            referrer = sanitizeReferrer(referrer);
                            postData = sanitizePostData(postData);
                            tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                            insertToTest_Suite(tuple, con);
                        }
                        else { //a matching test case has been found for the URL without the cookie and we assign this URL to the selected test case.
                            testCaseId = rs3.getInt("test_id");
                            url = sanitizeUrl(url);
                            cookie = sanitizeCookie(cookie);
                            referrer = sanitizeReferrer(referrer);
                            postData = sanitizePostData(postData);
                            tuple = testCaseId +","+ rownum + ",'"+time_string+ "','" + date_string+ "','" + ip+ "','" + method+ "','" + url+ "','" + cookie+ "','" + postData+ "','" + postFile +"'";
                            insertToTest_Suite(tuple, con);
                        }
                    }
                }  //end of while loop
            }
            catch (SQLException e) {
                logger.error("problem for handling rows with null cookies");
                logger.error(e);
                rollbackFlag = true;
                return;
            }
        } 		//end of if(rs2 != null) loop
    }    // end of function generateTestCaseCookie()

    /**
     * Helper function to createStatement
     * @param con The connection to database
     * @return the statement to the database
     */

    Statement createMyStatement(Connection con) {
        Statement myStmt = null;
        try {
            myStmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
        return myStmt;
    }

    /**
     * Helper method that inserts rows into test_suite table
     * @param tuple string that represents the row data
     * @param con connection to database
     */

    void insertToTest_Suite(String tuple, Connection con) {
        Statement stmt = null;
        stmt = createMyStatement(con);
        try {
            stmt.executeUpdate("INSERT INTO test_suite VALUES (" + tuple + ");");
        }
        catch (SQLException e) {
            rollbackFlag = true;
            logger.error("Error while inserting into table test_suite");
            logger.error(e);
        }
    }       //end of function insertRow

    /**
     * Helper method that retrieves current sequence number of the test_suite table
     * @param con connection to database
     * @return sequence number
     */

    int getSequenceNo(Connection con) {
        int serialNum = 0;
        Statement st = null;
        st = createMyStatement(con);

        // get the postgresql serial field value with this query
        String query = "SELECT nextval('test_id_seq')";
        ResultSet rs = null;
        try {
            rs = st.executeQuery(query);
        }
        catch (SQLException e) {
            logger.error("Error in getting next value for Sequence.");
            logger.error(e);
        }
        try {
            if ( rs.next() ) {
                serialNum = rs.getInt(1);
            }
        }
        catch (SQLException e) {
            logger.error(e);
        }
        return serialNum;
    }       // end of function getSequenceNo()
}  //end of main class
