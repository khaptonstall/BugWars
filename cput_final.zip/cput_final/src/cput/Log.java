/**
 * Class: Log
 * Version      : 1.0
 * Developed By : Jain Sachinkumar
 * Date         : 02-22-2010
 * Functions:This class basically reads the log file and inserts into log_data table. 
 * 			 This class implements basic methods necessary to connect to database,  existence of database, creation of database, tables, sequence, etc
 * 			 This class implements methods the check validity of log format.  
 */

package cput;

/**
*
* @author Sachinkumar Jain
*/


import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;


@SuppressWarnings("unused")
public class Log {
    /*
     * Variable declarations
     * @param defaultDatabase The default database required to connect to database
     * @param dbHost Name of the database server.
     * @param lineCount, errCount: counter to keep track of number of lines process and number of lines with error.
     *
     */
	
    //Also to modify to give hostname and portno values when called in a constructor

    Logger logger = Logger.getLogger(Log.class);


    String defaultDatabase = "postgres";
    String dbHost; // = "localhost";
    String portNumber; // = "5432";

    String date = null;
    String time;
    String host = null;
    String method = null;
    String url = null;
    String cookieId = null;
    String referrer;
    String postData;
    int lineCount = 0;
    int errLineCount = 0;

    boolean rollbackFlag = false;
    ErrorMessage errMsg = new ErrorMessage();
	
    //empty constructor
    /**
     * empty constructor
     */
    Log() {

    }
    /**
     * constructor with database hostname and port number
     * @param hostName
     * @param portNumber
     */
    Log(String hostName, int portNumber) {
        this.dbHost = hostName;
        this.portNumber = Integer.toString(portNumber);
    }
    /**
     * constructor with logger
     * @param logger
     * @param hostName
     * @param portNumber
     */
    Log(Logger logger, String hostName, int portNumber) {
        this.logger = logger;
        this.dbHost = hostName;
        this.portNumber = Integer.toString(portNumber);
    }
    /**
     * Description      : Set connection to database.
     * Function			: setConnection
     * @param db		: Name of the database to connect.
     * @param userName	: Database Username.
     * @param password	: Database Password
     * @return			: Returns the connection to database.
     */

    Connection setConnection(String db, String userName, String password) {
        Connection con = null;
        try {
            Class.forName("org.postgresql.Driver");
        }
        catch (ClassNotFoundException cnfe) {
            logger.error("Couldn't find the driver!");
            logger.error("Let's print a stack trace, and exit.");
            logger.error(cnfe);
            System.exit(1);
        }
		  
        logger.debug("\nRegistered the driver ok, so let's make a connection.");
        try {
            String url = "jdbc:postgresql://"+dbHost+ ":" +portNumber+"/"+db;
            con = DriverManager.getConnection(url, userName, password);
            logger.debug("The parameters to the connection are : Host: "+dbHost+"Database Name "+ db +".");
        }
        catch (SQLException se) {
            logger.error("Couldn't connect: print out a stack trace and exit.");
            logger.error(se);
        }
        return con;
    }   //End of function setConnection()
	
    /**
     * Processing of the log file.
     * Sample lines from the log file are:
     * <p>
     * GET with no cookie and no data:
     * <p>
     * [Thu Feb 25 11:35:43 2010] ]# 130.85.90.88 ]# GET ]# /SchoolMate/Main.php]# (null) ]# http://130.85.90.88/SchoolMate/Main.php
     * <p>
     * GET with cookie and no data:
     * <p>
     * [Thu Feb 25 11:35:44 2010] ]# 130.85.90.88 ]# GET ]# /SchoolMate/Main.php]# PHPSESSID=cb3a2e873e76fdc43e9bf4c5c38a3f15 ]# (null)
     * <p>
     * GET with data and cookie:
     * <p>
     * [Thu Feb 25 11:35:43 2010] ]# 130.85.90.88 ]# GET ]# /SchoolMate/Main.php?hl=en&source=hp&q=get+url+sample ]# PHPSESSID=cb3a2e873e76fdc43e9bf4c5c38a3f15 ]# http://130.85.90.88/SchoolMate/Main.php
     * <p>
     * POST in single line:
     * <p>
     * [Thu Feb 25 11:36:02 2010] ]# 130.85.90.88 ]# POST ]# /SchoolMate/index.php ]# PHPSESSID=cb3a2e873e76fdc43e9bf4c5c38a3f15 ]#http://130.85.90.88/SchoolMate/index.php ]#PostData:username=test&password=test&page=0&login=1
     * <p>
     * POST in multiple lines:
     * <p>
     * [Thu Feb 25 11:36:02 2010] ]# 130.85.90.88 ]# POST ]#/SchoolMate/index.php ]# PHPSESSID=cb3a2e873e76fdc43e9bf4c5c38a3f15 ]#http://130.85.90.88/SchoolMate/index.php ]# PostData:username=test
     * <p>
     * ]# PostData:&password=test&page=0&login=1
     *<p>
     *
     * @param inputFile Web Log file name to be processed.
     * @param con The connection to the database.
     */
	
    @SuppressWarnings("deprecation")
    //@SuppressWarnings("deprecation")
    //ToDo: Add above an example of POST with filename once filename logging is implemented
	
    void processLog(FileInputStream inputFile, Connection con) {
        DataInputStream currentStream = new DataInputStream(new BufferedInputStream(inputFile));
        DataInputStream nextStream = new DataInputStream(new BufferedInputStream(inputFile));

        String currentLine, nextLine;
        ErrorMessage em = new ErrorMessage();

        //all rows are initially going to be stored in a temporary table
        //the temp table is created to allow for rollback after 10 or multiple of 10 errors in inserting into database
        createTempTable(con);

        try {
            while((currentLine = currentStream.readLine()) != null) {
                String trunCurrentLine = currentLine.replaceAll("[^\\p{ASCII}]", "");
                currentLine = trunCurrentLine;
                String []logFileLineArray1 = new String[10192];
                logFileLineArray1 = currentLine.split("]#");
				
                // This is for any request will have atleast 3 data separators(See log format above.)
                if(logFileLineArray1.length > 3) {
                    String timeStamp = logFileLineArray1[0].replace("[", "").replace("]", "");
                    String []dateTime = new String[48];
                    dateTime = timeStamp.split(" ");
                    date = 		dateTime[1] + " " + dateTime[2] + " " + dateTime[4];
                    time = 		dateTime[3] ;
                    host = 		logFileLineArray1[1];
                    method = 	logFileLineArray1[2];
                    url = 		logFileLineArray1[3];
                    cookieId = 	logFileLineArray1[4];
                    referrer = 	logFileLineArray1[5];

                    //Check here if url is a request for a jpg, gif, ico, png bmp, etc and ignore them
                    if(url.contains(".jpg")||url.contains(".gif")||url.contains(".bmp")||
                    		url.contains(".ico")||url.contains(".png")||url.contains(".jpeg")
                    		||url.contains(".js")||url.contains(".css")) {
                            //Do nothing as we dont want to store any of url's which contains images etc. in the log_data table
                    }
                    // Request with POST data will have length greater than or equal to 6.
                    else {
                        if(logFileLineArray1.length <= 6 )
                            postData = null;
                        else
                            postData = logFileLineArray1[6];

                        if(currentStream.markSupported())
                            currentStream.mark(1000000);
                        nextStream = currentStream;

                        // These lines take care of POST data that goes into multiple lines.
                        // The multiple lines are processed and post data from all the lines is joined and stored in the postData instance variable

                        nextLine = nextStream.readLine();
                        if(nextLine != null){
                            String truncNextLine = nextLine.replaceAll("[^\\p{ASCII}]", "");
                            nextLine = truncNextLine;
                        }
                        while( nextLine != null &&nextLine.split("]#").length < 3) {  // when postData continues into multiple lines, such lines can have either 1 or 2 Delimiters
                            String []logFileLineArray2 = new String[10192];
                            logFileLineArray2 = nextLine.split("]#");
                            if(logFileLineArray2.length > 1)
                                postData = postData + logFileLineArray2[1].substring(10, logFileLineArray2[1].length());
                            nextLine = nextStream.readLine();
                            if(nextLine != null){
                                String truncNextLine = nextLine.replaceAll("[^\\p{ASCII}]", "");
                                nextLine = truncNextLine;
                            }
                        }
                        if(currentStream.markSupported())
                            currentStream.reset();

                        sanitizeDBValues();
                        String rowData = "'" + date + "','" + time + "','" + host + "','" + method + "','" + url + "','" + cookieId + "','" + referrer + "','" + postData + "'";
                        insertToTempTable(rowData, con); //insert row into database

                        //if more than 10 or multiples of 10 'insert' errors occur, the user is given the option to either continue or exit
                        if ((errLineCount+1)%9 == 0 ) {
                            String errMsg = "Total lines processed: "+lineCount+ ".\n Total lines in error: " +errLineCount +".\n Do you want to Continue?";
                            if(!em.displayMessageBox(errMsg, 2)) {
                                //rollback flag when set to true will make the program roll back ALL rows entered
                                //in current transaction
                                rollbackFlag = true;
                                logger.error("Unable to insert data into Log_data table.");
                                return;
                            }
                        }
                    }// end of else
                }
            }// End of while loop
            logger.debug("\nNo. of rows inserted in log_data table: " + lineCount);
            //copy rows from temp table to log_data table when all data in raw web log has been inserted into temp table successfully
            copyFromTemp(con);
        }
        catch (IOException e)  {
            logger.error("Error while reading file");
            logger.error(e);
            rollbackFlag = true;
        }
    }   //End of processLog() method

    public void sanitizeDBValues() {
        //Sanitize URL
        if(url != null) {
            String tempUrl = "";
            tempUrl = url.replaceAll("'", "''");
            url = tempUrl;
            tempUrl = url.replace("\\", "\\\\");
            url = tempUrl;
            tempUrl = url.replaceAll("[^\\p{ASCII}]", "");
            url = tempUrl;
        }
        //Sanitize cookie
        if(cookieId != null) {
            String tempCookie = "";
            tempCookie = cookieId.replaceAll("'", "''");
            cookieId = tempCookie;
            tempCookie = cookieId.replaceAll("[^\\p{ASCII}]", "");
            cookieId = tempCookie;
        }
        //Sanitize referrer
        if(referrer != null) {
            String tempReferrer = "";
            tempReferrer = referrer.replaceAll("'", "''");
            referrer = tempReferrer;
            tempReferrer = referrer.replaceAll("[^\\p{ASCII}]", "");
            referrer = tempReferrer;
        }
        //Sanitize postData
        if(postData != null) {
            String tempPostData = "";
            tempPostData = postData.replaceAll("'", "''");
            postData = tempPostData;
            tempPostData = postData.replaceAll("[^\\p{ASCII}]", "");
            postData = tempPostData;
        }
    }

    /**
     * creates a temporary table that stores all the rows that will eventually be entered into the log_data table
     * the temporary table is maintained so that rollback of data can take place, when 10 or multiples of 10 errors occur
     * @param con
     */
    private void createTempTable(Connection con) {
        Statement stmt = null;
        String queryText = null;
        stmt = createMyStatement(con);

        try {
            //Creating temp table
            queryText = "CREATE TEMP TABLE temp_log_data" +
                        "(" +
                        "rownum   		int not null default nextval('rownum_seq'),"+
                        "date_string 	date,"+
                        "time_string 	time without time zone,"+
                        "ip        		character varying(128),"+
                        "method    		character varying(32),"+
                        "url       		text,"+
                        "cookie    		character varying(2048),"+
                        "referrer  		character varying(2048),"+
                        "postdata  		character varying(8000),"+
                        "postfile  		character varying(2048)"+
                        ");";
            stmt.executeUpdate(queryText);
            logger.debug(queryText);
        }
        catch (SQLException e) {
            logger.error("Unable to create table");
            logger.error(e);
            rollbackFlag = true;
        }
    }

    /**
     * Called when all data from the raw web log could be successfully entered into the temp table
     * This function copies the data from the temp table into the log_data table
     * @param con
     */
    private void copyFromTemp(Connection con) {
        Statement st = null;
        st = createMyStatement(con);

        String query = "INSERT INTO log_data select * FROM temp_log_data;";
        st = createMyStatement(con);
        try {
            st.executeUpdate(query);
        }
        catch (SQLException e) {
            logger.error("Error truncating table temp_log_data");
            logger.error(e);
            rollbackFlag = true;
        }
    }

    /**
     * Function to insert raw web log data into temp table
     * @param tuple Row Data
     * @param con Connection to database
     */
    void insertToTempTable(String tuple, Connection con) {
        Statement stmt = null;
        stmt = createMyStatement(con);
        try {
            String colName = null;

            colName = "(date_string, time_string, ip, method, url, cookie, referrer, postdata)";

            stmt.executeUpdate("INSERT INTO temp_log_data "+ colName + " VALUES (" + tuple + ");");
            lineCount++;
        }
        catch (SQLException e) {
            logger.error("Error while inserting into table log_data. Row Value: " + tuple);
            errLineCount++; //if exception occurs during insert, the error count is incremented
            logger.error(e);
        }
    }

    /**
     * Function to get the log file name from directory path. This handles both windows and unix directory systems.
     * @param path The path where the file is stored
     * @return It returns the file name, without the extension.
     */
    String getFileName(String path) {
        String fileName = path;
        if(fileName.contains("\\"))
            fileName = path.split("\\\\")[path.split("\\\\").length-1].split("\\.")[0];
        else
            fileName = path.split("/")[path.split("/").length-1].split("\\.")[0];
        return fileName;
    }
	
    /**
     * Function to get the log file name from directory path. The file name is used to create an XML file with the same name that contains all the test cases.
     * This handles both Windows and Unix directory system.
     * @param path The path where the file is stored
     * @return It appends the targetSubDir and returns the file path.
     */
    //Example: path: C:\dir1\dir2\dir3\myApp.log ,and targetSubDir is testCases,
    //return value will be C:\dir1\dir2\dir3\testCases\
    String getFilePath(String path, String targetSubDir) {
        String filePath = path;
        int fileLength;
        if(filePath.contains("\\")) {
            fileLength = path.split("\\\\")[path.split("\\\\").length-1].length();
            filePath = path.substring(0,path.length() - fileLength ) + targetSubDir + "\\";
        }
        else {
            fileLength = path.split("/")[path.split("/").length-1].length();
            filePath =  path.substring(0,path.length()-fileLength ) + targetSubDir + "/";
        }
        return filePath;
    }
	
    //extension to existing createStatement. Helps create a database statement.
    private Statement createMyStatement(Connection con) {
        Statement myStmt = null;
        try {
            myStmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
        return myStmt;
    }
	
    /**
     * Function to drop database
     * @param databaseName The database which is to be dropped
     * @param userName Database username
     * @param password Database password
     */
    public boolean dropDatabase(String databaseName, String userName, String password) {
        //called by Project1.java
        Connection con = null;
        Statement stmt = null;
        boolean success = true;
        con = setConnection(defaultDatabase, userName, password);
        stmt = createMyStatement(con);
        String queryText = "Drop database IF EXISTS "+ databaseName;
        logger.info("Query to drop database: "+queryText);
        try {
            stmt.executeUpdate(queryText);
        }
        catch (SQLException e) {
            logger.debug("Unable to drop database. Stack trace is as follows: ", e);
            logger.debug("Exiting.....");
            //Display popup message so the user is aware of the problem, and don't exit program.
            String errorMessage = "Unable to drop database. Stack trace is as follows:\n"
                    + e;
            errMsg.displayMessageBox(errorMessage, 1); //Magic number being used to replicate value sent on failure inside createDatabase
            success = false;
        }
        finally {
            try {
                con.close();
            }
            catch (SQLException e) {
                logger.error("Unable to close connection.");
                logger.error(e); //e.printStackTrace();
                success = false;
            }
        }
        return success;
    }
	
    /**
     * Function to create required database
     * @return  1 if database and tables created successfully.
     *          -1 if unable to create tables.
     *          -2 if unable to create database.
     */
    public int createDatabase(String databaseName, String userName, String password) {
        //called by Project1.java
        Connection con = null;
        Statement stmt = null;

        con = setConnection(defaultDatabase,userName,password);
        stmt = createMyStatement(con);

        String queryText = null;

        logger.debug("Call function to create database" +databaseName);

        //create all the required database objects.

        queryText = "Create database "+ databaseName;
        logger.debug(queryText);

        try {
            stmt.executeUpdate(queryText);
        }
        catch (SQLException e) {
            logger.error("Unable to create database");
            logger.error(e);
            return -1;
        }

        Connection myCon = setConnection(databaseName, userName, password);

        if(createTables(databaseName, myCon)) {
            logger.debug("Database and table creation successfull.");
            return 1;
        }
        else {
            logger.error("unable to create tables in database "+ databaseName);
            return -2;
        }
    } //End of function createDatabase
	
    /**
     * Function to check if database exists or not.
     * @return  0 if database present
     *          1 if database not present
     *          -1 if some other error
     */
    public int checkDatabase(String databaseName, String userName, String password) {
        //called by Project1.java
        Connection con = null;
        Statement stmt = null;

        con = setConnection(defaultDatabase,userName,password);
        stmt = createMyStatement(con);
        ResultSet results = null;

        String queryText = null;
         //The query to get information from postgres metadata table and check if database exits or not.

        queryText = "SELECT datname dbname FROM pg_database WHERE lower(datname) = lower('"+databaseName+ "');";
        logger.debug(queryText);
        try {
            results = stmt.executeQuery(queryText);
        }
        catch (SQLException e) {
            logger.error("Cannot get the list of databases!!!!");
            logger.error(e);
        }

        // if query executed successfull
        if (results != null) {
            // If flag is true, this means that database is present and we do not need to create database
            // Else when flag is false, there is no database and we need to create database.

            boolean flag = true;
            try {
                flag = results.next();
                if(flag == false) {
                    logger.debug("Database not there");
                    return 1;
                }
                else {
                    logger.debug("Database already there");
                    return 0;
                }
            }
            catch (SQLException e) {
                logger.error("problem in while loop");
                logger.error(e);
            }
        }
        try {
            results.close();
        }
        catch (SQLException e) {
            logger.error(e);
        }
        return -1;
    } //End of function checkDatabase
	
    /**
     * Function to create both log_data table and test_suite table and the sequences, rownum_seq and test_id_seq
     * @param databaseName Database name in which table/sequence are to be created
     * @param con Database connection
     * @return True if all Table/Sequences were created successfully
     *          False when any error occurred.
     */
    private boolean createTables(String databaseName, Connection con) {
        //called in Log.java
        Statement stmt = null;
        String queryText = null;
        stmt = createMyStatement(con);

        try {
            //create all the required database objects.

            //rownum_seq is the primary key for table log_data.

            queryText = "Create sequence rownum_seq increment by 1 start with 1000000;";
            stmt.executeUpdate(queryText);
            logger.debug(queryText);
            //Creating log_data table.

            queryText = "CREATE TABLE log_data" +
                        "(" +
                        "rownum   		int not null,"+
                        "date_string 	date,"+
                        "time_string 	time without time zone,"+
                        "ip        		character varying(128),"+
                        "method    		character varying(32),"+
                        "url       		text,"+
                        "cookie    		character varying(2048),"+
                        "referrer  		character varying(2048),"+
                        "postdata  		character varying(8000),"+
                        "postfile  		character varying(2048)"+
                        ");";
            stmt.executeUpdate(queryText);
            logger.debug(queryText);


            queryText = "create sequence test_id_seq increment by 1 start with 1000000;";
            stmt.executeUpdate(queryText);
            logger.debug(queryText);

            //rownum from log_data table is same as row_id from test_suite table.
            //Creating test_suite table.

            queryText = "CREATE TABLE test_suite " +
                        "( "+
                        "test_id 		int not null, "+
                        "row_id			int, "+
                        "time_string 	time without time zone, "+
                        "date_string 	date, "+
                        "ip        		character varying(128), "+
                        "method    		character varying(32), "+
                        "url       		text, "+
                        "cookie    		character varying(2048), "+
                        "postdata  		character varying(8000), "+
                        "postfile  		character varying(2048) "+
                        ");";
            stmt.executeUpdate(queryText);
            logger.debug(queryText);

            return true;
        }
        catch (SQLException e) {
            logger.error("Unable to create table");
            logger.error(e);
            return false;
        }
    }   //End of function createDatabase
	
		
    // This function is not used, but may be used for future expansion. So it is not to be deleted.
    /**
     * This is to allow different log file formats. Right now, we use a pre-set format of date, ip address, etc.
     * In the future, this function can be used to allow different formats. The format itself would be specified in
     * a separate configuration file that will be read by Cput.
     */
    /*private void setValues(String line) {
        String []str1 = new String[10192];
        str1 = line.split("]#");
        String timeStamp = str1[0].replace("[", "").replace("]", "");
        date = timeStamp.split(" ")[1] + " " + timeStamp.split(" ")[2] + " " + timeStamp.split(" ")[4];
        time = timeStamp.split(" ")[3] ;
        host = str1[1];
        method = str1[2];
        url = str1[3];
        cookieId  = str1[4];
        referrer = str1[5];

        if(str1.length <= 6 )
            postData = "  ";
        else
            postData = str1[6];
    }
    */

    /**
     * Get the last row that is inserted. Called when the user selects the 'append' database option.
     * @param con
     * @param seqName a sequence to keep track of current row number
     * @return
     */
    public int getSeqLastVal(Connection con, String seqName) {
        //used in Project1.java
        Statement st = null;
        st = createMyStatement(con);

        // get the postgresql serial field value with this query
        int lastSeqVal = 0;
        String query = "SELECT last_value FROM "+ seqName +";";
        ResultSet rs = null;
        try {
            rs = st.executeQuery(query);
        }
        catch (SQLException e) {
            logger.error("Error in getting next value for Sequence.");
            logger.error(e);
        }
        try {
            while(rs.next())
                lastSeqVal = rs.getInt("last_value");
        }
        catch (SQLException e1) {
            logger.error("Error in getting next value for Sequence.");
            logger.error(e1);
        }
        try {
            rs.close();
        }
        catch (SQLException e) {
            logger.error("Error in getting next value for Sequence.");
            logger.error(e);
        }
        return lastSeqVal;
    }
	
    public int deleteDataFromLogData(Connection con, int startRowNum) {
        int numRows = 0;
        Statement stmt = null;

        try {
            con.setAutoCommit(true);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            stmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
        String queryText = "DELETE FROM log_data WHERE rownum > "+startRowNum;
        try {
            numRows = stmt.executeUpdate(queryText);
        }
        catch (SQLException e) {
            logger.error("Error in deleteing data from log_data table. Please execute following query inorder to make log_data table consistent\n");
            logger.error("DELETE FROM log_data WHERE rownum >" + startRowNum);
            logger.error(e);
        }
        return numRows;
    }
};