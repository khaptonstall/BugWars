/**
* Version      : 1.0
* Developed By : Jain Sachinkumar
* Date         : 02-22-2010 
* Description  : => This is the JAVA code for reading the log file in the format below and to
*                   generate the test cases
*                => It uses postgres SQL database to store log file data and the test cases into the database.
*                
* Log Format:
* 
* Sample Log Entries:
* 
* [Fri Jan 08 13:33:01 2010] ]# 127.0.0.1 ]# POST ]# /schoolMateApplication/index.php ]# PHPSESSID=a9099cd16db2e4134200cd69f6dc87cf ]# http://localhost:8000/schoolMateApplication/index.php ]# PostDataa:page2=5&logout=1&page=1
* [Fri Jan 08 13:33:01 2010] ]# 127.0.0.1 ]# GET ]# /favicon.ico ]# PHPSESSID=a9099cd16db2e4134200cd69f6dc87cf ]# (null)
* 
*/
 /* 
 * Todo 
 * need to add a debug flag, which if true, would write the informational messages into debug.log.
 * Later we can take/initialize this variable from configuration file.
 * Implementing with Log4j
 * 
 */
package cput;

/**
*
* @author Sachinkumar Jain
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.*;

import javax.swing.JOptionPane;

import cput.DatabaseInfo.dbWriteMethod;
import org.apache.log4j.Logger;

//@SuppressWarnings("unused")
@SuppressWarnings("unused")
public class Project1 
{
    private RawWebLogProgressScreen rawProgScreen;
    private String path;
    private DatabaseInfo dbInfo;
    private String XMLFilePath;
    String defaultDatabase = "postgres";
    Logger logger = Logger.getLogger(Project1.class);

    /**
     * 
     * @param dbInfo
     * @param filepath
     * @param logger
     */
    //Constructor uses dbInfo to get all the database credentials and DB name
    //Also in the constructor, the run method is called, which essentially parses the log
    //file and generates the test cases. The run method (as seen later) returns the path
    //to the XML file that contains all the test cases.
    public Project1(DatabaseInfo dbInfo, String filepath, Logger logger){
        this.path = filepath;
        this.dbInfo = dbInfo;
        this.logger = logger;
        XMLFilePath = run();
    }

    protected String getXMLFilePath(){
        return this.XMLFilePath;
    }
/**
 * 
 * @return a string that is the path to the XML file name that contains all the test cases.
 */
    public String run()
    {
        /**
         * The declaration of variables start here.
         * There are few inputs that are to be taken from the user, which will be coming from GUI interface.
         * Below parameters should be initialized with the methods which will be get values from the user.
         * @param path: the source for the log file
         * @param targetDir The source of directory where user specifies the location where un-ordered test cases reside.
         * @param userName Database username.
         * @param password Database password.
         * @param hostName database host name.
         * @param portNumber database port number.
         * @param dropDbFlag A parameter which asks user if he wants to replace existing database or append existing database. Default value is false
         */
    		 
        int startRowNum = 0;

        String targetSubDir = "TestCases";
        String completeFileName = null;
    		
        String userName = dbInfo.getUsername();
        String password = dbInfo.getPword();
        String hostName = dbInfo.getHostname();
        int portNumber  = dbInfo.getPort();

        Connection con = null;
        Connection defaultDbCon = null;
            
        ErrorMessage errMsg = new ErrorMessage();

        /*
         * Check if the Log file exists or not. If not here we need to ask user to re-enter the valid file.
         *
         */

        Validate validate = new Validate(logger);

/*           
            rawProgScreen = new RawWebLogProgressScreen(null, true);           
        	Thread progThread = new Thread() {
                @Override
                public void run() {
                    rawProgScreen.setVisible(true);
                }
            };
            
            progThread.start();
*/      
            
        try {
        /*
             * Class Log is a class which basically takes log file as input and will insert rows in log_data table.
             */
        Log log = new Log(logger, hostName, portNumber);
	            
        defaultDbCon = log.setConnection(defaultDatabase, userName, password);
	            
        //creating the sub-directory TestCases that will eventually contain the individual XML test cases and overall XML test suite
        //XML file that contains entire test suite has the same name as web log file with the extnesion .XML. Creating this filename
        //in the following code.
        String fileName = log.getFileName(path);
        String XMLFileName = fileName + ".XML";

        String targetDir = log.getFilePath(path, targetSubDir);

        File testCasesDir = new File(targetDir);
        //checking permissions to create the TestCases directory
        if(testCasesDir.exists()) {
            //check if you have permissions to write

            if(!testCasesDir.canWrite()) {
                errMsg.displayMessageBox("Unable to write to directory "+ targetDir +". \n Please make sure directory with log-file is writeable.", 1);
                logger.error("Directory "+ targetDir +" is write protected");
                return null;
            }
            //if the directory exists then check for file deletion, else create the target directory
            //call function to delete files
            boolean deleteFilesFlag = validate.deleteFilesFromDir(targetDir);
            if(!deleteFilesFlag) {
                errMsg.displayMessageBox("Cannot delete files from directory: "+targetDir +"\nPlease check persmissions and try again.", 1);
                logger.error("Cannot delete files from directory: "+targetDir);
                return null;
            }
        }
        else {
            boolean flag = (new File(targetDir)).mkdir(); //if TestCases directory successfully created, flag is true
            logger.debug("Target directory created"+ targetDir);
            if(!flag) {
                errMsg.displayMessageBox("Unable to create target directory "+ targetDir +"Please check permissions and try again.", 1);
                logger.error("Unable to create target directory "+ targetDir);
                this.XMLFilePath = "";
                return null;
            }
        }
           
        dbWriteMethod writeMethod = dbInfo.getWriteMethod(); // writeMethod will be either new/append/replace depending on what user selects
        String databaseName = dbInfo.getDatabase(); //if new/append/replace, the user selects a database name on the screen. this variable reads the database name user specifies
	               
        logger.debug("Operation set to "+writeMethod+" database");
            
        /*
         * Now that we have the database name, and log file is present, we need to decide whether to replace existing database, or append the existing
         * database, or create new database if does not exists.
         *
         */
   
            
        DBTableInfo dbt = new DBTableInfo(defaultDbCon, logger);
        //Variables used in switch statement
        int dbExists, success;
        boolean dbDrop;
        String tuple;
        //writeMethos will correspond to createNew, append, overwrite that user selects
        switch (writeMethod) {
            case createNew:                //createNew database option
                //If new database option is given, we need to check if it exists or not.
                //If it exists, we need to throw error.
                dbExists = log.checkDatabase(databaseName, userName, password);
                if(dbExists == 1) {  //Everything is OK
                    success = log.createDatabase(databaseName, userName, password);

                    if(success == 1) {
                        logger.debug("Database "+ databaseName + " created");
                    }
                    else {
                        errMsg.displayMessageBox("Unable to create database and/or tables", 1);
                        logger.error("Unable to create database and/or tables");
                        return null;
                    }

                }
                if(dbExists == 0){    //database already present
                    logger.error("Database "+databaseName+" already present, Please give another database name.");
                    errMsg.displayMessageBox("Database "+databaseName+" already present, Please give another database name", 1);
                    return null;
                }
                if(dbExists == -1){    //Some other error
                    logger.error("Something wrong happened.");
                    errMsg.displayMessageBox("Something wrong happened. Please check CPUT_Error log file for further details.", 1);
                    return null;
                }
                // Insert row with current database name into CPUT_database_info table.
                //(dbName, dropDbFlag, userCreated, dateCreated, userModified, dateModified)";

                tuple = "'"+databaseName+"', 'N', " + "'" + userName + "', now(), " + "'"+ userName +"', now()";

                dbt.insertRow(tuple);

                //and establish connection to the specified db
                con = log.setConnection(databaseName, userName, password);
                break; //End of createNew case
            case append:    //append database option
                dbExists = log.checkDatabase(databaseName, userName, password);
                if(dbExists == 0) {  //Everything is OK
                    logger.debug("Appending to database "+databaseName);
                    //Update CPUT_database_info table with info on user who modified the table.
                    dbt.updateRow(databaseName, userName, "N");
                    //and establish connection to the specified db
                    con = log.setConnection(databaseName, userName, password);
                    //when append db option is selected, we need to process only from last row inserted in DB
                    //in the following statement, we get the row number of the last row processed in the DB and use it
                    startRowNum = log.getSeqLastVal(con, "rownum_seq");
                }
                else {  //Create New DB instead of appending
                    System.out.println("Database '" + databaseName + "' doesn't exist, creating new DB.");
                    success = log.createDatabase(databaseName, userName, password);

                    if(success == 1) {
                        logger.debug("Database "+ databaseName + " created");
                    }
                    else {
                        errMsg.displayMessageBox("Unable to create database and/or tables", 1);
                        logger.error("Unable to create database and/or tables");
                        return null;
                    }
                    // Insert row with current database name into CPUT_database_info table.
                    //(dbName, dropDbFlag, userCreated, dateCreated, userModified, dateModified)";
                    tuple = "'"+databaseName+"', 'N', " + "'" + userName + "', now(), " + "'"+ userName +"', now()";

                    dbt.insertRow(tuple);

                    //and establish connection to the specified db
                    con = log.setConnection(databaseName, userName, password);
                }
                break;  //End of append case
            case overwrite:     //overwrite database option
                dbExists = log.checkDatabase(databaseName, userName, password);
                if(dbExists == 0) {  //Everything is OK
                    dbDrop = log.dropDatabase(databaseName, userName, password);
                    if(dbDrop)
                        logger.debug("Database " + databaseName + " dropped successfully.");
                    else {
                        return null;
                    }
                    success = log.createDatabase(databaseName, userName, password);
                    if(success == 1)
                        logger.debug("Database "+ databaseName + " created successfully.");
                    else {
                        errMsg.displayMessageBox("Unable to re-create database and/or tables. Please check CPUT_Error log file for further details.", 1);
                        logger.error("Unable to re-create database and/or tables");
                        return null;
                    }
                    // First update CPUT_database_info table that the database is being dropped
                    // Then add a row with user created and other details
                    dbt.updateRow(databaseName, userName, "Y");
                    String tuple1 = "'"+databaseName+"', 'N', " + "'" + userName + "', now(), " + "'"+ userName +"', now()";

                    dbt.insertRow(tuple1);
                    //and establish connection to the specified db
                    con = log.setConnection(databaseName, userName, password);
                }
                else {  //Create New DB instead of overwriting
                    System.out.println("Database '" + databaseName + "' doesn't exist, creating new DB.");
                    success = log.createDatabase(databaseName, userName, password);

                    if(success == 1) {
                        logger.debug("Database "+ databaseName + " created");
                    }
                    else {
                        errMsg.displayMessageBox("Unable to create database and/or tables", 1);
                        logger.error("Unable to create database and/or tables");
                        return null;
                    }
                    // Insert row with current database name into CPUT_database_info table.
                    //(dbName, dropDbFlag, userCreated, dateCreated, userModified, dateModified)";
                    tuple = "'"+databaseName+"', 'N', " + "'" + userName + "', now(), " + "'"+ userName +"', now()";

                    dbt.insertRow(tuple);

                    //and establish connection to the specified db
                    con = log.setConnection(databaseName, userName, password);
                }
                break; // End of overwrite case
            }
            /*
             * Finally once we have setup the database successfully, we are now ok to start reading the log file and inserting log data into
             * log_data table.
             * @param myLogFile: the log file which is to be processed
             * @param con: database connection
             */
            try {
                log.processLog(new FileInputStream(path), con);
            }
            catch (FileNotFoundException e) {
                logger.error("Unable to process log file.");
                logger.error(e);
                return null;
            }

            //if more than 10 or multiples of 10 errors occur, and the user wishes to cancel, the rollback flag is set to true.
            //when the rollback flag is set to true, Log.java returns, and data that was being stored in the temp table is NOT copied into the log_data table
            //when the flag is set to true, we return from here in Project1 and execute the finally block where database connections are closed.
            if(log.rollbackFlag == true) {
            	errMsg.displayMessageBox("Coundn't load data into log_data table. Please look in CPUT_error log file for more details.", 1);
                return null;
            }
			/*
             * Class CreateTestCases: this is the class which implements all the required methods which reads log_data table 
             * and break them into test cases
             */

            //Now start generating test cases
            try {
                //because even if one test case fails, the entire data that was going to be
                //entered into the test_suite table should be rolled back. so we don't allow auto commits. instead when all
                //rows are entered successfully, we then explicity commit.
                con.setAutoCommit(false);
            }
            catch (SQLException e1) {
                logger.error("Unable to set Auto-Commit to False.");
                logger.error(e1);
                return null;
            }
            CreateTestCases ts = new CreateTestCases(con, logger, startRowNum);
            ts.generateTestCase();
            
            //if rollback is set to true, we do not return anything into the test_suite table
            //we return null from here
            if(ts.rollbackFlag == true) {
            	//rollback the test_suite table data
            	try {
                    errMsg.displayMessageBox("Couldn't create test cases. Please look in CPUT_error log file for more details.\n " +
                                                "Note that all data entered into the log_data table in this session will also be deleted because of this failure.", 1);
                    con.rollback();

                    //Once we have determined that the testcase generation process is unsuccessful
                    //we will delete all the rows from log_data table
                    //so for this first we set con's auto commit to true
                    //and then delete all the rows where rownum > startrownum
					
                    try {
                        con.setAutoCommit(true);
                    }
                    catch (SQLException e) {
                        logger.error("Unable to set Auto-Commit to True.");
                        logger.error(e);
                    }
					
                    int deleteRowCount = log.deleteDataFromLogData(con,startRowNum);
                    logger.error(deleteRowCount+" number of rows deleted from log_data table.\n");
                    return null;
                }
                catch (SQLException e) {
                    logger.error("Unable to Rollback data from test_suite table");
                    logger.error(e);
                }
                return null;
            }
			
            //Once loading raw log data into log_data table is completed and the test cases are successfully loaded into the test_suite table, 
            //commit the test cases into the test_suite table
            try {
                con.commit();
            }
            catch (SQLException e) {
                logger.error("Unable to Commit database. Please check CPUT_Error log file for further details.");
                logger.error(e);
                return null;
            }
			/*
             * Class WritetoXML: This is the class which implements all the required methods for reading 
             * the test_suite table and converting them
             * into XML format.
             * @param con: The connection to the database.
             * @param targetDir: the location where testCases are to be created.
             */
            
            try {
                con.setAutoCommit(true);
            }
            catch (SQLException e) {
                logger.error("Unable to set Auto-Commit to True.");
                logger.error(e);
            }

            WritetoXML cts = new WritetoXML(con, logger);
            cts.parseTable(targetDir, XMLFileName, dbInfo);
            completeFileName = targetDir + XMLFileName;
            //    rawProgScreen.dispose();
            
            return completeFileName; //path + filename to XML file that contains all the test cases
        }
        catch (IllegalArgumentException e) {
            e.printStackTrace();
            logger.error(e);
            errMsg.displayMessageBox("Error occured. Look error log file for details.", 1);
            return null;
        }
        finally {
            try {
                if(defaultDbCon!= null)
                    defaultDbCon.close();
                if(con != null)
                    con.close();
            }
            catch (SQLException e) {
                logger.error("Unable to close connection.");
                logger.error(e); //e.printStackTrace();
            }
        }
        //return completeFileName;
    }   //End of run()
};  //End of class Project