/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cput;

/**
 *
 * @author Schuyler
 */
public class ThreeWayPair {
    private InputParameter first;
    private InputParameter second;
    private InputParameter third;

    /**
     *
     * @param first
     * @param second
     */
    public ThreeWayPair(InputParameter first, InputParameter second, InputParameter third){
        this.first = first;
        this.second = second;
        this.third = third;
    }

    /**
     * Creates a hash value of both parameters name and values.  It checks to see
     * which tuple has a lower value and ensures it be placed first.  This will make
     * sure that a pair A-B can't be counted as B-A a second time.
     * @return String key
     */
    public String createHashKey(){
        String key;
        if(first.createHash().compareTo(second.createHash()) <= 0 && first.createHash().compareTo(third.createHash()) <= 0) { //first must be lowest val
            if(second.createHash().compareTo(third.createHash()) <= 0) //1:2:3
                key = first.createHash() + ":" + second.createHash() + ":" + third.createHash();
            else                                                       //1:3:2
                key = first.createHash() + ":" + third.createHash() + ":" + second.createHash();
        }
        else if (second.createHash().compareTo(first.createHash()) <= 0 && second.createHash().compareTo(third.createHash()) <= 0) { //second must be lowest val
            if(first.createHash().compareTo(third.createHash()) <= 0) //2:1:3
                key = second.createHash() + ":" + first.createHash() + ":" + third.createHash();
            else                                                      //2:3:1
                key = second.createHash() + ":" + third.createHash() + ":" + first.createHash();
        }
        else {                                                                                                                      //third must be lowest val
            if(first.createHash().compareTo(second.createHash()) <= 0) //3:1:2
                key = third.createHash() + ":" + first.createHash() + ":" + second.createHash();
            else                                                       //3:2:1
                key = third.createHash() + ":" + second.createHash() + ":" + first.createHash();
        }
        return key;
    }
    
    /**
     * Creates a hash value of both parameters name and values.  It checks to see
     * which tuple has a lower value and ensures it be placed first.  This will make
     * sure that a pair A-B can't be counted as B-A a second time.
     * @return String key
     */
    public String createHashKeySeq(){
        String key = first.createHash() + ":" + second.createHash() + ":" + third.createHash();
        return key;
    }
    
    public String tostring(){
        return this.first+" "+this.second+" "+this.third;
    }
}
