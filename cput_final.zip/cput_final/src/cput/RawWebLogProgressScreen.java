/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * AboutPage.java
 *
 * Created on Apr 6, 2010, 7:07:47 PM
 */

package cput;

/**
 *
 * @author Devin
 */
@SuppressWarnings("serial")
public class RawWebLogProgressScreen extends javax.swing.JDialog {

    /** Creates new form AboutPage
     * @param parent
     * @param modal
     */

    public RawWebLogProgressScreen(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(parent);
        validate();
        progressBar.setIndeterminate(true);
        this.setDefaultCloseOperation(RawWebLogProgressScreen.DO_NOTHING_ON_CLOSE);
    }

 
    @SuppressWarnings({"deprecation"})
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        prompt1Label = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        prompt2Label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        prompt1Label.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        prompt1Label.setText("Parsing web log");

        prompt2Label.setFont(new java.awt.Font("Tahoma", 0, 14));
        prompt2Label.setText("This could take a few minutes...");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(prompt2Label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(prompt1Label)))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(prompt1Label)
                .addGap(18, 18, 18)
                .addComponent(prompt2Label)
                .addGap(18, 18, 18)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                RawWebLogProgressScreen dialog = new RawWebLogProgressScreen(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JLabel prompt1Label;
    private javax.swing.JLabel prompt2Label;
    // End of variables declaration//GEN-END:variables

}
