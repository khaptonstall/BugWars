package cput;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class DBTableInfo {
    Connection con = null;
    Logger logger = Logger.getLogger(DBTableInfo.class);
	
    public DBTableInfo(Connection con)
    {
            this.con = con;
    }

    public DBTableInfo(Connection con, Logger logger)
    {
            this.con = con;
            this.logger = logger;
    }

    public DBTableInfo() {
    }

    public boolean createTable()
    {
        String queryText = null;
        Statement stmt = null;
        try {
            stmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
        try {
            queryText = "CREATE table cput_database_info" +
                        "(" +
                        "dbName    varchar(50),"+
                        "dropDbFlag varchar(2),"+
                        "userCreated varchar(15),"+
                        "dateCreated timestamp,"+
                        "userModified varchar(15),"+
                        "dateModified timestamp"+
                        ");";
            logger.debug("CREATE cput_database_info Table: "+ queryText);
            stmt.executeUpdate(queryText);
			
            return true;
        }
        catch (SQLException e) {
            logger.error("Unable to create table: cput_database_info");
            logger.error(e);
            return false;
        }
    }   //End of function createDatabase
	
    public boolean checkTable() {
        boolean returnFlag = false;
        Statement stmt = null;
        try {
            stmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
			
        ResultSet results = null;
        String queryText = null;
         //The query to get information from postgres metadata table and check if database exits or not.
        queryText = "SELECT * FROM pg_tables WHERE schemaname='public' and tablename = 'cput_database_info';";
        logger.debug(queryText);
        try {
            results = stmt.executeQuery(queryText);
        }
        catch (SQLException e) {
            logger.error("Cannot get the list of databases!!!!");
            logger.error(e);
        }
		
        // if query executed successfull
		
        if (results != null) {
            // If flag is true, this means the table is present and we do not need to create it
            // Else when flag is false, there is no table created and we need to create the table.
			
            boolean flag = true;
            try {
                flag = results.next();
                if(flag == false){
                    returnFlag = false;
                }
                else {
                    logger.debug("cput_database_info table already there");
                    returnFlag = true;
                }
            }
            catch (SQLException e) {
                // TODO Auto-generated catch block
                logger.error("problem in while loop");
                logger.error(e);
            }
        }
        try {
            results.close();
        }
        catch (SQLException e) {
            logger.error(e);
        }
        return returnFlag;
    } //End of function checkDatabase
	
	
    public boolean insertRow(String tuple) {
        boolean returnFlag = false;

        Statement stmt = null;
        try {
            stmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
        try {
            String colName = null;

            colName = "(dbName, dropDbFlag, userCreated, dateCreated, userModified, dateModified)";

            stmt.executeUpdate("INSERT INTO cput_database_info "+ colName + " VALUES (" + tuple + ");");
            returnFlag = true;
        }
        catch (SQLException e) {
            logger.error("Error while inserting into table log_data");
            logger.error(e);
            returnFlag = false;
        }
        return returnFlag;
    }
	
    public boolean updateRow(String databaseName, String userModified, String dropDbFlag) {
        boolean returnFlag = false;

        Statement stmt = null;
        try {
            stmt = con.createStatement();
        }
        catch (SQLException e) {
            logger.error("Unable to create statement");
            logger.error(e);
        }
        String sqlText = "UPDATE cput_database_info " +
                         "set userModified 	= '" + userModified +"', " +
                         "dateModified 		=  now(), "  +
                         "dropDbFlag 		= '" + dropDbFlag +"' "+
                         "FROM (select c.dbname, datecreated ,  " +
                         "      RANK() OVER (partition by c.dbname order by datecreated desc) AS pos " +
                         "				from cput_database_info c" +
                         "   		WHERE dropdbflag = 'N'  " +
                         "		AND c.dbName 	= '"+ databaseName +"'  " +
                         ") as foo  " +
                         "WHERE cput_database_info.dbName 		= '"+ databaseName +"' AND cput_database_info.datecreated = foo.datecreated AND foo.pos = 1;";
        logger.debug(sqlText);
        try {
            stmt.executeUpdate(sqlText);
            returnFlag = true;
        }
        catch (SQLException e) {
            logger.error(e);
            returnFlag = false;
        }
        return returnFlag;
    }
}