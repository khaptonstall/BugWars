package cput;

import javax.swing.JOptionPane;

public class ErrorMessage {
    public boolean displayMessageBox(String message, int type) {
        if(type == 1){
            JOptionPane.showMessageDialog(null, message, "Alert", 1);
            return true;
        }
        else if(type == 2){
            if(JOptionPane.showConfirmDialog(null, message, "Prompt",JOptionPane.YES_NO_OPTION) == 0)
                return true;
            else
                return false;
        }
        return true;
    }
}