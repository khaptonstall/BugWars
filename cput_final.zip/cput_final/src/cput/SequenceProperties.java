package cput;

import java.util.HashMap;
import java.util.Map;

/*
 * @author Nilesh
 * This is a POJO that maintains all the properties related to a sequence.
 * 
 * */
public class SequenceProperties {
		
		//The number of times that the sequence appears in the entire test suite.
		private int totalSequenceCount;
		
		//The sequence. The sequence is created by separating two URLs with '|'.
		private String sequence;
		
		//This map keeps a record of the number of times a sequence appears in individual test cases.
		private Map<String,Integer> testCaseFrequencyMapping = new HashMap<String, Integer>();
		
		
		/* 
		 *@return testCaseFrequency 
		 */
		public Map<String, Integer> getTestCaseFrequencyMapping() {
			return testCaseFrequencyMapping;
		}
		
		/*
		 * Adds a test case to the testCaseFrquencyMapping.
		 * The local count and the total count of the sequence is incremented by 1.
		 */
		public void setTestCaseFrequencyMapping(final String testCase) {
			 
	        if( !testCaseFrequencyMapping.containsKey( testCase ) ){
	        	testCaseFrequencyMapping.put( testCase, 1 );
	        } else { 
	        	testCaseFrequencyMapping.put( testCase, testCaseFrequencyMapping.get( testCase ) + 1 );
	        }
	        incrementTotalSequenceCount();
		}
		

		/*
		 * @return sequence.
		 */
		public String getSequence() {
			return sequence;
		}
		
		/*
		 * Sets the sequence.
		 */
		public void setSequence(String sequence) {
			this.sequence = sequence;
		}

		/*
		 * @return totalSequenceCount.
		 */
		public int getTotalSequenceCount() {
			return totalSequenceCount;
		}
		
		
		/*
		 * Increments the totalSequenceCount by 1.
		 */
		private void incrementTotalSequenceCount() {
			totalSequenceCount++;
		}
		
		/*
		 * Decrements the total count by the given value. This is used in the
		 * case of MFPS.
		 */
		public void decrementTotalCount(int value){
			totalSequenceCount = totalSequenceCount - value;
		}

		public void setTotalSequenceCount(int totalSequenceCount) {
			this.totalSequenceCount = totalSequenceCount;
		}
		
		
			
}
