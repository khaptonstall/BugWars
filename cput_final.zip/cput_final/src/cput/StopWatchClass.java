/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cput;

/**
 *
 * @author Devin Minson & Schuyler Manchester
 */
public class StopWatchClass {

    private long startTime = 0;
    private long stopTime = 0;
    private boolean running = false;

    /**
     * Start timer
     */
    public void start() {
        this.startTime = System.currentTimeMillis();
        this.running = true;
    }

    /**
     * End timer
     */
    public void stop() {
        this.stopTime = System.currentTimeMillis();
        this.running = false;
    }

    /**
     * return either current elapsed time if still running, or elapsed time from start to stop if no longer running.
     * @return
     */
    public double getElapsedTime() {
        double elapsedSeconds;
        double elapsedMillis;
        if (running) {
             elapsedMillis = (System.currentTimeMillis() - startTime);
        }
        else {
            elapsedMillis = (stopTime - startTime);
        }
        elapsedSeconds = elapsedMillis / 1000;
        return elapsedSeconds;
    }
}
