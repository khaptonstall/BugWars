/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cput;

import java.util.ArrayList;
/**
 *
 * @author taranoble
 */
public class ThreeWayEdge {
    
    private int vertex1;
    private int vertex2;
    private int vertex3;
    private ArrayList<TestCase> commonTests;
    
    public ThreeWayEdge(int vert1, int vert2, int vert3, ArrayList<TestCase> commonTests){
        vertex1 = vert1;
        vertex2 = vert2;
        vertex3 = vert3;
        this.commonTests = commonTests;
    }
    
    public int getVertex1(){
        return vertex1;
    }
    
    public int getVertex2(){
        return vertex2;
    }
    
    public int getVertex3(){
        return vertex3;
    }
    
    public ArrayList<TestCase> getCommonTests(){
        return commonTests;
    }
    
    public boolean sequentialVertices(){
        return ((vertex1 < vertex2) && (vertex2 < vertex3));
    }
    
}
