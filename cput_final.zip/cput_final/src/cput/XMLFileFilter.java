package cput;

import java.io.File;

/**
 * This class is used with the JFileChooser to filter displayed files.  It is used
 * to display only XML files.
 * @author Schuyler Manchester and Devin Minson
 */
public class XMLFileFilter extends javax.swing.filechooser.FileFilter {
    public boolean accept(File f) {
        return f.isDirectory() || f.getName().toLowerCase().endsWith(".xml");
    }

    public String getDescription() {
        return ".xml files";
    }
}
